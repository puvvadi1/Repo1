## Security groups

To create/update any `security group` please follow the below steps.

First, setup the environment as mentioned in the main [README.md](https://bitbucket.org/master-bitbucket/bluvalt-openstack-terraform/src/master/README.md)

```
terraform plan --target=module.security_group --out=terraform.plan
terraform apply terraform.plan
```

- In this document, a few examples of some of the security groups along with their rules have been given for both staging and production environment for reference.

- For every Instance we need to attach below security groups in the respective environments as below:

##### For `STAGING` environment:

### ZTNA Security group(Zero Trust Network Access SG)

This security group is used to connect ssh via internal ip, it contains the following rules as shown:

 Direction	  EtherType	  IP Protocol	   Port Range     Remote IP Prefix	   Remote Security Group    	Actions
|-----------|-----------|-------------|---------------|--------------------|--------------------------|----------|
 Egress	       IPv4	       ANY 	        0 - 65535	       0.0.0.0/0	                -	
 Egress  	     IPv6	       ANY	        0 - 65535	         ::/0	                    -	
 Ingress	     IPv4	       TCP	        1 - 65535	          -	                    xxxx
 Ingress	     IPv4	       UDP	        1 - 65535	          -	                    xxxx

### SSH Access security group

This security group is useful for connecting to instances via SSH and it's rules are as shown:

 Direction	 EtherType	 IP Protocol	    Port Range  	Remote IP Prefix	     Remote Security Group	      Actions
|----------|-----------|-------------|--------------|----------------------|--------------------------|---------|
 Egress	       IPv4	     ANY	         0 - 65535	      0.0.0.0/0	                   -	
 Egress  	     IPv6	     ANY	         0 - 65535	        ::/0	                     -	
 Ingress	     IPv4	     TCP	         22 (SSH)	           - 	                      xxxx


`Note`: 
1. Apart from the above `security groups` based on the application port or db port we have to add extra security groups or add rules to the existing security groups  whenever it is needed.

2. You can find other security groups along with their rules in the staging Bluvalt UI (https://ruh2-vdc.bluvalt.com/project/s_security_groups/)

##### For `PRODUCTION` environment:

### ZTNA Security group(Zero Trust Network Access SG)

This security group is used to connect ssh via internal ip. It contains the following rules as shown:

 Direction	    EtherType	IP Protocol	    Port Range      Remote IP Prefix	    Remote Security Group   	Actions
|------------|------------|--------------|--------------|-------------------|-------------------------|---------|
  Egress  	    IPv4	        ANY	        0 - 65535	      0.0.0.0/0	                 -	
  Egress  	    IPv6	        ANY	        0 - 65535	        ::/0	                   -	
  Ingress	      IPv4	        TCP 	      0 - 65535	         -	                    xxxx	
  Ingress 	    IPv4	        TCP	        1 - 65535	         -	                    xxxx	
  Ingress	      IPv4	        UDP	        0 - 65535	         -	                    xxxx	
  Ingress	      IPv4	        UDP	        1 - 65535	         -	                    xxxx

### SSH Access security group

This security group is used for connecting to instances via SSH. It contains the following rule as shown:

 Direction	    EtherType	      IP Protocol	     Port Range  	  Remote IP Prefix	  Remote Security Group	    Actions
|----------|------------------|--------------|--------------|---------------------|-----------------------|-----------|
 Ingress	       IPv4	            TCP	           22 (SSH)	            -	                  xxxx


`Note`: 
1. Apart from the above `security groups` based on the application port or db port we have to add extra security groups or add rules to the existing security groups whenever it is needed. 

2. You can find other security groups along with their rules in the production Bluvalt UI (https://ruh2-vdc.bluvalt.com/project/s_security_groups/)