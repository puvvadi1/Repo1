## Network Architecture

This network architecture contains below components.

1. Public Network 
2. Private Network for Application
3. Private Network for Database

To create the network setup follow the steps mentioned in main [README.md](https://bitbucket.org/master-bitbucket/bluvalt-openstack-terraform/src/master/README.md)

```
terraform init
```
```
terraform plan --target=module.network --out=terraform.plan
```
```
terraform apply terraform.plan
```

### Public Network:

- This network/subnet is created to host `external load balancers` and other publicly accessible services.

- The name of the network should be like `riyadh2-stg-public-network/riyadh2-prd-public-network`.

- The CIDR block range of this subnet is - `xxxx`/`xxxx` [stg/prd]


### Private Network(For Application):

- This network/subnet is created for to host all `Linux/Windows` based `applications` and  `internal load balancers` and other privately accessible services.

- The name of the network should be like `riyadh2-stg-app-private-network/riyadh2-prd-app-private-network`.

- The CIDR block range of this subnet is - `xxxx`/`xxxx` [stg/prd]


### Private Network(For Database):

- This network/subnet is created for to host `database(mysql)` servers.

- The name of the network should be like `riyadh2-stg-storage-private-network/riyadh2-prd-storage-private-network`.

- The CIDR block range of this subnet is - `xxxx`/`xxxx` [stg/prd]
