## Remote Backend Setup - Production 
This documentation is a guide to all the steps required for the setup of remote backend in the Bluvalt production environment.


#### Step 1: Created S3 Bucket for Terraform state file "xxx" [your bucket name]

An `aws s3 bucket` is created. 

#### Step 2: Configured backend.tf to store tf state file to shl AWS S3 bucket
The configuration file for the `backend.tf` is as follows:

```
terraform {
  backend "s3" {
    bucket         = "xxx" [provide your aws s3 bucket name]
    key            = "terraform.tfstate"
    region         = "xxx" [provide aws region]
    dynamodb_table = "xxx" [provide your DynamoDB table name]
  }
}
```
The configuration file for the `provider.tf` is:
```
provider "aws" {
  region     = "xxx" [provide aws region here]
  access_key = "xxx" [provide access key]
  secret_key = "xxx" [provide secret key]
}
```
#### Step 3: 
When the `backend.tf` configuration is run with terraform apply, it automatically pushes the `.tfstate file` to the bucket which is created in step 5.