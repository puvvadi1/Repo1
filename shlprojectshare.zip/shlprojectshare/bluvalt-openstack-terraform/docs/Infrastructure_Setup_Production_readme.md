## Infrastruture Setup - Production 
This documentation is a guide to all the steps required for the infrastructure setup in the Bluvalt production environment.

#### Step 1: Code Changes for Production Configuration and setup

-A new `production` folder is created. All contents of the staging environment folder is copied to the production folder.

-In the `variables.tf` file the following changes are made:-

- All variables with `stg` is changed to `prd` . 
- All CIDR blocks with network prefixes `10.210` are changed to `10.211`
- A new keypair for the production environment is created with the variable name `riyadh2-prod-keypair` and is replaced in place of the staging keypair variables.

#### Step 2: Setting up the production pre-requisite to run the infrastructure setup.
The production environment is setup by `enabling zscaler connector`, `bastion server`. IP ranges changed from `10.210` to `10.211`

#### Step 3: Network creation (Subnets and Router for public/private) through terraform code
To create `network` instances through terraform code, the following steps are carried out:
 ``` 
 terraform init 
 ```
 
 ``` 
 terraform plan --target=module.MODULE_NAME --out=terraform.plan 
 ```
 
 ``` 
 terraform apply "terraform.plan" 
 ```
#### Step 4: Security Groups creation through terraform code
To create `security groups` through terraform code, the following steps are carried out:
 ``` 
 terraform init
 ```
 
 ``` 
 terraform plan --target=module.MODULE_NAME --out=terraform.plan 
 ```
 
 ``` 
 terraform apply "terraform.plan" 
 ```
#### Step 5: Created S3 Bucket for Terraform state file "xxx" [your bucket name]

An `aws s3 bucket` is created. 

#### Step 6: Configured backend.tf to store tf state file to shl AWS S3 bucket
The configuration file for the `backend.tf` is as follows:

```
terraform {
  backend "s3" {
    bucket         = "xxx" [provide your aws s3 bucket name]
    key            = "terraform.tfstate"
    region         = "xxx" [provide aws region]
    dynamodb_table = "xxx" [provide your DynamoDB table name]
  }
}
```
The configuration file for the `provider.tf` is:
```
provider "aws" {
  region     = "xxx" [provide your aws region here]
  access_key = "xxx" [provide your access key]
  secret_key = "xxx" [provide your secret access key]
}
```
#### Step 7: 
When the `backend.tf` configuration is run with terraform apply, it automatically pushes the `.tfstate file` to the bucket which is created in step 5.

Note: Later on, while connecting to launched instances if there is any proxy setting issue, raise bluvalt ticket to resolve it.


