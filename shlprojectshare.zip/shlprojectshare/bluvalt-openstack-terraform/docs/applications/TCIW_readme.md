## TCIW Application

This document contains some notes about TC applications deployment in Bluvalt.

## Dependencies

This appplication contains:

-    `AWSCLIV2` 
-    `7zip` 
-    `Notepad++` 
-    `Rapid7`
-    `Crowdstrike`
-    `Datadog`
-    `datadogAPM`
-    `Netframework 4.8`


### Inserting and retrieving software dependencies from s3:

Usually, you should follow the below instructions.

#### Step1:

Rename the  Computer.

```
Rename-computer -NewName "TCIW-01"
```

#### Step2:

Getting the Windows password from the Hashicorp Vault and passing to it.

```
net user XXXX $Password
```

#### Step3:

Create to directories to keep dependencies in the Machine.

```
mkdir C:\installs
```
```
mkdir C:\bootstrap
```

#### Step4:

Disable the  `Windows Firewall` and Remove `Windows Defender`.

```
Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled False
```

```
Uninstall-WindowsFeature -Name Windows-Defender
```

#### Step5:

Inserting and Retrieving Dependencies through Bluvalt s3.

```
aws s3api --endpoint-url https://<XXX> --profile profilename put-object --bucket <BUCKETNAME> --key sample.exe --body "D:/XXXXXX"
```
```
aws s3api --endpoint-url https://<XXX> --profile profilename put-object --bucket <BUCKETNAME> --key sample.zip --body "D:/XXXXXX"
```

```
aws s3api --endpoint-url https://<XXX> --profile profilename get-object --bucket <BUCKETNAME> --key sample.exe C:\installs\sample.exe
```
```
aws s3api --endpoint-url https://<XXX> --profile profilename get-object --bucket <BUCKETNAME> --key sample.zip C:\installs\sample.zip
```

#### Step6:
Install the dependencies after retrieving from the bluvalt.

```
c:\installs\sample.exe /S | out-null
```

```
Expand-Archive -LiteralPath c:\installs\sample.zip -DestinationPath c:\installs\XXXX -force
````
Configuring the users

```
C:\installs\logonasservice.ps1 "username"
```

#### Step6:

Installing the msbuild package,fonts and Configure win2019 for windows connections.

```
 "C:\installs\setup.ps1"
```

```
"C:\installs\win2019.ps1"
```

## Application Deployment

#### Step1:
Inserting and Retrieving Deployment files through Bluvalt s3. 

```
aws s3api --endpoint-url https://<XXX> --profile profilename put-object --bucket <BUCKETNAME> --key tc_common.ps1 --body "D:/XXXXXX"
```
```
aws s3api --endpoint-url https://<XXX> --profile profilename put-object --bucket <BUCKETNAME> --key module.ps1 --body "D:/XXXXXX"
```

```
aws s3api --endpoint-url https://<XXX> --profile profilename get-object --bucket <BUCKETNAME> --key tc_common.ps1 C:\bootstrap\tc_common.ps1
```
```
aws s3api --endpoint-url https://<XXX> --profile profilename get-object --bucket <BUCKETNAME> --key module.ps1 C:\bootstrap\module.ps1
```

#### Step2:

For `Application Deployment` run below Scripts.

```
"C:\bootstrap\tc_common.ps1"
```

```
"C:\bootstrap\module.ps1"
```
