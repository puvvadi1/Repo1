This documentation is a guide to the steps required for deploying the TCCH application.
### To deploy the application, below instructions are to be followed:

### Step-1: Source Code Repository:

- ` Clone the repo` : git clone git@bitbucket.org:master-bitbucket/bluvalt-openstack-terraform.git


### Step-2: Infrastructure and Application deployemnt for the staging and production environments respectively is as follows: 

- For `staging` environment, `cd bluvalt-openstack-terraform/riyadh-2/staging`(make sure the staging key is present in this path), launch the machine by performing:

### Note:
- If you want to launch any particular module then `comment` all the modules except the one you want to launch in `main.tf` under staging. then execute the below commands.
- If you want to bring complete infrastructure i.e all the instances at the same time then `don't comment any module in main.tf` under staging. then execute the below commands.
- Make sure to create a keypair in bluvalt UI and copy that keypair with the name lnxDeploy.pem to the location "bluvalt-openstack-terraform\riyadh-2\staging\lnxDeploy.pem" 

``` 
terraform init
```
 
```
 terraform apply -var 'hashi_vault_root_token=xxx' -var 'hashi_vault_server_ip=xxxx' -var 'openstack_user_name=xxxx' -var 'openstack_user_password=xxxx' -var 'openstack_tenant_name=tc-poc-2_31419' -var 'staging_keypair=lnxDeploy' -var 'openstack_flavour_name=R1-Generic-4' -var 'dns_server_ip_2=xxxx' -var 'dns_domain_name=sa.shl.domains' --auto-approve
```

- For `production` environment, `cd bluvalt-openstack-terraform/riyadh-2/production`(make sure the production key is present in this path), launch the machine by performing:

### Note:
- If you want to launch any particular module then use the --target=module.<module_name> parameter.
- If you want to bring complete infrastructure i.e all the instances at the same time then don't use `--target=module.<module_name>` parameter in below plan command and rest of the steps are same.
- Make sure to create a keypair in bluvalt UI and copy that keypair with the name riyadh2-prod-keypair.pem to the location "bluvalt-openstack-terraform\riyadh-2\production\riyadh2-prod-keypair.pem".

```
terraform init
```
After terraform init, make sure that the values of the listed parameters are added in the `variables.tf` file under the production folder. The listed parameters are: 

- `openstack_user_name` =xxxx
- `openstack_user_password` =xxxx
- `hashi_vault_root_token` =xxxx 
- `hashi_vault_server_ip` =xxxx
- `dns_server_ip_1` =xxxx
- `dns_server_ip_2` =xxxx
- `dns_domain_name` =sa.shl.com


```
terraform plan --target=module.TCCH --out=terraform.plan
```

```
terraform apply "terraform.plan"
```

`Note:`
The process above will create instance and run `ansible-playbook` to install all the dependencies and download `application binaries` from BluvaltS3 and also run `modules scripts` to install application.
`tcch_config.yaml`:- ansible-playbook used to download all the dependencies.
`tcch_module.sh `:- This script deploys application 

### Step-3: DNS Mapping:

For `STAGING` environment:


- Adding the TCCH IP in named.conf.options--------------->`under /etc/bind`

- to Map TCCH IP to `talentcentral-tcch-zone1.sa.shl.domains & talentcentral-tcch-zone2.sa.shl.domains` and need to increase the serial number in forward.sa.shl.domains and reverse.sa.shl.domains--------->under /etc/bind/zones

- sudo `named-checkconf`

- sudo named-checkzone 210.10.in-addr.arpa `/etc/bind/zones/reverse.sa.shl.domains`

- sudo named-checkzone `sa.shl.domains forward.sa.shl.domains`

- `sudo systemctl restart bind9`


For `PRODUCTION` environment:

- Adding the TCCH IP in named.conf.options--------------->`under /etc/bind`

- to Map TCCH IP to `talentcentral-tcch-zone1.sa.shl.com & talentcentral-tcch-zone2.sa.shl.com` and need to increase the serial number in forward.sa.shl.com and reverse.sa.shl.com--------->under /etc/bind/zones

- sudo `named-checkconf`

- sudo named-checkzone 211.10.in-addr.arpa `/etc/bind/zones/reverse.sa.shl.com`

- sudo named-checkzone `sa.shl.com forward.sa.shl.com`

- `sudo systemctl restart bind9`


Note: 
1. While connecting to machine if there is any proxy setting issue, raise bluvalt ticket to resolve it.
2. While launching the machine if you face error like "process exited with status 100", then make sure you have atleast 20 volumes available in bluvalt.
3. While launching the machine if you face error like "Error creating openstack server : EOF", then make sure to wait for atleast half an hour between terraform plan and terraform apply.