This documentation is a guide to the steps required for deploying the TCIA application.
### To deploy the application, below instructions are to be followed:

#### Step-1: Perform git clone for terraform script and dependency scripts as shown below:

```
git clone git@bitbucket.org:master-bitbucket/bluvalt-openstack-terraform.git
```

#### Step-2: To launch machines, go to the path mentioned in the respective environment and do the terraform apply as instructed:

- For the `staging` environment, go to the path `./bluvalt-openstack-terraform/riyadh-2/staging` and launch the machine as shown below (make sure that the staging keypair is present in this path):

### Note:
- If you want to launch any particular module then `comment` all the modules except the one you want to launch in `main.tf` under staging. then execute the below commands.
- If you want to bring complete infrastructure i.e all the instances at the same time then `don't comment any module in main.tf` under staging. then execute the below commands.
- Make sure to create a keypair in bluvalt UI and copy that keypair with the name packer-tom.pem to the location "bluvalt-openstack-terraform\riyadh-2\staging\packer-tom.pem" 

```
terraform init
```

```
terraform apply -var 'hashi_vault_root_token=xxxx' -var 'hashi_vault_server_ip=xxxx' -var 'openstack_user_name=xxxx' -var 'openstack_user_password=xxxx' -var 'openstack_tenant_name=tc-poc-2_31419' -var 'staging_keypair=packer-tom' -var 'openstack_flavour_name=R1-Generic-4'  --auto-approve
```

- For the `production` environment, go to the path `./bluvalt-openstack-terraform/riyadh-2/production` and launch the machine as shown below (make sure that the production keypair is present in this path):

### Note:
- If you want to launch any particular module then use the --target=module.<module_name> parameter.
- If you want to bring complete infrastructure i.e all the instances at the same time then don't use `--target=module.<module_name>` parameter in below plan command and rest of the steps are same.
- Make sure to create a keypair in bluvalt UI and copy that keypair with the name riyadh2-prod-keypair.pem to the location "bluvalt-openstack-terraform\riyadh-2\production\riyadh2-prod-keypair.pem".

```
terraform init
```

After terraform init, make sure that the values of the listed parameters are added in the `variables.tf` file under the production folder. The listed parameters are: 

- `openstack_user_name` =xxxx
- `openstack_user_password` =xxxx
- `hashi_vault_root_token` =xxxx 
- `hashi_vault_server_ip` =xxxx
- `dns_server_ip_1` =xxxx
- `dns_server_ip_2` =xxxx
- `dns_domain_name` =sa.shl.com

```
terraform plan --target=module.TCIA --out=terraform.plan
```

```
terraform apply "terraform.plan"
```

`Note`:
The above process will create instance and run common.ps1 script as userdata to install dependencies and download modules scripts and application binaries for deployment from BluvaltS3. 


#### Step-3: Run the powershell script from the path `C:\bootstrap\tc_common.ps1` which will deploy the application binaries with vault ip and token


```
.\tc_common.ps1 XXXX xxxx
```
where XXXX = vault token and xxxx = vault IP

`common.ps1`-: Downloads all the dependency softwares and  script files from S3 bucket. It also installs all the dependency softwares.

`diskpart.ps1`-: Creates D drive.

`setup.ps1`-: It will create Tomcat and Devops users and different roles.

`winrm.ps1`-: It performs windows OS related configurations.

`tc_common.ps1`-: This script enables winrm and runs module.ps1 script.

`module.ps1`-: This script deploys application and runs dns.ps1 script.

`dns.ps1`-: This script configures dns on the machine. 

 
#### Step-4: DNS Mapping

For `STAGING` environment:


-- Adding the TCIA IP in `named.conf.options`--------------->`under /etc/bind`

-- to Map TCIA IP to `talentcentral-tcia-zone1.sa.shl.domains & talentcentral-tcia-zone2.sa.shl.domains` in `forward.sa.shl.domains and reverse.sa.shl.domains`--------->under `/etc/bind/zones`

-- `sudo named-checkconf`

-- `sudo named-checkzone 210.10.in-addr.arpa /etc/bind/zones/reverse.sa.shl.domains`

-- `sudo named-checkzone sa.shl.domains forward.sa.shl.domains`

-- `sudo systemctl restart bind9`



For `PRODUCTION` environment:


-- Adding the TCIA IP in `named.conf.options`--------------->`under /etc/bind`

-- to Map TCIA IP to `talentcentral-tcia-zone1.sa.shl.com & talentcentral-tcia-zone2.sa.shl.com` in `forward.sa.shl.com and reverse.sa.shl.com`--------->under `/etc/bind/zones`

-- `sudo named-checkconf`

-- `sudo named-checkzone 211.10.in-addr.arpa /etc/bind/zones/reverse.sa.shl.com`

-- `sudo named-checkzone sa.shl.com forward.sa.shl.com`

-- `sudo systemctl restart bind9`



Note: While launching the machine, if faced with error like "Error creating openstack server : EOF", then make sure to wait for atleast half an hour between terraform plan and terraform apply.