## TCCH Application

This document contains some notes about TC applications deployment in Bluvalt.


## Dependencies

This appplication contains:

-    `openjdk-8-jdk` 
-    `htop` 
-    `jq` 
-    `telnet`
-    `ruby`
-    `Data-dog Agent`
-    `Rapid7`
-    `CrowdStrike`
-    `Rediscli`

For software dependencies versions are defined below: 
-    `Data-dog Agent:` v7
-    `Rapid7:` v2.7.10.7
-    `CrowdStrike:` falcon-sensor_6.12.0-10912
-    `Rediscli:` v4.0.9

### Inserting and retrieving software dependencies from s3:
Usually, you should follow the below instructions.

#### Step1:

Inserting the software dependencies to s3.
```
aws s3api --endpoint-url https://<XXX> --profile profilename put-object --bucket <BUCKETNAME> --key sample.tar.gz --body "D:/XXXXXX"
```

#### Step2:

Retrieving software dependencies from s3
```
aws s3api --endpoint-url https://<XXX> get-object --bucket <BUCKETNAME> --key sample.tar.gz /tmp/sample.tar.gz
```

For Application dependencies versions are defined below:
-    `tc-cache.jar`

### Inserting and retrieving Application dependencies from s3:

Usually, you should follow the below instructions.

#### Step1:

Inserting the Application dependencies to s3.

```
aws s3api --endpoint-url https://<XXX> --profile profilename put-object --bucket <BUCKETNAME> --key sample.jar --body "D:/XXXXXX"
```

#### Step2:

Retrieving Application dependencies from s3

```
aws s3api --endpoint-url https://<XXX> get-object --bucket <BUCKETNAME> --key sample.war /opt/shl/sample.jar
```