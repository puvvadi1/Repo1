## MSSQL Databse Server 

This document contains some notes about `MSSQL Server`, `SSMS(SQL Server Management Studio)` and `7-Zip Installer`.

#### Step 1:

Insert the artifacts to `s3` like database backup files, IderaSQLdmInstallationKit-x64.zip, SQL2019-SSEI-Dev.exe, SSMS-Setup-ENU.exe, 7z.exe 

```
aws s3api --endpoint-url https://<XXX> --profile profilename put-object --bucket <BUCKETNAME> --key sample.war --body "D:/XXXXXX"
```

#### Step 2:

After windows machine is launched successfully with required drive partitions, all the dependencies needed for the installtion is downloaded automatically from the respective bucket using `Terraform Script`. The commands for retrieving the artifacts from `s3` in TF script are:

```
aws s3api --endpoint-url https://<XXX>  get-object --bucket <BUCKETNAME> --key SQL2019-SSEI-Dev.exe c:\installs
```

```
aws s3api --endpoint-url https://<XXX>  get-object --bucket <BUCKETNAME> --key SSMS-Setup-ENU.exe c:\installs
```

```
aws s3api --endpoint-url https://<XXX>  get-object --bucket <BUCKETNAME> --key 7z.exe c:\installs
```

#### Step 3:

Extract and install all the downloaded artifacts of sql `server`, `ssms`, `7z` and database backup files.

#### Step 4:

Extract downloaded database files like Talentcentral.7z using 7zip. After extraction is complete, you will get .bak files.

#### Step 5:

Installtion of sql server and ssms done then 

1. Go to SSMS and connect to SQL Server Instance with windows credentials.

2. Create new user and login to sql server instance with created user (to check whether you are being able to connect sql server instance through user or not). 

#### Step 6:

Restore database's from `.bak` files.

1. Go to `database`, do a right click here and then select `Restore database`. Then select `device` and then give the `path of the location where the database backup files are stored` and click `ok`.

### Step 7:

Do the required user mapping `with db_owner permisiion` to all restored databases. (users like tomcat & tomcat-s)

### Step 8:

1. Go to `SQLServer properties`, under `security`, then under `server authentication` select `SQS server and windows Authentication mode`.

2. Try to connect `SQL Server Instance` through mapped users. If the connection to `SQL Server instance` through `users` is done, then proceed to step 9.

### Step 9:

Select the `TalentCentral database`. Execute the queries like select, insert, update regarding the required `tcadmin` application.

### Note:

For disk partitions and other configurations need to follow [Disk-partition](https://confluence.shl.systems/display/CLOUD/Standard+Database+Configurations+for+SHL+Environment)