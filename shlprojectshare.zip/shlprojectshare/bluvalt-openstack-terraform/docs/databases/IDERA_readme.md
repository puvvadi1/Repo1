## IDERA SQL Diagnostic Manager

This document contains some notes about `IDERA SQLDM`. It is one of the `sql server monitoring tools`.

#### Step 1:

Insert the artifacts to `s3` like IderaSQLdmInstallationKit-x64.zip, SQL2019-SSEI-Dev.exe, SSMS-Setup-ENU.exe.

```
aws s3api --endpoint-url https://<XXX> --profile profilename put-object --bucket <BUCKETNAME> --key sample.war --body "D:/XXXXXX"
```

#### Step 2:

After windows machine is launched successfully with required drive partitions, all the dependencies needed for installation is downloaded automatically from the respective bucket using `Terraform Script`. The commands for retrieving the artifacts from `s3` in TF script are:

```
aws s3api --endpoint-url https://<XXX>  get-object --bucket <BUCKETNAME> --key SQL2019-SSEI-Dev.exe c:\installs
```

```
aws s3api --endpoint-url https://<XXX>  get-object --bucket <BUCKETNAME> --key SSMS-Setup-ENU.exe c:\installs
```

```
aws s3api --endpoint-url https://<XXX>  get-object --bucket <BUCKETNAME> --key IderaSQLdmInstallationKit-x64.zip c:\installs
```

#### Step 3:

Extract and install all the downloaded artifacts of `idera sqldm`, `sql server`, `ssms`

#### Step 4:

1. Go to SSMS and connect to SQL Server Instance with windows credentials.

2. Create new user and login to sql server instance with this user. 

3. After logging into SQL Server Instance successfully, again connect to the sql server with the credentials of the database machine we need to add to Idera Dashboard for monitoring purpose.

### Step 5:

1. Go to `SQLServer properties`, under `security`, then under `server authentication` select `SQS server and windows Authentication mode`.

2. Try to connect `SQL Server Instance` through mapped users. If the connection to `SQL Server instance` through `users` is done, then proceed to step 6.

#### Step 6:

- After installation of `ideradm` is done, go to `ideradm dashboard` and then go to `All Servers`. 
- Here, add the `SQL server instance` which is needed to be added to the Idera dashboard. 
- Once it is done, `ideradm dashboad` will show the list of all the databases, logs, alerts, metrics of the added sqlserver.

### Note:

For disk partitions and other configurations need to follow [Disk-partition](https://confluence.shl.systems/display/CLOUD/Standard+Database+Configurations+for+SHL+Environment)