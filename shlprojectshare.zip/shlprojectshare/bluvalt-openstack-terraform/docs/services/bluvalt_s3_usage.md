## Bluvalt S3 using AWS S3API

This documentation is a guide to some important notes about Configuration of S3 in Bluvalt.


## Setting up an environment for S3

Usually, you should follow the below instructions.

#### Step1:
Inserting the artifacts to s3.

```
aws s3api --endpoint-url https://<XXX> --profile profilename put-object --bucket <BUCKETNAME> --key sample.war --body "D:/XXXXXX"
```
#### Step2:
Get the `aws_access_key` , `aws_secret_acess_key` and `aws_default_region` from Hashicorp vault and configure them.

```
curl -H "X-Vault-Token:{{ <RootToken> }}" -X GET http://{{ <Ipaddress> }}:8200/v1/kv/aws_access_key
```
```
curl -H "X-Vault-Token:{{ <RootToken> }}" -X GET http://{{ <Ipaddress> }}:8200/v1/kv/aws_secret_access_key
```
```
curl -H "X-Vault-Token:{{ <RootToken> }}" -X GET http://{{ <Ipaddress> }}:8200/v1/kv/aws_region
```
#### Step3:
Retrieving artifacts from s3

```
aws s3api --endpoint-url https://<XXX> get-object --bucket <BUCKETNAME> --key sample.war /tmp/sample.war
```

