##  Internal Load balancer
This documentation contains some notes about Internal load balancer script in Bluvalt.

## Setting up an environment for Internal load balancer
Usually, you should follow the below instructions.

#### Step1:
- Updating packages, Installing and enabling Docker
```
sudo apt-get update -y
```
```
sudo apt-get install -y docker.io
sudo systemctl enable docker
sudo systemctl start docker
```

- Enabling this user to docker without sudo

```
sudo usermod -a -G docker "${USER}"
```
- Run the Nginx Docker image and get the Nginx configuration files from container to local

```
dockerId=$(sudo docker run -d nginx)
sleep 1s
sudo docker cp "${dockerId}":/etc/nginx/nginx.conf /etc/nginx.conf
sudo docker cp "${dockerId}":/etc/nginx/conf.d/default.conf /etc/default.conf
```
- Kill the docker container

```
sudo docker kill "${dockerId}"
```

#### Step2:
##### Adding the DNS entries to resolv.conf file
- Install the resolvconf package

```
sudo apt-get install resolvconf -y
```
- Add the DNS name entries in resolv.conf files

```
sudo cat <<EOF > /etc/resolvconf/resolv.conf.d/head
nameserver xx.xx.xx.xx      #ns1 ip
nameserver xx.xx.xx.xx      #ns2 ip
search xx.xxx.xxx           #domain name
EOF
```
#### Update the resolv.conf file
```
sudo resolvconf -u
```

#### Step3:
#### nginx configuration

- now modify nginx.conf to merge in upstream servers conf in the 'http' section
- now use some sed magic to merge the two files
- first create a placeholder 'tag' then merge the files using the 'r' feature of sed
```
sudo sed -i 's/http {/http { \n#FROM_UPSTREAM_TEMPLATE/' /etc/nginx.conf
sudo sed -ie '/#FROM_UPSTREAM_TEMPLATE/rupstream.conf.template' /etc/nginx.conf
```
- Upstream configuration for all applications 

```
sudo vi /etc/nginx.conf #outside of the container
sudo vi /etc/nginx/nginx.conf #inside of the container
```
- our virtualhosts configuration to inject in nginx-default.conf

- Copy the nginx-default.conf file to /etc/nginx-default.conf

```
sudo cp nginx-default.conf /etc/nginx-default.conf
sudo vi /etc/nginx-default.conf #outside of the container
sudo vi /etc/nginx/conf.d/default.conf #inside of the container
```

- Configuring perl-regex.conf file
```
sudo vi /etc/perl-regex.conf #outside of the container
sudo vi /etc/nginx/conf.d/perl-regex.conf #inside of the container
```
- Configuring the SSL Certificate

```
sudo vi  /home/ubuntu/fullchain.pem #outside of the container
sudo vi /etc/ssl/private/fullchain.pem #inside of the container
```

- Configuring the privkey.pem file

```
sudo vi  /home/ubuntu/privkey.pem #outside of the container
sudo vi /etc/ssl/private/privkey.pem #inside of the container
```
#### Step 4:
#### datadog configuration
- To configure the datadog on the internal ngninx machine, the following configurations were done.

1. In the beginning, we have to install the datadog agent script file, namely, `install_script.sh` 

```
sudo wget https://s3.amazonaws.com/dd-agent/scripts/install_script.sh
```

To set permissions to this file:

``` 
sudo chmod 777 /tmp/install_script.sh
```

2. To setup datadog monitoring in the internal_lb machines, at first we have to initialize the following parameters in the beginning:

`hashi_vault_root_token`="xxx"
`hashi_vault_server_ip` ="xxx"
`PROFILE` = "xxx"

Then we have to configure the following files as described:

3. Configuring the `datadog.yaml` file in the `/etc/datadog-agent` location

This file is one of the primary files, essential for `installing the datadog agent` enabling all the required permissions and passing the required tags and api key i.e.`DDAPIKEY`.

```
DDAPIKEY=`curl -H "X-Vault-Token:$hashi_vault_root_token" -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/DATADOG_APIKEY | jq '.data.DATADOG_APIKEY' | sed 's/"//g'` 
```

To view the file: 

```
sudo vi /etc/datadog-agent/datadog.yaml
```

4. Configuring the `status.conf` file in the `/etc` location where the other nginx configuration files are present. 

```
sudo vi /etc/status.conf
```

The `status.conf` file configuration:

```
tee /etc/status.conf <<EOF
server {
  listen 81;
  server_name localhost;
  access_log off;
  allow 127.0.0.1;
  deny all;
location /nginx_status {
    # Choose your status module
    # freely available with open source NGINX
    stub_status;
    # for open source NGINX < version 1.7.5
    # stub_status on;
    # available only with NGINX Plus
    # status;
    # ensures the version information can be retrieved
    server_tokens on;
  }
}

EOF
```

5. To check the status of the datadog-agent:

```
sudo systemctl status datadog-agent
```

6. To `enable` and `restart` datadog: 

```
sudo systemctl enable datadog-agent
```
```
sudo systemctl restart datadog-agent
```

#### Step5:
- now inject these configurations into two nginx containers running as a background service. 

```
sudo docker run -d --name datadog-agent \
                -e DD_API_KEY=$DDAPIKEY \
                -e DD_LOGS_ENABLED=true \
                -e DD_LOGS_CONFIG_CONTAINER_COLLECT_ALL=true \
                -e DD_LOGS_CONFIG_DOCKER_CONTAINER_USE_FILE=true \
                -e DD_CONTAINER_EXCLUDE="name:datadog-agent" \
                -v /var/run/docker.sock:/var/run/docker.sock:ro \
                -v /var/lib/docker/containers:/var/lib/docker/containers:ro \
                -v /proc/:/host/proc/:ro \
                -v /opt/datadog-agent/run:/opt/datadog-agent/run:rw \
                -v /sys/fs/cgroup/:/host/sys/fs/cgroup:ro \
                gcr.io/datadoghq/agent:latest
```

```
sudo docker run \
    -d \
    -p 80:80 \
    -p 8983:8983 \
    -p 8984:8984 \
    -p 26379:26379 \
    -p 61617:61617 \
    -p 443:443 \
    -p 9036:9036 \
    -p 9038:9038 \
    -p 81:81 \
    --restart=always \
    -v /etc/nginx.conf:/etc/nginx/nginx.conf:ro \
    -v /etc/nginx-default.conf:/etc/nginx/conf.d/default.conf:ro \
    -v /tmp/install_script.sh:/tmp/install_script.sh:ro \
    -v /etc/perl-regex.conf:/etc/nginx/conf.d/perl-regex.conf:ro \
    -v /home/ubuntu/<XXXX>.pem:/etc/ssl/private/<XXXX>.pem:ro \                   
    -v /home/ubuntu/<XXXX>.pem:/etc/ssl/private/<XXXX>.pem:ro \
    -v /etc/resolv.conf:/etc/resolv.conf:ro \
    -v /etc/datadog-agent/datadog.yaml:/etc/datadog.yaml:ro \
    -v /etc/status.conf:/etc/status.conf:ro \
    nginx:1.21.0-perl \
    nginx-debug -g 'daemon off;'

```
`Note`: In the above code block, `XXXX` = ssl certificate key file name for respective environment.

- To check the status of the docker containers:

```
docker ps
```