## DATADOG SERVICE USAGE

This document contains some notes about Datadog service in Bluvalt.


Usually, you should follow the below instructions.

#### Step1:

Install the latest datadog agent `install_script` and move the file to destination.

```
sudo wget https://s3.amazonaws.com/dd-agent/scripts/install_script.sh 
```

#### Step2:

Change the `DD_API_KEY` and `DD_SITE` as required.

```
DD_API_KEY=XXXX DD_SITE=XXXX
```


#### Step3:

Configuration file for Datadog: 

```
DDAPIKEY= xxxxx

systemctl stop datadog-agent

tee /etc/datadog-agent/datadog.yaml <<EOF
dd_url: https://app.datadoghq.eu
api_key: $DDAPIKEY
logs_enabled: true
log_format_json: false
log_level: DEBUG
log_file: /var/log/datadog/agent.log
log_payloads: false
log_to_console: true
log_to_syslog: false
logging_frequency: 20
apm_config:
  enabled: true
logs_config:
  container_collect_all: false
  dd_port: 10516
  dd_url: agent-intake.logs.datadoghq.com
  dev_mode_use_proto: true
  frame_size: 9000
  open_files_limit: 100
  run_path: ""
  tcp_forward_port: -1
tags:
- system:talentcentral
- application:talentcentral
- env:tc_$PROFILE
- tcappcode:tcch
- tcappname:tc-cache
EOF

```

