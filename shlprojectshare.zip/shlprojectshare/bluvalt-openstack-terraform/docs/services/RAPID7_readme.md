## RAPID7 SERVICE USAGE

This document contains some notes about RAPID7 Service in Bluvalt.


Usually, you should follow the below instructions.

#### Step1:

Inserting the Rapid7 Binaries to s3.

```
aws s3api --endpoint-url https://<XXX> --profile profilename put-object --bucket <BUCKETNAME> --key agent-installer.sh --body "D:/XXXXXX"
```
#### Step2:

Retrieving Rapid7 Binaries from s3 and copying to destination using AWS S3api.

```
sudo aws s3api --endpoint-url https://<XXX> get-object --bucket <BUCKETNAME> --key agent_installer.sh /tmp/rapid7/agent_installer.sh
```

#### Step3:

Commands to install and run the Rapid7 service.

```
dos2unix /tmp/rapid7/install.sh
```

```
chmod 755 /tmp/rapid7/install.sh
```
          
```
bash /tmp/rapid7/install.sh
```