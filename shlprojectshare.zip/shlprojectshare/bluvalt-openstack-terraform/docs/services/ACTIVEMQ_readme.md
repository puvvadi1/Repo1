## ACTIVEMQ SERVICE

This document contains some notes about ActiveMQ Service in Bluvalt.


## Dependencies

This Service contains:

-    `openjdk-8-jdk` 
-    `awscli` 
-    `jq` 

Usually, you should follow the below instructions.

#### Step1:
Inserting the ActiveMQ-server to s3.

```
aws s3api --endpoint-url https://<XXX> --profile profilename put-object --bucket <BUCKETNAME> --key sample.tar.gz --body "D:/XXXXXX"
```
#### Step2:
Retrieving software dependencies from s3

```
aws s3api --endpoint-url https://<XXX> get-object --bucket <BUCKETNAME> --key sample.tar.gz ./sample.tar.gz
```
#### Step3:
Commands to run to `enable and start the ActiveMQ-server`.

```
sudo systemctl daemon-reload
```
```
sudo systemctl start activemq
```
```
sudo systemctl enable activemq
```
```
/opt/activemq/bin/activemq status
```