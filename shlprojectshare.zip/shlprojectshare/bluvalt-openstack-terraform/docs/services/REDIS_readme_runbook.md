## REDIS SERVICE

This document contains some notes about redis service in Bluvalt.


Usually, you should follow the below instructions.

#### Step1:

Install Dependencies as shown below:
-    `Redis-server` 
-    `apache2` 
-    `redis-sentinel` 

```
sudo apt install redis-server -y
```

```
sudo apt install apache2 -y
```

```
sudo apt install redis-sentinel -y
```

#### Step2:

Install sentinel.conf using copy from `templates/redis-sentinel.conf.j2`

Install redis.conf using template from `/templates/redis-master.conf.j2`

copy redis_os_setup.sh from `/files/redis_os_setup.sh`


#### Step3:

Run this commands for configuring the `Redis-server` and `Redis-sentinel`.

```
sudo sed -e '/ReadOnlyDirectories/s/^/#/g' -i /lib/systemd/system/redis-server.service
```
```
sudo sed -e '/PIDFile/s/^/#/g' -i /lib/systemd/system/redis-sentinel.service
```

### Step4:

Reload the daemon and Restart the services.

-    `Redis-server` 
-    `apache2` 
-    `redis-sentinel` 

```
systemctl daemon-reload
```

```
sudo apt install redis-server -y
```

```
sudo apt install apache2 -y
```

```
sudo apt install redis-sentinel -y
```

### Note
1. Run Master first and then slave.
2. Master IP need to be updated in vault.
3. For Redis cluster setup, get the Redis master IP from Hashicorp vault to the slaves of Redis.