
## MQR SERVICE

This document contains some notes about `MQR Service` in Bluvalt.

Usually, you should follow the below instructions:

#### Step1:

Inserting the `MQR-server` to s3:

```
aws s3api --endpoint-url https://<XXX> --profile profilename put-object --bucket <BUCKETNAME> --key mqr/mqr-container.zip  --body "D:/XXXXXX"
```

#### Step2:
Retrieving `MQR-server` from s3:

```
aws s3api --endpoint-url https://<XXX> get-object --bucket <BUCKETNAME> --key mqr/mqr-container.zip  ./mqr-container.zip 
```

#### Step3:

Install unzip and unzip the `mqr-container.zip`:

```
sudo apt-get install zip unzip -y
```
```
sudo unzip mqr-container.zip 
```

### Step4:
Install docker, build and run the `MQR-container master and slave`:

```
sudo apt install docker.io -y
```

```
sudo docker image build  -t tc-mqr-img /tmp/mqr-container
```

```
sudo docker container run \
-e MQ_API_CONTEXT='/mq-api' \
-e CONTENT_DB_DRIVER='net.sourceforge.jtds.jdbc.Driver' \
-e CONTENT_DB_URL='jdbc:jtds:sqlserver://'[PROVIDE DB IP HERE]':1605/TC_Content' \
-e CONTENT_DB_USER=[PROVIDE DB USER HERE] \
-e CONTENT_DB_PASSWORD=[PROVIDE DB PASSWORD HERE] \
-p 8080:8080 \
--name tc-mqr-cont \
-d tc-mqr-img
```

### Step5:
List the containers

```
sudo docker ps -a
```
