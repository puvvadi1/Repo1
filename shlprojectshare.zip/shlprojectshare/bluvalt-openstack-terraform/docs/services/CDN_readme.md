## CDN SERVICE

This document contains some notes about cdn service in Bluvalt.


Usually, you should follow the below instructions.

#### Step1:

Install Dependencies:
-    `apache2` 
-    `s3fs` 

```
sudo apt install apache2 -y
```

```
sudo apt install s3fs -y
```

#### Step2:
Run this commands for configuring the `volume mount` with bluvlat S3 bucket for file syncup.

```
sudo systemctl restart apache2
```

```
sudo touch /etc/passwd-s3fs
```

```
echo "$AWS_ACCESS_KEY_ID:$AWS_SECRET_ACCESS_KEY" >> /etc/passwd-s3fs;
```

```
sudo s3fs cdn-test /var/www/html/cdn -o passwd_file=/etc/passwd-s3fs -o allow_other -o url=https://xxxxxx
```


#### Step3:

Restart the apache2 server

```
sudo systemctl restart apache2
```

#### Step4:
 
Creating s3 mount-point monitoring script for failure of mount failed and cron-job
 
```
MountFailed=$(/bin/ls -l /var/www/html 2>&1 | grep -i "healthcheck.html" | wc -l)
```
 
If MountFailed vaule return zero, Its means Mount is failed. Follow the script below and add as cron job
 
```
if [[ $MountFailed == "0" ]]; then
  echo $(date) ": Remounting /var/www/hmtl on TCCD  .."
  umount -l /var/www/html
  sudo s3fs <<BucketName>> /var/www/html/cdn -o passwd_file=/etc/passwd-s3fs -o allow_other -o url=https://xxxxxx
  sleep 15
 
fi
```
To add Cron Job Script
 
```
*/1 * * * * root /bin/bash /opt/shl/monitor-s3-mountpoint.sh
```
 
#### Step5:
 
To start and enable the cron job
 
```
sudo systemctl start cron
```
```
sudo systemctl enable cron
```