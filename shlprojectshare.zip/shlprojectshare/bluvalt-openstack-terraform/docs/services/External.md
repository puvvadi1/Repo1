##  External Load balancer
This document contains some notes about External load balancer in Bluvalt.

## Setting up an environment for External load balancer
Usually, you should follow the below instructions.

#### Step1:
Updating packages and Installing latest/default nginx

```
 sudo apt-get update -y
```
```
sudo apt install nginx -y
```
#### Step2:
#### SSL Certificates path

```
sudo cd /etc/letsencrypt/live/sa.shl.domains
```

#### Step3:
#### Configuring the nginx.conf file
Once installed change directory into the nginx main configuration folder.

```
sudo cd /etc/nginx/
```
Configuring the nginx.conf with upstream servers(Internal server)
```
sudo vi /etc/nginx/nginx.conf

```
#### Step3:
#### Configuring the applications file in conf.d
Adding the proxy details in applications file

```
sudo vi /etc/nginx/conf.d/applications
```
#### Step4:
#### Perl Configuration

```
sudo vi /etc/nginx/conf.d/perl-regex.conf
```

#### Step5:
#### Timeout Configuration

```
sudo vi /etc/nginx/conf.d/timeout.conf
```

#### Step 6:
#### datadog configuration
1. Datadog script installation through:

```
sudo wget https://s3.amazonaws.com/dd-agent/scripts/install_script.sh
```

2. To setup datadog monitoring in the internal_lb machines, at first we have to initialize the following parameters in the beginning:

`hashi_vault_root_token`="xxx"
`hashi_vault_server_ip` ="xxx"
`PROFILE` = "xxx"

3. Configuring the `datadog.yaml` file in the `/etc/datadog-agent` location

This file is one of the primary files essential for installing the datadog agent enabling all the required permissions and passing the required tags and api key i.e.`DDAPIKEY`.

```
DDAPIKEY=`curl -H "X-Vault-Token:$hashi_vault_root_token" -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/DATADOG_APIKEY | jq '.data.DATADOG_APIKEY' | sed 's/"//g'` 
```

```
sudo vi /etc/datadog-agent/datadog.yaml
```

4. In the `conf.yaml ` file (location : ` /etc/datadog-agent/conf.d/nginx.d`) the following lines are added in the beginning in regards to datadog configurations:

```
init_config:

instances:
  - nginx_status_url: http://localhost:81/nginx_status/
```

- To view the file,

```
sudo vi /etc/datadog-agent/conf.d/nginx.d/conf.yaml
```
- To set the permissions:

```
sudo chmod 644 /var/log/nginx/access.log

```

```
sudo chmod 644 /var/log/nginx/error.log

```

4. Configuring the `status.conf` file in the `/etc/nginx/conf.d` location where the other nginx configuration files are present. 

```
sudo vi /etc/nginx/conf.d/status.conf
```
The `status.conf` file configuration:

```
sudo cat <<EOF > /etc/nginx/conf.d/status.conf
server {
  listen 81;
  server_name localhost;
  access_log off;
  allow 127.0.0.1;
  deny all;
location /nginx_status {
    # Choose your status module
    # freely available with open source NGINX
    stub_status;
    # for open source NGINX < version 1.7.5
    # stub_status on;
    # available only with NGINX Plus
    # status;
    # ensures the version information can be retrieved
    server_tokens on;
  }
}

EOF
```

5. To check the status of the datadog-agent:

```
sudo systemctl status datadog-agent
```

6. To `enable` and `restart` datadog: 

```
sudo systemctl enable datadog-agent
```
```
sudo systemctl restart datadog-agent
```
#### Step6:
#### Updating the resolv.conf file with DNS IP

```
sudo vi /etc/resolv.conf
```
You should configure your name servers(ns1,ns2) and search domain in the list:
```
nameserver xxxx.xxx.xx.xxx   #ns1 ip
nameserver xxxx.xxx.xx.xxx   #ns2 ip
search     xxx.xx.xxx        #domain name
```
#### Restarting Nginx
```
sudo systemctl restart nginx
```