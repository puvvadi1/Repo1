This documentation is a guide to the steps required to perform various activities with Bluvalt S3 bucket.

#### Step 1: The very first step is to configure AWS on the machine. For that perform the following steps:
On the terminal type:

```
aws configure  
```

Put the value of the following as needed:

`ACCESS_KEY` = "XXX" 
`SECRET_ACCESS_KEY` = "XXX" 
`DEFAULT_REGION` = "XXX" 


#### Step 2: The following commands are of importance:

1. To `create` bucket in Bluvalt S3, 

```
aws s3api --endpoint-url https://<XXX> --profile <PROFILE_NAME>  create-bucket --bucket <BUCKETNAME>
```

2. To `upload` files to bluvalt s3,
 
```
aws s3api --endpoint-url https://<XXX> --profile <PROFILE_NAME> put-object --bucket <BUCKETNAME> --key <KEY_NAME> --body <SOURCE_PATH>
```

3. To `get` files from bluvalt s3,

```
aws s3api --endpoint-url https://<XXX> --profile <PROFILE_NAME> get-object --bucket <BUCKETNAME> --key <KEY_NAME> <DESTINATION_PATH>
```

4. To `delete` files from Bluvalt S3,
```
aws s3api --endpoint-url https://<XXX> --profile <PROFILE_NAME> delete-object --bucket <BUCKETNAME> --key <KEY_NAME> 
```

5. Commands to `list` all the objects in Bluvalt S3,
```
aws s3api --endpoint-url https://<XXX> --profile <PROFILE_NAME> list-objects --bucket <BUCKETNAME>
```  
