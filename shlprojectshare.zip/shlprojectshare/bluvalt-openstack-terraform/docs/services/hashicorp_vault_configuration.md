## Hashicorp Vault Usage

This document contains some notes about Hashicorp Vault usage in Bluvalt.


## Setting up an environment for Hashicorp Vault

Usually, you should follow the below instructions.

#### Step1:

Install and setup Hashicorp Vault with version [Hashicorp Vault v1.7.1] (https://releases.hashicorp.com/vault/1.7.1/vault_1.7.1_linux_amd64.zip).

```
sudo apt-get update -y
sudo apt-get install zip unzip -y
```

```
wget https://releases.hashicorp.com/vault/1.7.1/vault_1.7.1_linux_amd64.zip
```

```
sudo unzip vault_1.7.1_linux_amd64.zip
```

```
mv vault /usr/bin
```

```
sudo mkdir /etc/vault
```

```
sudo mkdir -p /var/lib/vault/data
```

#### Step2:

- Create and configure `config.hcl` with S3 bucket as storage in `/etc/vault/config.hcl`.

```
 vi /etc/vault/config.hcl
```

```
disable_cache = true
disable_mlock = true
ui = true
listener "tcp" {
   address          = "0.0.0.0:8200"
   tls_disable      = 1
}
storage "s3" {
  access_key = $access_key [provide your s3 access_key]
  secret_key = $secret_key [provide your s3 secret_key]
  region     = "xxxx" [provide your s3 default Region]
  endpoint   = "https://api-object.bluvalt.com:8082"
  bucket     = $bucket_name [Provide your Bucket name here]
}
api_addr         = "http://0.0.0.0:8200"
max_lease_ttl         = "10h"
default_lease_ttl    = "10h"
cluster_name         = "vault"
raw_storage_endpoint     = true
disable_sealwrap     = true
disable_printable_check = true
```

#### Step3:

Create and configure `vault.service` in `/etc/systemd/system/vault.service`.

```
vi /etc/systemd/system/vault.service
```

```
[Service]
ProtectSystem=full
ProtectHome=read-only
PrivateTmp=yes
PrivateDevices=yes
SecureBits=keep-caps
AmbientCapabilities=CAP_IPC_LOCK
NoNewPrivileges=yes
ExecStart=/usr/bin/vault server -config=/etc/vault/config.hcl
ExecReload=/bin/kill --signal HUP 
KillMode=process
KillSignal=SIGINT
Restart=on-failure
RestartSec=5
TimeoutStopSec=30
StartLimitBurst=3
LimitNOFILE=6553
 
[Install]
WantedBy=multi-user.target
```

#### Step4:

Commands to run to `enable and start the Vault Service`.

```
systemctl daemon-reload
```

```
systemctl start vault
```

```
systemctl enable vault
```

```
systemctl status vault
```

#### Step5:

Once vault running successfully with zero errors. Export `VAULT_ADDR` environment variable before you initialize Vault Server.

```
export VAULT_ADDR=http://<IPaddress>:8200
```
#### Step6:
Intialise the vault server, you will get unsealed keys and Root Token

```
vault operator init
```
### Step7:
To unseal the keys and Login with Root Token

```
vault operator unseal <keys>
```
```
vault login <Root Token>
```
### Step8:
Enable KV Secret engine to insert secrets and list the Secret engines 

```
vault secrets enable -path=kv kv
```

```
vault secrets list
```
### Step9:
Insert the secrets
```
vault kv put kv/<secretpath> Username=<username>
```
### Step10:
Retrieving the secrets 
```
curl -H "X-Vault-Token:{{ <RootToken> }}" -X GET http://{{ <IPaddress> }}:8200/v1/kv/<secretpath>/Username
```

`NOTE`:
Refer to the following links for Installation of Vault.
[vault Installation] (https://www.virtualizationhowto.com/2021/01/how-to-install-hashicorp-vault-on-ubuntu-20-04/)
[S3 configuration for Vault] (https://www.vaultproject.io/docs/configuration/storage/s3)


