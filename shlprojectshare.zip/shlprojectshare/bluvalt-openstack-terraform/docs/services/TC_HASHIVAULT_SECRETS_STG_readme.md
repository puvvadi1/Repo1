## HASHICORP VAULT SERVICE USAGE

This document contains some notes about `Hashicorp vault secrets of TC Applications` used in Bluvalt.


##### Secrets for S3 Bluvalt 
- Inserting the `Bluvalt S3 bucket` secrets [Access_key_Id,Secret_Access_key_Id and Region] to `Hashicorp Vault`.

```
vault kv put kv/tc-s3/AWS_ACCESS_KEY_ID AWS_ACCESS_KEY_ID=XXXX
```

```
vault kv put kv/tc-s3/AWS_SECRET_ACCESS_KEY AWS_SECRET_ACCESS_KEY=XXXX
```

```
vault kv put kv/tc-s3/AWS_DEFAULT_REGION AWS_DEFAULT_REGION=XXXX
```

- Retrieving the `S3 Bluvalt bucket` secrets [Access_key_Id, Secret_Access_key_Id and Region] from vault using `CURL-API`.

```
curl -H "X-Vault-Token: <Hashivault_Root_Token> " -X GET http://<Hashivault_IPaddress>/v1/kv/tc-s3/AWS_ACCESS_KEY_ID
```

```
curl -H "X-Vault-Token: <Hashivault_Root_Token> " -X GET http://<Hashivault_IPaddress>/v1/kv/tc-s3/AWS_SECRET_ACCESS_KEY
```

```
curl -H "X-Vault-Token: <Hashivault_Root_Token> " -X GET http://<Hashivault_IPaddress>/v1/kv/tc-s3/AWS_DEFAULT_REGION
```

##### Secrets for TC-WINDOWS Application in Bluvalt.
- Inserting Secrets for `TC-Windows` application into `Hashicorp Vault`.

```
vault kv put /kv/tc-windows/WIN_USER_PASSWORD  WIN_USER_PASSWORD=XXXX
```
```
vault kv put /kv/tc-windows/TCPASSWORD TCPASSWORD=XXXX
```

- Retrieving Secrets for `TC-Windows` application from `Hashicorp Vault`.
```
curl -H "X-Vault-Token: <Hashivault_Root_Token> " -X GET http://<Hashivault_IPaddress>/v1/kv/tc-windows/WIN_USER_PASSWORD
```
```
curl -H "X-Vault-Token: <Hashivault_Root_Token> " -X GET http://<Hashivault_IPaddress>/v1/kv/tc-windows/TCPASSWORD
```

##### Secrets Common for TC Applications in Bluvalt.
- Inserting Secrets for `TC Applications`  into `Hashicorp Vault` which is common for both `Linux and Windows Application`.

```
vault kv put /kv/tc-common/CROWDSTRIKE_CID  CROWDSTRIKE_CID=XXXX
```
```
vault kv put /kv/tc-common/RAPID7_CUSTOMTOKEN RAPID7_CUSTOMTOKEN=XXXX
```
```
vault kv put /kv/tc-common/DATADOG_APIKEY DATADOG_APIKEY=XXXX
```

- Retrieving data for `TC Applications` from `Hashicorp Vault` which is common for both `Linux and Windows Applications`.

```
curl -H "X-Vault-Token: <Hashivault_Root_Token> " -X GET http://<Hashivault_IPaddress>/v1/kv/tc-common/CROWDSTRIKE_CID
```
```
curl -H "X-Vault-Token: <Hashivault_Root_Token> " -X GET http://<Hashivault_IPaddress>/v1/kv/tc-common/RAPID7_CUSTOMTOKEN
```
```
curl -H "X-Vault-Token: <Hashivault_Root_Token>  " -X GET http://<Hashivault_IPaddress>/v1/kv/tc-common/DATADOG_APIKEY
```
