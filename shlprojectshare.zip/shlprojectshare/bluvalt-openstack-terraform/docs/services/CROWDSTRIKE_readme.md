## CROWDSTRIKE SERVICE USAGE

This document contains some notes about CROWDSTRIKE Service in Bluvalt.


Usually, you should follow the below instructions.

#### Step1:

Inserting the `CrowdStrike Binaries` to s3.

```
aws s3api --endpoint-url https://<XXX> --profile profilename put-object --bucket <BUCKETNAME> --key falcon-sensor_6.12.0-10912_amd64.deb --body "D:/XXXXXX"
```
#### Step2:

Retrieving `CrowdStrike Binaries` from s3 and copying to destination.

```
sudo aws s3api --endpoint-url https://<XXX> get-object --bucket <BUCKETNAME> --key falcon-sensor_6.12.0-10912_amd64.deb /tmp/crowdstrike/falcon-sensor_6.12.0-10912_amd64.deb
```

#### Step3:

Commands to Execute and start the `CrowdStrike service`.

```
/opt/CrowdStrike/falconctl -s --cid=XXX
```

