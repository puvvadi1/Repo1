## DNS Service
This document contains some notes about DNS Service in Bluvalt.

## Setting up an environment for DNS
Usually, you should follow the below instructions.

#### Step1:
Updating packages and Installing Bind on DNS Server.

```
 sudo apt-get update -y
```
```
sudo apt-get install bind9 bind9utils bind9-doc -y
```
#### Step2:
#### Configuring the Primary DNS Server
BIND’s configuration consists of multiple files:
1. named.conf.options
2. named.conf.local

#### Configuring the Options File
Creating a new ACL (access control list) block called “trusted”. This is where we will define a list of clients that we will allow recursive DNS queries and adding the primary DNS Ip on listen on. 

```
sudo vi /etc/bind/named.conf.options
```
#### Configuring the Local File
Adding the Forward and Reverse zones

```
sudo vi /etc/bind/named.conf.local
```
#### Step3:
Let’s create the directory where our zone files will reside. According to our named.conf.local configuration, that location should be /etc/bind/zones:

```
sudo mkdir /etc/bind/zones
```

#### Step4:
#### Creating the Forward Zone File

```
sudo cp /etc/bind/db.local /etc/bind/zones/xxxx.xxx.xx.xxx
```
```
sudo vi /etc/bind/zones/xxxx.xxx.xx.xxx
```

#### Step5:
#### Creating the Reverse Zone File

```
sudo cp /etc/bind/db.127 /etc/bind/zones/xxxx.xxx.xx.xxx
```
```
sudo vi /etc/bind/zones/xxxx.xxx.xx.xxx
```

#### Step6:
#### Updating the resolv.conf file with DNS IP

```
sudo vi /etc/resolv.conf
```
`Note`: You should configure your name servers(ns1) and search domain in the list:

```
nameserver xxxx.xxx.xx.xxx   #ns1 ip
search     xxx.xx.xxx        #domain name
```

#### Restarting BIND
```
sudo systemctl restart bind9
```