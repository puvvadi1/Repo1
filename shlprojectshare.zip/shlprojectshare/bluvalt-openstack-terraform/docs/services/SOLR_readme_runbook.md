
## SOLR SERVICE

This document contains some notes about SOLR Service in Bluvalt.

Usually, you should follow the below instructions.

#### Step1:

Inserting the SOLR-server to s3.
```
aws s3api --endpoint-url https://<XXX> --profile profilename put-object --bucket <BUCKETNAME> --key solr-container-code.zip  --body "D:/XXXXXX"
```

#### Step2:
Retrieving SOLR-server from s3
```
aws s3api --endpoint-url https://<XXX> get-object --bucket <BUCKETNAME> --key solr-container-code.zip  ./solr-container-code.zip 
```

#### Step3:

Install unzip and unzip the solr-container-code.zip 

```
sudo apt-get install zip unzip -y
```
```
sudo unzip solr-container-code.zip 
```

### Step4:
Install docker, build and run the solr-container  master and slave
```
sudo apt install docker.io -y
```

```
sudo docker image build --build-arg MASTER=true --build-arg SLAVE=false --build-arg SOLR_URL=talentcentral.sa.shl.domains -t tc-solr-img-master /tmp/solr-container-code
```

```
sudo docker image build --build-arg MASTER=false --build-arg SLAVE=true --build-arg SOLR_URL=talentcentral.sa.shl.domains -t tc-solr-img-slave /tmp/solr-container-code
```

```
sudo docker container run --name tc-solr-cont-master -p 8984:8983 -d tc-solr-img-master
```

```
sudo docker container run --name tc-solr-cont-slave -p 8983:8983 -d tc-solr-img-slave
```
### Step5:

List the containers
```
sudo docker ps -a
```
