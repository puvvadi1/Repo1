## Saudi Bluvalt infrastructure

This document contains some notes about our infrastructure deployed in Bluvalt.

## Structure

This project contains:

- `terraform:` all the infrastructure code per environment
- `vaults(Hashicorp Vault):` all secrets per environment
- `scripts:` various scripts(, Ansible, Powershell)
- `jobs:` contains bamboo pipeline jobs that need to be run to deploy applications.

An environment is defined by the following convention:`<bluvalt_shortregion>/<env_type>`Where:

- `bluvalt_shortregion` is the full region defined by the Cloud provider and where the environment is deployed ( eg, riyadh2)

- `env_type` is the type of the environment (eg, stg, prod)


## Creating/Updating an environment

Usually, you should follow the below instructions.

#### Step1:

Install and setup terraform with version [Terraform v0.12.28](https://releases.hashicorp.com/terraform/0.12.28/).

#### Step2:

Activate your bluvalt cloud credentials like `openstack_user_name`,`openstack_tenant_name`, `openstack_user_password` (eg,`saudi-cloudy/bluvalt-openstack-terraform/riyadh-2/staging/variables.tf`).

#### Step3:

Prepare the desired environment by updating the respective variables(will make it as parameters soon for bamboo pipelies) for Bluvalt (eg, `saudi-cloudy/bluvalt-openstack-terraform/riyadh-2/staging/variables.tf`).

#### Step4:

Terraform plan and apply changes.

```
$ pwd
/path/to/bluvalt-openstack-terraform/riyadh-2/staging
```
```
terraform init
```
```
terraform plan --target=module.module_name --out=terraform.plan	   
For example, terraform plan --target=module.network --out=terraform.plan
```
```
terraform apply terraform.plan
```


## Saudi Bluvalt infra build scripts

Infrastructure build scripts for Saudi Bluevalt. A combination of Terraform, , Ansible and Powershell
## Testing build scripts

A Vagrantfile has been provided which will start an Ubuntu 20 (focal) server that you can test your build scripts in
Assuming you have [Vagrant](https://www.vagrantup.com/) installed and configured simply:

```
vagrant up

# then to get in
vagrant ssh

# once in, this directory is mounted in /vagrant eg
$(cd /vagrant && ls -alh)

# machine is hardcoded to listen on 10.0.0.10

# to kill
vagrant destroy -f
```