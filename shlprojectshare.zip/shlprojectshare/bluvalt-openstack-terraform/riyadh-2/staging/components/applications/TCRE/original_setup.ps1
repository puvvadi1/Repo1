<powershell>

# Copy Install files to c:\installs #
Write-Host "Copying Install Zips.."
aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket win-dependencies --key tcnet.zip  C:\installs\tcnet.zip

Expand-Archive -LiteralPath c:\installs\tcnet.zip -DestinationPath c:\installs\tcnet -force
Move-Item -Path C:\installs\tcnet\tcnet\* -Destination C:\installs\
Remove-Item -Path C:\installs\tcnet\tcnet

# Install Roles for TCNet #
Write-Host "Installing roles and features"
Import-Module servermanager
Import-Csv C:\installs\roles.csv | ForEach-Object{Add-WindowsFeature $_.name  }
# End Install Roles for TCNet #

# Install MS Stuff #
Write-Host "Installing MS Build Packages"
Start-Process "c:\installs\msbuild1.msi" /qn -Wait
Start-Process "c:\installs\msbuild2.msi" /qn -Wait
Start-Process "c:\installs\msxml.msi" /qn -Wait
Start-Process "c:\installs\webdeploy.msi" /qn -Wait
Set-location c:\Installs
.\dotnet223 /install /norestart /quiet 
start-sleep 10
# End Install MS Stuff #

# Install fonts #
Write-Host "Installing MS Fonts"
c:\installs\Add-Font.ps1 -path "c:\installs\fonts"
Write-Host "Finished Installing MS Fonts"



</powershell>