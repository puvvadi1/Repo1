param ($hashi_vault_root_token,$hashi_vault_server_ip)

# Extract zip for module #
Expand-Archive -LiteralPath c:\installs\tcre.zip -DestinationPath d:\ -force
# End Extract zip for module #

# Copy scripts and Desktop Icons #
Remove-Item C:\users\public\desktop\* -force
copy-item -path "d:\desktop\*" -destination "c:\users\public\desktop\" -recurse
# End Copy scripts and Desktop Icons #


# Setup Local User #
$TCPassword=$(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-common/TCPASSWORD  | ConvertFrom-Json ).data).TCPASSWORD )
$DOPassword=$(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-common/TCPASSWORD  | ConvertFrom-Json ).data).TCPASSWORD )

$UserAccount = Get-LocalUser -Name "devops-s"
$SecurePassword=ConvertTo-SecureString $DOPassword -asplaintext -force 
$UserAccount | Set-LocalUser -Password $SecurePassword -PasswordNeverExpires 1

$UserAccount = Get-LocalUser -Name "tomcat-s"
$SecurePassword=ConvertTo-SecureString $TCPassword -asplaintext -force 
$UserAccount | Set-LocalUser -Password $SecurePassword -PasswordNeverExpires 1

$UserAccount = Get-LocalUser -Name "Administrator"
$UserAccount | Set-LocalUser -PasswordNeverExpires 1
# End Setup Local User #

# Install ReportGenerator #
mkdir d:\logs
Set-Location D:\AppServer
$DeployProject=$(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-windows/DEPLOYPROJECT  | ConvertFrom-Json ).data).DEPLOYPROJECT )
C:\Windows\Microsoft.NET\Framework64\v3.5\msbuild.exe $DeployProject /p:DomainName='.' /p:Environment='default' /p:SVC-SODA-ADMIN-APP-PWD=$TCPassword
start-sleep 40
cmd /c sc.exe config "SodaReportGenerator" obj= ".\tomcat-s" password= $TCPassword
# End Install ReportGenerator #

# Configure TC Report Services #
function Update-Config
{
    param([string]$confFile, [string]$oldText, [string]$newText)

    try{
    $configContent = Get-Content $confFile
    $configContent = $configContent -Replace($oldText,$newText)
    $configContent | Set-Content -Path $confFile -Encoding UTF8
	}catch [Exception] {
		$line = $_.InvocationInfo.ScriptLineNumber.ToString()
		$ex = $_.Exception.ToString()
		Write-Host "Error at line: $line" 
		Write-Host $ex 
		Exit;
	};

} 

$TCPassword=$(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-common/TCPASSWORD  | ConvertFrom-Json ).data).TCPASSWORD )
$REDBServer=$(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-windows/REDBSERVER | ConvertFrom-Json ).data).REDBSERVER  )
$TCURL=$(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-windows/TCURL  | ConvertFrom-Json ).data).TCURL )

$tcre_conf = "C:\Program Files\SHL\SODA\ReportEngine\ReportGenerator\SHL.ReportEngine.ReportGenerator.Host.exe.config"

Update-Config $tcre_conf "#domainurl#" $TCURL 
Update-Config $tcre_conf "#REDBServer#" $REDBServer 
Update-Config $tcre_conf "#REPassword#" $TCPassword 

# Datadog Config #
$envString1 = $(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/windows-tcbr/STACKPROFILE | ConvertFrom-Json ).data).STACKPROFILE)
$envString = "tc_" + $envString1
$hostnamedefault = "hostname: NOT-SET"
$hostname = hostname
$hostnamedd= "hostname: $hostname"
$tagdefault = "- system:NOT-SET"
$tags = @"
- system:talentcentral
- application:talentcentral
- env:$envString
- tcappcode:br
- tcappname:bulkreporting
- platform:bluvalt
"@
$ddconf = Get-Content "C:\programdata\datadog\datadog.yaml"
$ddconf = $ddconf -Replace ($tagdefault,$tags) 
$ddconf = $ddconf -Replace ($hostnamedefault,$hostnamedd)
$ddconf = $ddconf -Replace ("5000","8000")
$ddconf = $ddconf -Replace ("5001","8001")
$ddconf = $ddconf -Replace ("5002","8002")
$ddconf = $ddconf -Replace ("5005","8005")
$ddconf | Set-Content -Path "C:\programdata\datadog\datadog.yaml"

$Region=$(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-s3/AWS_DEFAULT_REGION | ConvertFrom-Json ).data).AWS_DEFAULT_REGION)

$ACCESSKEY=$(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-s3/AWS_ACCESS_KEY_ID | ConvertFrom-Json ).data).AWS_ACCESS_KEY_ID)

$SECRETKEY=$(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-s3/AWS_SECRET_ACCESS_KEY | ConvertFrom-Json ).data).AWS_SECRET_ACCESS_KEY) 

aws configure set region $Region --profile default
 
aws configure set aws_access_key_id $ACCESSKEY --profile default
 
aws configure set aws_secret_access_key $SECRETKEY --profile default

aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket testbucket3 --key tcbr_http_check.d.txt C:\bootstrap\tcbr_http_check.d.txt
aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket testbucket3 --key tcbr_windows_service.d.txt C:\bootstrap\tcbr_windows_service.d.txt

Copy-Item "C:\bootstrap\tcbr_http_check.d.txt" -Destination "C:\ProgramData\Datadog\conf.d\http_check.d\conf.yaml" -force;
Copy-Item "C:\bootstrap\tcbr_windows_service.d.txt" -Destination "C:\ProgramData\Datadog\conf.d\windows_service.d\conf.yaml" -force;

Copy-Item "C:\bootstrap\iis.d_conf.txt" -Destination "c:\ProgramData\Datadog\conf.d\iis.d\conf.yaml" -force;
Copy-Item "C:\bootstrap\disk.d_conf.txt" -Destination "c:\ProgramData\Datadog\conf.d\disk.d\conf.yaml" -force;

Set-Service -Name DatadogAgent -StartupType "Automatic"
# End Datadog Config #

# Cleanup Install Files #
#Remove-item 'c:\installs' -Recurse
#Remove-item 'd:\desktop' -Recurse
# End Cleanup Install Files #

& c:\installs\test_dns.ps1 $hashi_vault_root_token $hashi_vault_server_ip

#Restart-Computer -force
# End Of Script #