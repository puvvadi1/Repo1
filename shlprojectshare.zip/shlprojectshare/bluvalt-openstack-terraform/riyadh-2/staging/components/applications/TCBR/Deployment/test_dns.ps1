param ($hashi_vault_root_token,$hashi_vault_server_ip)

$dnsip = $(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-windows/DNS_SERVER_IP | ConvertFrom-Json ).data).DNS_SERVER_IP)

$dnsip1 = $(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-windows/DNS_SERVER_IP1 | ConvertFrom-Json ).data).DNS_SERVER_IP1)

$intix = Get-NetRoute | % { Process { If (!$_.RouteMetric) { $_.ifIndex } } };

Set-DNSClientServerAddress -interfaceIndex $intix -ServerAddresses ("$dnsip","$dnsip1");

Restart-Computer -force
