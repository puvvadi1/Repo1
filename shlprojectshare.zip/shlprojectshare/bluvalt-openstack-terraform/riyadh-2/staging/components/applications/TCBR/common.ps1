<powershell>

Remove-Item alias:curl

$Password=$(((curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-windows/WIN_USER_PASSWORD | ConvertFrom-Json ).data).WIN_USER_PASSWORD)
 
net user Administrator $Password

Invoke-WebRequest -Uri "https://awscli.amazonaws.com/AWSCLIV2.msi" -Outfile C:\AWSCLIV2.msi
 
$arguments = "/i `"C:\AWSCLIV2.msi`" /quiet"
 
Start-Process msiexec.exe -ArgumentList $arguments -Wait
 
$env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine")

$Region=$(((curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-s3/AWS_DEFAULT_REGION | ConvertFrom-Json ).data).AWS_DEFAULT_REGION)

$ACCESSKEY=$(((curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-s3/AWS_ACCESS_KEY_ID | ConvertFrom-Json ).data).AWS_ACCESS_KEY_ID)

$SECRETKEY=$(((curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-s3/AWS_SECRET_ACCESS_KEY | ConvertFrom-Json ).data).AWS_SECRET_ACCESS_KEY) 

aws configure set region $Region --profile default
 
aws configure set aws_access_key_id $ACCESSKEY --profile default
 
aws configure set aws_secret_access_key $SECRETKEY --profile default
 
# Dsiable User Account Control #
Write-Host "Disabling UAC..."
New-ItemProperty -Path HKLM:Software\Microsoft\Windows\CurrentVersion\Policies\System -Name EnableLUA -PropertyType DWord -Value 0 -Force
New-ItemProperty -Path HKLM:Software\Microsoft\Windows\CurrentVersion\Policies\System -Name ConsentPromptBehaviorAdmin -PropertyType DWord -Value 0 -Force
Write-Host "Finished Disabling UAC..."

# Disable IE ESC #
Write-Host "Disabling Disabling Internet Explorer ESC"
function Disable-InternetExplorerESC {
    $AdminKey = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}"
    $UserKey = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}"
    Set-ItemProperty -Path $AdminKey -Name "IsInstalled" -Value 0 -Force
    Set-ItemProperty -Path $UserKey -Name "IsInstalled" -Value 0 -Force
    Remove-ItemProperty -Path $AdminKey -Name "IsInstalled" -Force
    Remove-ItemProperty -Path $UserKey -Name "IsInstalled" -Force
}
Disable-InternetExplorerESC
Write-Host "Finished Disabling Disabling Internet Explorer ESC"

# Disable Firewall #
Write-Host "Disabling Windows Firewall..."
Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled False
Write-Host "Finished Disabling Windows Firewall..."

#Remove Windows Defender #
Write-Host "Removing Windows Defender..."
Uninstall-WindowsFeature -Name Windows-Defender
Write-Host "Finished Removing Windows Defender..."

# Disable Services #
Write-Host "Disabling Themes..."
Set-Service Themes -StartupType Disable
Write-Host "Finished Disabling Themes..."

# Set PowerPlan to High Performance #
Write-Host "Setting High Performance PowerPlan..."
Try {
    $HighPerf = powercfg -l | ForEach-Object{if($_.contains("High performance")) {$_.split()[3]}}
    $CurrPlan = $(powercfg -getactivescheme).split()[3]
    if ($CurrPlan -ne $HighPerf) {powercfg -setactive $HighPerf}
} Catch {
    Write-Warning -Message "Unable to set power plan to high performance"
}
Write-Host "Finished Setting High Performance PowerPlan..."

mkdir C:\installs

mkdir C:\bootstrap

aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket win-dependencies --key disk-part.ps1 C:\disk-part.ps1
 
aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket win-dependencies --key iis.d_conf.txt  C:\bootstrap\iis.d_conf.txt

aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket win-dependencies --key disk.d_conf.txt  C:\bootstrap\disk.d_conf.txt

aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket testbucket3 --key test_dns.ps1 C:\installs\test_dns.ps1

aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket testbucket3 --key original_setup.ps1 C:\installs\original_setup.ps1
 
aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket testbucket3 --key original_winrm.ps1 C:\installs\original_winrm.ps1

aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket testbucket3 --key tcbr_module.ps1 C:\bootstrap\module.ps1

aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket testbucket3 --key tcbr_tc_common.ps1 C:\bootstrap\tc_common.ps1

aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket win-dependencies --key npp.exe C:\installs\npp.exe

aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket win-dependencies --key 7z.exe C:\installs\7z.exe

aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket win-dependencies --key idr-windows.zip C:\installs\idr-windows.zip

aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket win-dependencies --key cs-windows.zip C:\installs\cs-windows.zip

aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket win-dependencies --key Agent.zip C:\installs\agent.zip

aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket win-dependencies --key cdagent.msi C:\installs\cdagent.msi

aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket win-dependencies --key datadog-agent-6.msi C:\installs\datadog-agent-6.msi

aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket win-dependencies --key datadog-dotnet-apm.msi C:\installs\datadog-dotnet-apm.msi

aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket win-dependencies --key ConfigureRemotingForAnsible.ps1 C:\installs\ConfigureRemotingForAnsible.ps1

Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process
 
powershell.exe 'C:\disk-part.ps1'

# Install 7zip #
Write-Host "Installing 7zip..."
c:\installs\7z.exe /S | out-null
Write-Host "Finished Installing 7zip..."

# Install Notepad++ #
Write-Host "Installing Notepad++..."
c:\installs\npp.exe /S | out-null
Write-Host "Finished Installing Notepad++..."

$RAPID7_CUSTOMTOKEN=$(((curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-common/RAPID7_CUSTOMTOKEN | ConvertFrom-Json ).data).RAPID7_CUSTOMTOKEN)

# Install Rapid7 #
Write-Host "Installing Rapid7 ..."
Expand-Archive -LiteralPath c:\installs\idr-windows.zip -DestinationPath c:\installs\idr -force
Start-Process C:\Windows\System32\msiexec.exe -wait -ArgumentList "/i c:\installs\idr\agentInstaller-x86_64.msi /l*v insight_agent_install_log.log CUSTOMCONFIGPATH=C:\Rapid7\Depencies CUSTOMTOKEN=$RAPID7_CUSTOMTOKEN /quiet /qn"
Write-Host "Finished Installing Rapid7..."

$CROWDSTRIKE_CID=$(((curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-common/CROWDSTRIKE_CID | ConvertFrom-Json ).data).CROWDSTRIKE_CID)

# Install Crowdstrike #
Write-Host "Installing Crowdstrike ..."
Expand-Archive -LiteralPath c:\installs\cs-windows.zip -DestinationPath c:\installs -force
Start-Process "C:\installs\WindowsSensor.exe" -ArgumentList "/install /quiet /norestart CID=$CROWDSTRIKE_CID "
Write-Host "Finished Installing Crowdstrike..."

# Extract Cloudwatch Agent #
Write-Host "Extracting Cloudwatch Agent..."
Expand-Archive -LiteralPath c:\installs\agent.zip -DestinationPath c:\bootstrap\Agent -force
Write-Host "Finished Extracting Cloudwatch Agent..."

# Install CodeDeploy Agent #
Write-Host "Installing Code Deploy Agent..."
Start-Process C:\Windows\System32\msiexec.exe -wait -ArgumentList "/qn /i c:\installs\cdagent.msi"
Write-Host "Finished Installing Code Deploy Agent..."

$DATADOG_APIKEY=$(((curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-common/DATADOG_APIKEY | ConvertFrom-Json ).data).DATADOG_APIKEY)

# install Datadog #
Write-Host "Installing DataDog..."
$tags = "system:NOT-SET"
Start-Process C:\Windows\System32\msiexec.exe -wait -ArgumentList "/qn /i c:\installs\datadog-agent-6.msi APIKEY=""$DATADOG_APIKEY"" HOSTNAME=""NOT-SET"" APM_ENABLED=""true"" LOGS_ENABLED=""true"" TAGS=""$tags"""
start-sleep -s 10
Set-Service -Name DatadogAgent -StartupType Manual
Write-Host "Finished Installing DataDog..."

# install Datadog APM #
Write-Host "Installing DataDog Trace APM..."
Start-Process msiexec.exe -Wait -ArgumentList "/qn /i c:\installs\datadog-dotnet-apm.msi /norestart"
Write-Host "Finished Installing DataDog Trace APM..."

#ansible script
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$url = "c:\installs\ConfigureRemotingForAnsible.ps1"
$file = "$env:temp\ConfigureRemotingForAnsible.ps1"
(New-Object -TypeName System.Net.WebClient).DownloadFile($url, $file)
powershell.exe -ExecutionPolicy ByPass -File $file
winrm enumerate winrm/config/Listener

aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket win-dependencies --key logonasservice.ps1 C:\installs\logonasservice.ps1


# Setup Local User #
$TCPassword=$(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-windows/TCPASSWORD  | ConvertFrom-Json ).data).TCPASSWORD )
$DOPassword=$(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-windows/TCPASSWORD  | ConvertFrom-Json ).data).TCPASSWORD )

#set local username/password
Write-Host "Setting up Tomcat User.."
$Password = ConvertTo-SecureString $TCPassword -AsPlainText -Force
New-LocalUser -Name "tomcat-s" -password $Password -Description "Application User Account" -AccountNeverExpires -confirm:$false
Add-LocalGroupMember -Group "Administrators" -Member "tomcat-s"
c:\installs\logonasservice.ps1 "tomcat-s"
Set-LocalUser -Name 'tomcat-s' -PasswordNeverExpires 1

Write-Host "Setting up Devops User.."
$Password = ConvertTo-SecureString $DOPassword -AsPlainText -Force
New-LocalUser -Name "devops-s" -password $Password -Description "Application User Account" -AccountNeverExpires -confirm:$false
Add-LocalGroupMember -Group "Administrators" -Member "devops-s"
Set-LocalUser -Name 'devops-s' -PasswordNeverExpires 1

Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process -force

& "c:\installs\original_setup.ps1"

Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process -force

& "c:\installs\original_winrm.ps1"

</powershell>