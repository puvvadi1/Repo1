# Install .NetFramework 4.8 #
Write-Host "Installing .NetFramework 4.8..."
Start-Process -FilePath "c:\installs\ndp48-web.exe" -ArgumentList "/q /norestart /log c:\installs\NetFx48_Install.txt" -wait -Verbose
Write-Host "Finished Installing .NetFramework 4.8..."