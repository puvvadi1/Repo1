param ($hashi_vault_root_token,$hashi_vault_server_ip)

# Setup Service #
mkdir d:\logs
Expand-Archive -LiteralPath c:\installs\tcsc.zip -DestinationPath d:\ -force
copy-item -path "d:\desktop\*" -destination "C:\Users\Administrator\desktop\" -recurse
copy-item -path d:\tcsc -recurse -destination c:\windows\system32\inetsrv\backup\tcsc -container -force
restore-webconfiguration tcsc
# End Setup Service #


# Setup Local User #

$TCPassword = $(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-common/TCPASSWORD | ConvertFrom-Json ).data).TCPASSWORD)
$DOPassword = $(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-common/TCPASSWORD | ConvertFrom-Json ).data).TCPASSWORD)

$UserAccount = Get-LocalUser -Name "devops-s"
$SecurePassword=ConvertTo-SecureString $DOPassword -asplaintext -force 
$UserAccount | Set-LocalUser -Password $SecurePassword -PasswordNeverExpires 1

$UserAccount = Get-LocalUser -Name "tomcat-s"
$SecurePassword=ConvertTo-SecureString $TCPassword -asplaintext -force 
$UserAccount | Set-LocalUser -Password $SecurePassword -PasswordNeverExpires 1

$UserAccount = Get-LocalUser -Name "Administrator"
$UserAccount | Set-LocalUser -PasswordNeverExpires 1
# End Setup Local User #

# Datadog config #

$envString =  "tc_" +  $(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/windows-tcpd/STACKPROFILE | ConvertFrom-Json ).data).STACKPROFILE)
$hostnamedefault = "hostname: NOT-SET"

$hostname = hostname
$hostnamedd= "hostname: $hostname"
$tagdefault = "- system:NOT-SET"
$tags = @"
- system:talentcentral
- application:talentcentral
- env:$envString
- tcappcode:sc
- tcappname:scoring
- platform:bluvalt
"@
$ddconf = Get-Content "C:\programdata\datadog\datadog.yaml"
$ddconf = $ddconf -Replace ($tagdefault,$tags) 
$ddconf = $ddconf -Replace ($hostnamedefault,$hostnamedd)
$ddconf | Set-Content -Path "C:\programdata\datadog\datadog.yaml"

$Region=$(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-s3/AWS_DEFAULT_REGION | ConvertFrom-Json ).data).AWS_DEFAULT_REGION)

$ACCESSKEY=$(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-s3/AWS_ACCESS_KEY_ID | ConvertFrom-Json ).data).AWS_ACCESS_KEY_ID)

$SECRETKEY=$(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-s3/AWS_SECRET_ACCESS_KEY | ConvertFrom-Json ).data).AWS_SECRET_ACCESS_KEY) 

aws configure set region $Region --profile default
 
aws configure set aws_access_key_id $ACCESSKEY --profile default
 
aws configure set aws_secret_access_key $SECRETKEY --profile default

aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket testbucket3 --key tcsc_http_check.d.txt C:\bootstrap\tcsc_http_check.d.txt

Copy-Item "C:\bootstrap\tcsc_http_check.d.txt" -Destination "C:\ProgramData\Datadog\conf.d\http_check.d\conf.yaml" -force;
Copy-Item "C:\bootstrap\iis.d_conf.txt" -Destination "c:\ProgramData\Datadog\conf.d\iis.d\conf.yaml" -force;

Set-Service -Name DatadogAgent -StartupType "Automatic"
# End DataDog Config #


# CleanUp Installs #
#Remove-item 'c:\installs' -Recurse
#Remove-item 'd:\desktop' -Recurse
#Remove-item 'd:\tcsc' -Recurse
# End CleanUp Installs #

#Restart-Computer -force
& c:\installs\test_dns.ps1 $hashi_vault_root_token $hashi_vault_server_ip
