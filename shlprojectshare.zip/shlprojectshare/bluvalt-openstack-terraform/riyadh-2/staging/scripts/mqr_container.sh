#!/bin/bash

hashi_vault_root_token=""
hashi_vault_server_ip=""
 
# Initialize parameters specified from command line
while getopts ":t:i:" arg; do
    case "$arg" in
        t)
            hashi_vault_root_token=$OPTARG
            ;;
        i)
            hashi_vault_server_ip=$OPTARG
            ;;
    esac
done
 
sudo apt install awscli -y
sudo apt install jq -y
sudo apt-get install zip unzip -y
sudo apt install docker.io -y

AWS_ACCESS_KEY_ID=`curl -H "X-Vault-Token:$hashi_vault_root_token" -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-s3/AWS_ACCESS_KEY_ID | jq '.data.AWS_ACCESS_KEY_ID' | sed 's/"//g'`
AWS_SECRET_ACCESS_KEY=`curl -H "X-Vault-Token:$hashi_vault_root_token" -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-s3/AWS_SECRET_ACCESS_KEY | jq '.data.AWS_SECRET_ACCESS_KEY' | sed 's/"//g'`
AWS_DEFAULT_REGION=`curl -H "X-Vault-Token:$hashi_vault_root_token" -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-s3/AWS_DEFAULT_REGION | jq '.data.AWS_DEFAULT_REGION' | sed 's/"//g'`
DB_USER=`curl -H "X-Vault-Token:$hashi_vault_root_token" -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-services/DB_USER | jq '.data.DB_USER' | sed 's/"//g'`
DB_PASSWORD=`curl -H "X-Vault-Token:$hashi_vault_root_token" -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-services/DB_PASSWORD | jq '.data.DB_PASSWORD' | sed 's/"//g'`
DB_IP=`curl -H "X-Vault-Token:$hashi_vault_root_token" -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-services/DB_IP | jq '.data.DB_IP' | sed 's/"//g'`

echo "AWS_ACCESS_KEY_ID=$AWS_ACCESS_KEY_ID" >> /etc/environment;
echo "AWS_SECRET_ACCESS_KEY=$AWS_SECRET_ACCESS_KEY" >> /etc/environment;
echo "AWS_DEFAULT_REGION=$AWS_DEFAULT_REGION" >> /etc/environment;
 
sudo bash /etc/environment

sudo aws s3api --endpoint-url https://api-object.bluvalt.com:8082 get-object --bucket tc-application-artifacts --key mqr/mqr-container.zip  /tmp/mqr-container.zip

sudo unzip /tmp/mqr-container.zip -d /tmp/mqr-container

sudo docker image build  -t tc-mqr-img /tmp/mqr-container

sudo docker container run \
-e MQ_API_CONTEXT='/mq-api' \
-e CONTENT_DB_DRIVER='net.sourceforge.jtds.jdbc.Driver' \
-e CONTENT_DB_URL='jdbc:jtds:sqlserver://'$DB_IP':1605/TC_Content' \
-e CONTENT_DB_USER=$DB_USER \
-e CONTENT_DB_PASSWORD=$DB_PASSWORD \
-p 8080:8080 \
--name tc-mqr-cont \
-d tc-mqr-img
