#!/bin/bash

hashi_vault_root_token=""
hashi_vault_server_ip=""
PROFILE = ""
 
# Initialize parameters specified from command line
while getopts ":t:i:p:" arg; do
  case "${arg}" in
    t)
      hashi_vault_root_token=${OPTARG}
      ;;
    i)
      hashi_vault_server_ip=${OPTARG}
      ;;
     p)
      PROFILE=${OPTARG}
      ;; 
   
  esac
done

#!/bin/bash
# to install the nginx internal reverse proxy
# modified 2021-04-28 Jujhar to dockerify thingssu
# Installing docker and enable
sudo apt-get update -y
sudo apt-get install -y docker.io
sudo systemctl enable docker
sudo systemctl start docker

# enable this user to docker without sudo (will have to logout to take effect for next round)
sudo usermod -a -G docker "${USER}"

# we need to grab an nginx default conf as our base template
# simply grab it form a vanilla docker nginx container
dockerId=$(sudo docker run -d nginx)
sleep 1s
sudo docker cp "${dockerId}":/etc/nginx/nginx.conf /etc/nginx.conf
sudo docker cp "${dockerId}":/etc/nginx/conf.d/default.conf /etc/default.conf

sudo docker kill "${dockerId}"

sudo apt-get install resolv* -y

sudo cat <<EOF > /etc/resolvconf/resolv.conf.d/head
nameserver 10.210.16.15
nameserver 10.210.16.55
search sa.shl.domains
EOF

sudo resolvconf -u

# now modify nginx.conf to merge in upstream servers conf in the 'http' section
sudo cat <<EOF > ./upstream.conf.template
    # upstream application servers
    # have to be added in main conf as FOSS nginx doesn't support dynamic lookups

client_max_body_size 500M;
upstream solrmaster {
server talentcentral-solr-master-zone1.sa.shl.domains:8984;
}
upstream solrslave {
server talentcentral-solr-slave-zone1.sa.shl.domains:8983;
} 
upstream cdn {
server talentcentral-cdn-zone1.sa.shl.domains:80;
server talentcentral-cdn-zone2.sa.shl.domains:80;
}

upstream tcad {
server tcad1.sa.shl.domains:8080 max_fails=3 fail_timeout=10s;
server tcad2.sa.shl.domains:8080 max_fails=3 fail_timeout=10s;
}

upstream tcba {
server tcba1.sa.shl.domains:8080 max_fails=3 fail_timeout=10s;
server tcba2.sa.shl.domains:8080 max_fails=3 fail_timeout=10s;
}

upstream tcvp {
server tcvp1.sa.shl.domains:8080 max_fails=3 fail_timeout=10s;
server tcvp2.sa.shl.domains:8080 max_fails=3 fail_timeout=10s;
}

upstream tcai {
server integration-talentcentral-ai-zone1.sa.shl.domains:8080 max_fails=3 fail_timeout=10s;
server integration-talentcentral-ai-zone2.sa.shl.domains:8080 max_fails=3 fail_timeout=10s;
}

upstream tcch {
server tcch1.sa.shl.domains:8080 max_fails=3 fail_timeout=10s;
}

upstream tcbr {
server tcbr1.sa.shl.domains:9036 max_fails=3 fail_timeout=10s;
}

upstream tcre {
server tcre1.sa.shl.domains:9036 max_fails=3 fail_timeout=10s;
}

upstream tcsc {
server tcsc1.sa.shl.domains:80 max_fails=3 fail_timeout=10s;
server tcsc2.sa.shl.domains:80 max_fails=3 fail_timeout=10s;
}

upstream tcia {
#server tcia1.sa.shl.domains:80 max_fails=3 fail_timeout=10s;
server tcia2.sa.shl.domains:80 max_fails=3 fail_timeout=10s;
}

upstream tciw {
server tciw1.sa.shl.domains:80 max_fails=3 fail_timeout=10s;
server tciw2.sa.shl.domains:80 max_fails=3 fail_timeout=10s;
}



EOF

# now use some sed magic to munge the two files
# first create a placeholder 'tag' then munge the files using the 'r' feature of sed

sudo sed -i 's/nginx.pid;/nginx.pid;\nload_module \/usr\/lib\/nginx\/modules\/ngx_http_perl_module.so;/' /etc/nginx.conf
#sudo sed -i 's/nginx.pid;/nginx.pid;\nload_module \/usr\/lib\/nginx\/modules\/ngx_http_perl_module.so;\nload_module \/usr\/lib\/nginx\/modules\/ngx_http_redis2_module.so;' /e    tc/nginx.conf
sudo sed -i 's|error_log  /var/log/nginx/error.log warn;|error_log  /var/log/nginx/error.log debug;|g' /etc/nginx.conf
#sudo sed -i 's|access_log  /var/log/nginx/access.log  main;|access_log  /var/log/nginx/access.log debug;|g' /etc/nginx.conf

sudo sed -i 's/http {/http { \n#FROM_UPSTREAM_TEMPLATE/' /etc/nginx.conf
sudo sed -ie '/#FROM_UPSTREAM_TEMPLATE/rupstream.conf.template' /etc/nginx.conf

# our virtualhosts configuration to inject in
cat <<EOF > ./nginx-default.conf

server {
        listen 80 default_server;
        listen [::]:80 default_server;
	root /var/www/html;

        # Add index.php to the list if you are using PHP
        index index.html index.htm index.nginx-debian.html;

        server_name _;
	#return 301 https://$host$request_uri;


	location /cdn {
		if (\$request_uri ~ [A-Z]) {
  	        rewrite ^(.*)\$ https://\$host\$uri_lowercase;
        }
 		proxy_redirect off;
                proxy_set_header Host talentcentral.sa.shl.domains;   
		proxy_pass http://cdn;
	}

	location /admin/integration {
		proxy_redirect off;
		proxy_set_header Host talentcentral.sa.shl.domains;
                proxy_pass http://tcai;
          }

	location /admin {
		proxy_redirect off;
                proxy_set_header Host \$host;
		proxy_pass http://tcad;
	}

	location /player {
		proxy_pass http://tcvp;
	}

	location /opq {
		proxy_pass http://tcvp;
	}

	location /backenddriver {
		proxy_pass http://tcba;
	}

	
	location ~* /primaryscoringservice {
		proxy_pass http://tcsc;
	}

	location ~* /primaryscoringserviceapta {
		proxy_pass http://tcsc;
	}

	location ~* /secondaryscoringservice {
		proxy_pass http://tcsc;
	}
	location ~* /secondaryscoringservicev2 {
                client_max_body_size 500M;
		proxy_pass http://tcsc;
	}

        location /InternalIntegration/DependencyHealthChecks/AppServer {
		proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
                proxy_set_header X-Forwarded-Proto \$scheme;
		proxy_pass http://tcia;
	
	}

	location /integrationtools/dependencyhealthchecks/webserver {
		 proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
                proxy_set_header X-Forwarded-Proto \$scheme;
                proxy_pass http://tciw;
    
	}
	location /integration/ {
		
                proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
                proxy_set_header X-Forwarded-Proto \$scheme;
		proxy_pass http://tciw;

	}
	location /integrationtools/ {
		
		proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
		proxy_set_header X-Forwarded-Proto \$scheme;
		proxy_pass http://tciw;
		proxy_redirect default;
	}
	location /internalintegration/ {
	
                proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
                proxy_set_header X-Forwarded-Proto \$scheme;
		proxy_pass http://tcia;
	
	}
	 location /InternalIntegration/ {
         	
                proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
                proxy_set_header X-Forwarded-Proto \$scheme;
                proxy_pass http://tcia;
	
        }
        location /Integration/ {
        
                proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
                proxy_set_header X-Forwarded-Proto \$scheme;
                proxy_pass http://tciw;
	
        }

        location /IntegrationTools/ {
	
                proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
                proxy_set_header X-Forwarded-Proto \$scheme;
                proxy_pass http://tciw;
		proxy_redirect default;
        }

	location /content {
                proxy_pass http://tcch;
        }
}

server {
       listen 443 ssl ;
       ssl_certificate /etc/ssl/private/fullchain.pem;
       ssl_certificate_key /etc/ssl/private/privkey.pem;
       ssl_protocols TLSv1.2 TLSv1.1 TLSv1;
       server_name _;

       root /var/www/html;
       index index.html index.htm index.nginx-debian.html;

location /cdn {
		if (\$request_uri ~ [A-Z]) {
  	        rewrite ^(.*)\$ https://\$host\$uri_lowercase;
        }
 		proxy_redirect off;
                proxy_set_header Host talentcentral.sa.shl.domains;   
		proxy_pass http://cdn;
	}

	location /admin/integration {
		proxy_redirect off;
		proxy_set_header Host talentcentral.sa.shl.domains;
                proxy_pass http://tcai;
          }

	location /admin {
		proxy_redirect off;
                proxy_set_header Host \$host;
		proxy_pass http://tcad;
	}

	location /player {
		proxy_pass http://tcvp;
	}

	location /opq {
		proxy_pass http://tcvp;
	}

	location /backenddriver {
		proxy_pass http://tcba;
	}

	
	location ~* /primaryscoringservice {
		proxy_pass http://tcsc;
	}

	location ~* /primaryscoringserviceapta {
		proxy_pass http://tcsc;
	}

	location ~* /secondaryscoringservice {
		proxy_pass http://tcsc;
	}
	location ~* /secondaryscoringservicev2 {
                client_max_body_size 500M;
		proxy_pass http://tcsc;
	}
	

        location /InternalIntegration/DependencyHealthChecks/AppServer {
		proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
                proxy_set_header X-Forwarded-Proto \$scheme;
		proxy_pass http://tcia;
	
	}

	location /integrationtools/dependencyhealthchecks/webserver {
		 proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
                proxy_set_header X-Forwarded-Proto \$scheme;
                proxy_pass http://tciw;
             
	}
	location /integration/ {
		
                proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
                proxy_set_header X-Forwarded-Proto \$scheme;
		proxy_pass http://tciw;
		
	}
	location /integrationtools/ {
		
		proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
		proxy_set_header X-Forwarded-Proto \$scheme;
		proxy_pass http://tciw;
		proxy_redirect default;
	}
	location /internalintegration/ {
		
                proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
                proxy_set_header X-Forwarded-Proto \$scheme;
		proxy_pass http://tcia;
	
	}
	 location /InternalIntegration/ {
       
                proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
                proxy_set_header X-Forwarded-Proto \$scheme;
                proxy_pass http://tcia;
		
        }
        location /Integration/ {
       
                proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
                proxy_set_header X-Forwarded-Proto \$scheme;
                proxy_pass http://tciw;
		
        }

        location /IntegrationTools/ {
	
                proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
                proxy_set_header X-Forwarded-Proto \$scheme;
                proxy_pass http://tciw;
		proxy_redirect default;
        }

	location /content {
                proxy_pass http://tcch;
        }
}

server {
    listen 8983;
    server_name _;
    location /solr/collection1/replication {
        proxy_pass http://solrmaster;
    }
    location /solr {
        if (\$request_method = POST ) {
          proxy_pass http://solrmaster;
        }
        proxy_pass http://solrslave;
    }
}

server {
    listen 8984;
    server_name _;
    location /solr {
        proxy_pass http://solrmaster;
    }
}

server {
listen 9036;
server_name _;
location / {
proxy_pass http://tcre;
}
}

server {
listen 9038;
server_name _;
location / {
proxy_pass http://tcbr;
}
}


EOF

sudo cp nginx-default.conf /etc/nginx-default.conf

tee ./perl-regex.conf <<EOF
perl_modules perl/lib;

 

perl_set \$uri_lowercase '
    sub {
            my \$r = shift;
            my \$uri = \$r->uri;
            \$uri = lc(\$uri);
            return \$uri;
   }
';
EOF

####add sudo if required and check script and remove unwanted comments
sudo apt update -y
sudo apt install jq -y
sudo wget https://s3.amazonaws.com/dd-agent/scripts/install_script.sh
#sudo cp install_script.sh /etc/install_script.sh
sudo cp install_script.sh /tmp/
sudo chmod 777 /tmp/install_script.sh

DDAPIKEY=`curl -H "X-Vault-Token:$hashi_vault_root_token" -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/DATADOG_APIKEY | jq '.data.DATADOG_APIKEY' | sed 's/"//g'` 

echo $DDAPIKEY >> /tmp

DD_AGENT_MAJOR_VERSION=7 DD_API_KEY=$DDAPIKEY DD_SITE="datadoghq.com" bash /tmp/install_script.sh

systemctl stop datadog-agent

tee /etc/datadog-agent/datadog.yaml <<EOF
dd_url: https://app.datadoghq.com
api_key: $DDAPIKEY
logs_enabled: true
log_format_json: false
log_level: DEBUG
log_file: /var/log/datadog/agent.log
log_payloads: false
log_to_console: true
log_to_syslog: false
logging_frequency: 20
apm_config:
  enabled: true
logs_config:
  container_collect_all: false
  dd_port: 10516
  dd_url: agent-intake.logs.datadoghq.com
  dev_mode_use_proto: true
  frame_size: 9000
  open_files_limit: 100
  run_path: ""
  tcp_forward_port: -1
tags:
- system:talentcentral
- application:talentcentral
- env:tc_$PROFILE
- tcappcode:tccnnginx
- tcappname:tccnnginx

EOF

chown dd-agent:dd-agent /etc/datadog-agent/datadog.yaml

echo "stream {
server {
listen 26379;
proxy_pass talentcentral-redis-master-zone1.sa.shl.domains:26379;
}
}" >> /etc/nginx.conf

tee /etc/status.conf <<EOF 
server {
  listen 81;
  server_name localhost;
  access_log off;
  allow 127.0.0.1;
  deny all;
location /nginx_status {
    # Choose your status module
    # freely available with open source NGINX
    stub_status;
    # for open source NGINX < version 1.7.5
    # stub_status on;
    # available only with NGINX Plus
    # status;
    # ensures the version information can be retrieved
    server_tokens on;
  }
}

EOF

sudo cp perl-regex.conf /etc/perl-regex.conf
#sudo cp datadog.yaml /etc/datadog-agent/datadog.yaml

#sudo cp status.conf /etc/nginx/conf.d/status.conf

sudo systemctl enable datadog-agent
sudo systemctl restart datadog-agent

# now inject these configs into a nginx container running as a background service
sudo docker run -d --name datadog-agent \
                -e DD_API_KEY=$DDAPIKEY \
                -e DD_LOGS_ENABLED=true \
                -e DD_LOGS_CONFIG_CONTAINER_COLLECT_ALL=true \
                -e DD_LOGS_CONFIG_DOCKER_CONTAINER_USE_FILE=true \
                -e DD_CONTAINER_EXCLUDE="name:datadog-agent" \
                -v /var/run/docker.sock:/var/run/docker.sock:ro \
                -v /var/lib/docker/containers:/var/lib/docker/containers:ro \
                -v /proc/:/host/proc/:ro \
                -v /opt/datadog-agent/run:/opt/datadog-agent/run:rw \
                -v /sys/fs/cgroup/:/host/sys/fs/cgroup:ro \
                gcr.io/datadoghq/agent:latest
                
sudo docker run \
    -d \
    -p 80:80 \
    -p 8983:8983 \
    -p 8984:8984 \
    -p 26379:26379 \
    -p 61617:61617 \
    -p 443:443 \
    -p 9036:9036 \
    -p 9038:9038 \
    -p 81:81 \
    --restart=always \
    -v /etc/nginx.conf:/etc/nginx/nginx.conf:ro \
    -v /etc/nginx-default.conf:/etc/nginx/conf.d/default.conf:ro \
    -v /tmp/install_script.sh:/tmp/install_script.sh:ro \
    -v /etc/perl-regex.conf:/etc/nginx/conf.d/perl-regex.conf:ro \
    -v /home/ubuntu/fullchain.pem:/etc/ssl/private/fullchain.pem:ro \
    -v /home/ubuntu/privkey.pem:/etc/ssl/private/privkey.pem:ro \
    -v /etc/resolv.conf:/etc/resolv.conf:ro \
    -v /etc/datadog-agent/datadog.yaml:/etc/datadog.yaml:ro \
    -v /etc/status.conf:/etc/status.conf:ro \
    nginx:1.21.0-perl \
    nginx-debug -g 'daemon off;'

