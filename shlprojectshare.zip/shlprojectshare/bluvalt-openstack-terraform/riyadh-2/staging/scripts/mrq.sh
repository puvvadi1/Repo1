#!/bin/bash

hashi_vault_root_token=""
hashi_vault_server_ip=""
 
# Initialize parameters specified from command line
while getopts ":t:i:" arg; do
    case "$arg" in
        t)
            hashi_vault_root_token=$OPTARG
            ;;
        i)
            hashi_vault_server_ip=$OPTARG
            ;;
    esac
done


sudo apt install awscli -y
sudo apt install jq -y

sudo apt-get install default-jdk -y
sudo groupadd tomcat
sudo useradd -s /bin/false -g tomcat -d /opt/tomcat tomcat
cd /opt && sudo wget https://archive.apache.org/dist/tomcat/tomcat-9/v9.0.21/bin/apache-tomcat-9.0.21.tar.gz
sudo tar -xvzf apache-tomcat-9.0.21.tar.gz
sudo mv apache-tomcat-9.0.21 /opt/tomcat
cd /opt && sudo chown -R tomcat: tomcat

start sleep 10

sudo chmod o+x /opt/tomcat/
sudo chmod 777 /opt/tomcat/webapps

sudo cat > /etc/systemd/system/tomcat.service <<-EOF
[Unit]
Description=Tomcat 9 Server
After=network.target
[Service]
Type=forking
User=tomcat
Group=tomcat
Environment="JAVA_HOME=/usr/lib/jvm/default-java"
Environment="JAVA_OPTS=-Xms512m -Xmx512m"
Environment="CATALINA_BASE=/opt/tomcat"
Environment="CATALINA_HOME=/opt/tomcat"
Environment="CATALINA_PID=/opt/tomcat/temp/tomcat.pid"
Environment="CATALINA_OPTS=-Xms512M -Xmx1024M -server -XX:+UseParallelGC"
ExecStart=/opt/tomcat/bin/startup.sh
ExecStop=/opt/tomcat/bin/shutdown.sh
UMask=0007
RestartSec=10
Restart=always 
[Install]
WantedBy=multi-user.target
EOF

sudo chmod 777 /etc/systemd/system/tomcat.service 
sudo systemctl daemon-reload

start sleep 10

sudo systemctl start tomcat

sudo apt-get install zip unzip -y

AWS_ACCESS_KEY_ID=`curl -H "X-Vault-Token:$hashi_vault_root_token" -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-s3/AWS_ACCESS_KEY_ID | jq '.data.AWS_ACCESS_KEY_ID' | sed 's/"//g'`
AWS_SECRET_ACCESS_KEY=`curl -H "X-Vault-Token:$hashi_vault_root_token" -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-s3/AWS_SECRET_ACCESS_KEY | jq '.data.AWS_SECRET_ACCESS_KEY' | sed 's/"//g'`
AWS_DEFAULT_REGION=`curl -H "X-Vault-Token:$hashi_vault_root_token" -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-s3/AWS_DEFAULT_REGION | jq '.data.AWS_DEFAULT_REGION' | sed 's/"//g'`
 
echo "AWS_ACCESS_KEY_ID=$AWS_ACCESS_KEY_ID" >> /etc/environment;
echo "AWS_SECRET_ACCESS_KEY=$AWS_SECRET_ACCESS_KEY" >> /etc/environment;
echo "AWS_DEFAULT_REGION=$AWS_DEFAULT_REGION" >> /etc/environment;

APPVERSION=`curl -H "X-Vault-Token: $hashi_vault_root_token " -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/APPVERSION | jq '.data.APPVERSION' | sed 's/"//g'`

sudo bash /etc/environment
mkdir /opt/tomcat/webapps/mq
sudo aws s3api --endpoint-url https://api-object.bluvalt.com:8082 get-object --bucket tc-application-artifacts  --key mqr/${APPVERSION}/mqr.zip /opt/tomcat/webapps/mq/mq.zip

cd /opt/tomcat/webapps/mq/ && sudo unzip mq.zip 

sudo systemctl restart tomcat
