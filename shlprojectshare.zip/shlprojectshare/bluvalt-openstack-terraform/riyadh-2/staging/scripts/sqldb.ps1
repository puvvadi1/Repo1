<powershell>

Remove-Item alias:curl

$Password=$(((curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-windows/WIN_USER_PASSWORD | ConvertFrom-Json ).data).WIN_USER_PASSWORD)
 
net user Administrator $Password

Invoke-WebRequest -Uri "https://awscli.amazonaws.com/AWSCLIV2.msi" -Outfile C:\AWSCLIV2.msi
 
$arguments = "/i `"C:\AWSCLIV2.msi`" /quiet"
 
Start-Process msiexec.exe -ArgumentList $arguments -Wait
 
$env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine")

$Region=$(((curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-s3/AWS_DEFAULT_REGION | ConvertFrom-Json ).data).AWS_DEFAULT_REGION)

$ACCESSKEY=$(((curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-s3/AWS_ACCESS_KEY_ID | ConvertFrom-Json ).data).AWS_ACCESS_KEY_ID)

$SECRETKEY=$(((curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-s3/AWS_SECRET_ACCESS_KEY | ConvertFrom-Json ).data).AWS_SECRET_ACCESS_KEY) 


aws configure set region $Region --profile default
 
aws configure set aws_access_key_id $ACCESSKEY --profile default
 
aws configure set aws_secret_access_key $SECRETKEY --profile default

mkdir C:\installs

aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket win-dependencies --key 7z.exe C:\installs\7z.exe

aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket win-dependencies --key SQL2019-SSEI-Dev.exe C:\installs\SQL2019-SSEI-Dev.exe

aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket win-dependencies --key SSMS-Setup-ENU.exe C:\installs\SSMS-Setup-ENU.exe

</powershell>