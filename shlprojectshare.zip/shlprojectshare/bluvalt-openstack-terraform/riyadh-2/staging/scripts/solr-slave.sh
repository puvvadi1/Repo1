#!/bin/bash
 
hashi_vault_root_token=""
hashi_vault_server_ip=""
 
# Initialize parameters specified from command line
while getopts ":t:i:n:s:d:" arg; do
    case "$arg" in
        t)
            hashi_vault_root_token=$OPTARG
            ;;
        i)
            hashi_vault_server_ip=$OPTARG
            ;;
 
        n)
            dns_srv_ip=${OPTARG}
            ;;
 
        s)
            dns_srv_ip2=${OPTARG}
            ;; 
        d)
            dns_domain=${OPTARG}
            ;;
    esac
done
 
apt update -y
 
#Install and enable resolveconf
apt install resolvconf 
sudo systemctl enable --now resolvconf.service
tee /etc/resolvconf/resolv.conf.d/head <<EOF
nameserver $dns_srv_ip
nameserver $dns_srv_ip2
search $dns_domain
EOF
sudo resolvconf -u
 
 
sudo apt install awscli -y
sudo apt install jq -y
sudo apt-get install zip unzip -y
sudo apt install docker.io -y
 
AWS_ACCESS_KEY_ID=`curl -H "X-Vault-Token:$hashi_vault_root_token" -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-s3/AWS_ACCESS_KEY_ID | jq '.data.AWS_ACCESS_KEY_ID' | sed 's/"//g'`
AWS_SECRET_ACCESS_KEY=`curl -H "X-Vault-Token:$hashi_vault_root_token" -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-s3/AWS_SECRET_ACCESS_KEY | jq '.data.AWS_SECRET_ACCESS_KEY' | sed 's/"//g'`
AWS_DEFAULT_REGION=`curl -H "X-Vault-Token:$hashi_vault_root_token" -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-s3/AWS_DEFAULT_REGION | jq '.data.AWS_DEFAULT_REGION' | sed 's/"//g'`
 
echo "AWS_ACCESS_KEY_ID=$AWS_ACCESS_KEY_ID" >> /etc/environment;
echo "AWS_SECRET_ACCESS_KEY=$AWS_SECRET_ACCESS_KEY" >> /etc/environment;
echo "AWS_DEFAULT_REGION=$AWS_DEFAULT_REGION" >> /etc/environment;
 
sudo bash /etc/environment
 
sudo aws s3api --endpoint-url https://api-object.bluvalt.com:8082 get-object --bucket testbucket3 --key solr-container-code.zip /tmp/solr-container-code.zip
 
sudo unzip /tmp/solr-container-code.zip -d /tmp/solr-container-code
 
sudo docker image build --build-arg MASTER=false --build-arg SLAVE=true --build-arg SOLR_URL=talentcentral.sa.shl.domains -t tc-solr-img-slave /tmp/solr-container-code
 
sudo docker container run --name tc-solr-cont-slave -p 8983:8983 -d tc-solr-img-slave