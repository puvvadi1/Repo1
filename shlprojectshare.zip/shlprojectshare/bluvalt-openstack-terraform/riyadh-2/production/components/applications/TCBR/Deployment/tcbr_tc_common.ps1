param ($hashi_vault_root_token,$hashi_vault_server_ip)
Start-Process "c:\installs\msbuild1.msi" /qn -Wait
Start-Process "c:\installs\msbuild2.msi" /qn -Wait

$DATADOG_APIKEY=$(((curl.exe -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-common/DATADOG_APIKEY | ConvertFrom-Json ).data).DATADOG_APIKEY)

# install Datadog #
Write-Host "Installing DataDog..."
$tags = "system:NOT-SET"
Start-Process C:\Windows\System32\msiexec.exe -wait -ArgumentList "/qn /i c:\installs\datadog-agent-6.msi APIKEY=""$DATADOG_APIKEY"" HOSTNAME=""NOT-SET"" APM_ENABLED=""true"" LOGS_ENABLED=""true"" TAGS=""$tags"""
start-sleep -s 10
Set-Service -Name DatadogAgent -StartupType Manual
Write-Host "Finished Installing DataDog..."

# install Datadog APM #
Write-Host "Installing DataDog Trace APM..."
Start-Process msiexec.exe -Wait -ArgumentList "/qn /i c:\installs\datadog-dotnet-apm.msi /norestart"
Write-Host "Finished Installing DataDog Trace APM..."

# Disable Firewall
Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled False

#Enable WinRM
Enable-PSRemoting -force
Set-Service WinRM -StartMode Automatic
Set-Item WSMan:localhost\client\trustedhosts -value * -force

& c:\bootstrap\module.ps1 $hashi_vault_root_token $hashi_vault_server_ip


