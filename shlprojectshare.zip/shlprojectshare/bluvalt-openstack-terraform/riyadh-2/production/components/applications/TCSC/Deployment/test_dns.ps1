param ($hashi_vault_root_token,$hashi_vault_server_ip)

$dnsip1 = $(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-windows/DNSSERVERIP1 | ConvertFrom-Json ).data).DNSSERVERIP1)

$dnsip2 = $(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-windows/DNSSERVERIP2 | ConvertFrom-Json ).data).DNSSERVERIP2)

$intix = Get-NetRoute | % { Process { If (!$_.RouteMetric) { $_.ifIndex } } };

Set-DNSClientServerAddress -interfaceIndex $intix -ServerAddresses ("$dnsip1","$dnsip2");

Restart-Computer -force
