param ($hashi_vault_root_token,$hashi_vault_server_ip)

#create the logs & deploy folders
mkdir d:\logs
mkdir d:\deploy


$env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine")

$Region=$(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-s3/AWS_DEFAULT_REGION | ConvertFrom-Json ).data).AWS_DEFAULT_REGION)

$ACCESSKEY=$(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-s3/AWS_ACCESS_KEY_ID | ConvertFrom-Json ).data).AWS_ACCESS_KEY_ID)

$SECRETKEY=$(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-s3/AWS_SECRET_ACCESS_KEY | ConvertFrom-Json ).data).AWS_SECRET_ACCESS_KEY) 


aws configure set region $Region --profile default
 
aws configure set aws_access_key_id $ACCESSKEY --profile default
 
aws configure set aws_secret_access_key $SECRETKEY --profile default


$TCPassword = $(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-common/TCPASSWORD | ConvertFrom-Json ).data).TCPASSWORD)
$DOPassword = $(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-common/TCPASSWORD | ConvertFrom-Json ).data).TCPASSWORD)
$UserAccount = Get-LocalUser -Name "devops-s"
$SecurePassword=ConvertTo-SecureString $DOPassword -asplaintext -force 
$UserAccount | Set-LocalUser -Password $SecurePassword -PasswordNeverExpires 1
Set-LocalUser -Name "devops-s" -PasswordNeverExpires 1

$UserAccount = Get-LocalUser -Name "tomcat-s"
$SecurePassword=ConvertTo-SecureString $TCPassword -asplaintext -force 
$UserAccount | Set-LocalUser -Password $SecurePassword -PasswordNeverExpires 1
Set-LocalUser -Name "tomcat-s" -PasswordNeverExpires 1

$UserAccount = Get-LocalUser -Name "Administrator"
$UserAccount | Set-LocalUser -PasswordNeverExpires 1

c:\installs\logonasservice.ps1 "SVC-TCI-INCOMING-APP"
Set-LocalUser -Name "SVC-TCI-INCOMING-APP" -PasswordNeverExpires 1
c:\installs\logonasservice.ps1 "SVC-TCI-INCOMING-WEB"
Set-LocalUser -Name "SVC-TCI-INCOMING-WEB" -PasswordNeverExpires 1
c:\installs\logonasservice.ps1 "SVC-TCI-OUTGOING-APP"
Set-LocalUser -Name "SVC-TCI-OUTGOING-APP" -PasswordNeverExpires 1
c:\installs\logonasservice.ps1 "SVC-TCI-OUTGOING-WEB"
Set-LocalUser -Name "SVC-TCI-OUTGOING-WEB" -PasswordNeverExpires 1

# End Setup Local User #

#Create folder structure for health checks 
$path = "D:\SHL\TalentCentral\Integration\Logs\IISLogs\W3SVC11"
If(!(test-path $path))
{
      New-Item -ItemType Directory -Force -Path $path
}

$path = "D:\SHL\TalentCentral\Integration\Logs\RequestTracing\W3SVC11"
If(!(test-path $path))
{
      New-Item -ItemType Directory -Force -Path $path
}

$IncomingAppUserName = "SVC-TCI-INCOMING-APP"
$IncomingWebUserName = "SVC-TCI-INCOMING-WEB"

$IncomingAppPassword = $(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/windows-tcia/OUTGOINGAPPPASSWORD | ConvertFrom-Json ).data).OUTGOINGAPPPASSWORD)
$IncomingWebPassword = $(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/windows-tcia/OUTGOINGWEBPASSWORD | ConvertFrom-Json ).data).OUTGOINGWEBPASSWORD)


$MQFull_messaging = $(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/windows-tcia/MQFULLMESSAGING | ConvertFrom-Json ).data).MQFULLMESSAGING)

# Deploy App
set-alias 7z "$env:ProgramFiles\7-Zip\7z.exe"
Set-Location d:\deploy
aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket riyadh2-prd-win-dependencies --key CEB.TalentCentral.Integration.Incoming.zip d:\deploy\CEB.TalentCentral.Integration.Incoming.zip

7z x CEB.TalentCentral.Integration.Incoming.zip
Set-Location IncomingServer

$DeployRegByCode = "False"

.\DeployServer.exe /Password_SvcIntegrationIncomingApp:$IncomingAppPassword /Password_SvcIntegrationIncomingWeb:$IncomingWebPassword

# Deploy Wait 
do
{
    $HTTP_Request = [System.Net.WebRequest]::Create('http://localhost:8090/integrationtools/dependencyhealthchecks/webserver')
    $HTTP_Response = $HTTP_Request.GetResponse()
    $HTTP_Status = [int]$HTTP_Response.StatusCode
    Start-sleep 5
} until ($HTTP_Status -eq "200")


#--- Begin TCIW Registry Changes -----#

$TomcatUserName = "tomcat-s"

$ActiveMQUsername = $(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/windows-tcia/ACTIVEMQUSERNAME | ConvertFrom-Json ).data).ACTIVEMQUSERNAME)

$ActiveMQPassword = $(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/windows-tcia/ACTIVEMQPASSWORD | ConvertFrom-Json ).data).ACTIVEMQPASSWORD)

$EnvironmentName = $(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/windows-tcia/TCIENVNAME | ConvertFrom-Json ).data).TCIENVNAME)

$TCURL=$(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-windows/TCURL  | ConvertFrom-Json ).data).TCURL )
$TCDBServer=$(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/tc-windows/REDBSERVER | ConvertFrom-Json ).data).REDBSERVER )

#Data Source=talentcentral-db.au.shl.com,1605; Initial Catalog=Integration; User Id=tomcat-s; Password=RmChxhb6wLxzcvztBQBOufWKi; MultipleActiveResultSets=True
$IntegrationDatabaseConnectionString = "Data Source=$TCDBServer,1605; Initial Catalog=Integration; User Id=$TomcatUserName; Password=$TCPassword; MultipleActiveResultSets=True"

#talentcentral.au.shl.com
$TalentCentralDomain = $TCURL

#integration-talentcentral.au.shl.com
$TalentCentralIntegrationDomain = "integration-$TCURL"

#ssl-integration-talentcentral.au.shl.com
$TalentCentralIntegrationSSLDomain = "ssl-integration-$TCURL"

$RegressionToolServiceUrl = "https://integration-$TCURL/InternalIntegration/IntegrationService/RegressionToolService/IRegressionToolService"


$IntegrationToolsDomain =$(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/windows-tcia/TCIINTEGRATIONTOOLSDOMAIN | ConvertFrom-Json ).data).TCIINTEGRATIONTOOLSDOMAIN)
$JWTSigningCertificateName =$(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/windows-tcia/TCIJWTSIGNINGCERTIFICATENAME | ConvertFrom-Json ).data).TCIJWTSIGNINGCERTIFICATENAME)
$SnaphireApiKey =$(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/windows-tcia/TCISNAPHIREAPIKEY | ConvertFrom-Json ).data).TCISNAPHIREAPIKEY)
$SnaphireAppName =$(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/windows-tcia/TCISNAPHIREAPPNAME | ConvertFrom-Json ).data).TCISNAPHIREAPPNAME)
$SnaphireAppShortCode =$(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/windows-tcia/TCISNAPHIREAPPSHORTCODE | ConvertFrom-Json ).data).TCISNAPHIREAPPSHORTCODE)
$SnaphireSnaphireUrl =$(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/windows-tcia/TCISNAPHIRESNAPHIREURL | ConvertFrom-Json ).data).TCISNAPHIRESNAPHIREURL)


$smartrecruitersbaseurl =$(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/windows-tcia/SMARTRECRUITERSBASEURL | ConvertFrom-Json ).data).SMARTRECRUITERSBASEURL)
$smartrecruitersaccesstoken =$(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/windows-tcia/SMARTRECRUITERSACCESSTOKEN | ConvertFrom-Json ).data).SMARTRECRUITERSACCESSTOKEN)
$icimsprimeurlkey =$(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/windows-tcia/ICIMSPRIMEURLKEY | ConvertFrom-Json ).data).ICIMSPRIMEURLKEY)
$icimsprimeusername =$(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/windows-tcia/ICIMSPRIMEUSERNAME | ConvertFrom-Json ).data).ICIMSPRIMEUSERNAME)
$icimsprimepassword =$(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/windows-tcia/ICIMSPRIMEPASSWORD | ConvertFrom-Json ).data).ICIMSPRIMEPASSWORD)
$aspiringmindsbaseurl =$(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/windows-tcia/ASPIRINGMINDSBASEURL | ConvertFrom-Json ).data).ASPIRINGMINDSBASEURL)


$mokabaseurl ="https://api-staging003.mokahr.com/"

#Data Source=talentcentral-db.au.shl.com,1605; Initial Catalog=IntegrationRegressionToolTest; User Id=tomcat-s; Password=RmChxhb6wLxzcvztBQBOufWKi; MultipleActiveResultSets=True
$RegressionToolDatabaseConnectionString = "Data Source=$TCDBServer,1605; Initial Catalog=IntegrationRegressionTool; User Id=$TomcatUserName; Password=$TCPassword; MultipleActiveResultSets=True"

#Data Source=talentcentral-db.au.shl.com,1605; Initial Catalog=IntegrationRegressionToolTest; User Id=tomcat-s; Password=RmChxhb6wLxzcvztBQBOufWKi; MultipleActiveResultSets=True
$RegressionToolTestDatabaseConnectionString = "Data Source=$TCDBServer,1605; Initial Catalog=IntegrationRegressionToolTest; User Id=$TomcatUserName; Password=$TCPassword; MultipleActiveResultSets=True"

#Data Source=talentcentral-db.au.shl.com,1605; Initial Catalog=IntegrationTestHarness; User Id=tomcat-s; Password=RmChxhb6wLxzcvztBQBOufWKi; MultipleActiveResultSets=True
$TestHarnessDatabaseConnectionString = "Data Source=$TCDBServer,1605; Initial Catalog=IntegrationTestHarness; User Id=$TomcatUserName; Password=$TCPassword; MultipleActiveResultSets=True"

#HKEY_LOCAL_MACHINE\SOFTWARE\CEB\TalentCentral\Integration\TestHarness
Set-Itemproperty -path HKLM:\SOFTWARE\CEB\TalentCentral\Integration\ -Name 'TestHarness' -value $TestHarnessDatabaseConnectionString

#HKEY_LOCAL_MACHINE\SOFTWARE\CEB\TalentCentral\Integration\TestHarness\TestHarnessDatabaseConnectionString
Set-Itemproperty -path HKLM:\SOFTWARE\CEB\TalentCentral\Integration\TestHarness -Name 'TestHarnessDatabaseConnectionString' -value $TestHarnessDatabaseConnectionString

#HKEY_LOCAL_MACHINE\SOFTWARE\CEB\TalentCentral\Integration\RegressionTool\RegressionToolDatabaseConnectionString
Set-Itemproperty -path HKLM:\SOFTWARE\CEB\TalentCentral\Integration\RegressionTool\ -Name 'RegressionToolDatabaseConnectionString' -value $RegressionToolDatabaseConnectionString

#HKEY_LOCAL_MACHINE\SOFTWARE\CEB\TalentCentral\Integration\RegressionTool\RegressionToolDatabaseConnectionString
Set-Itemproperty -path HKLM:\SOFTWARE\CEB\TalentCentral\Integration\RegressionTool -Name 'RegressionToolDatabaseConnectionString' -value $RegressionToolDatabaseConnectionString

#HKEY_LOCAL_MACHINE\SOFTWARE\CEB\TalentCentral\Integration\RegressionTool\RegressionToolTestDatabaseConnectionString
Set-Itemproperty -path HKLM:\SOFTWARE\CEB\TalentCentral\Integration\RegressionTool\ -Name 'RegressionToolTestDatabaseConnectionString' -value $RegressionToolTestDatabaseConnectionString

#As discussed below registries are not required

#HKEY_LOCAL_MACHINE\SOFTWARE\CEB\TalentCentral\Integration\Messaging\ActiveMQUri
#Set-Itemproperty -path HKLM:\SOFTWARE\CEB\TalentCentral\Integration\Messaging -Name 'ActiveMQUri' -value $MQFull_messaging

#HKEY_LOCAL_MACHINE\SOFTWARE\CEB\TalentCentral\Integration\Messaging\ActiveMQUsername
#Set-Itemproperty -path HKLM:\SOFTWARE\CEB\TalentCentral\Integration\Messaging -Name 'ActiveMQUsername' -value $ActiveMQUsername

#HKEY_LOCAL_MACHINE\SOFTWARE\CEB\TalentCentral\Integration\Messaging\ActiveMQPassword
#Set-Itemproperty -path HKLM:\SOFTWARE\CEB\TalentCentral\Integration\Messaging -Name 'ActiveMQPassword' -value $ActiveMQPassword

#HKEY_LOCAL_MACHINE\SOFTWARE\CEB\TalentCentral\Integration\IntegrationDatabaseConnectionString
Set-Itemproperty -path HKLM:\SOFTWARE\CEB\TalentCentral\Integration\ -Name 'IntegrationDatabaseConnectionString' -value $IntegrationDatabaseConnectionString

if ($DeployRegByCode -eq "False") {
	#HKEY_LOCAL_MACHINE\SOFTWARE\CEB\TalentCentral\Integration\EnvironmentName
	Set-Itemproperty -path HKLM:\SOFTWARE\CEB\TalentCentral\Integration\ -Name 'EnvironmentName' -value $EnvironmentName

	#HKEY_LOCAL_MACHINE\SOFTWARE\CEB\TalentCentral\Integration\TalentCentralDomain
	Set-Itemproperty -path HKLM:\SOFTWARE\CEB\TalentCentral\Integration\ -Name 'TalentCentralDomain' -value $TalentCentralDomain

	#HKEY_LOCAL_MACHINE\SOFTWARE\CEB\TalentCentral\Integration\TalentCentralIntegrationDomain
	Set-Itemproperty -path HKLM:\SOFTWARE\CEB\TalentCentral\Integration\ -Name 'TalentCentralIntegrationDomain' -value $TalentCentralIntegrationDomain

	#HKEY_LOCAL_MACHINE\SOFTWARE\CEB\TalentCentral\Integration\TalentCentralIntegrationSSLDomain
	Set-Itemproperty -path HKLM:\SOFTWARE\CEB\TalentCentral\Integration\ -Name 'TalentCentralIntegrationSSLDomain' -value $TalentCentralIntegrationSSLDomain

	#HKEY_LOCAL_MACHINE\SOFTWARE\CEB\TalentCentral\Integration\JWTSigningCertificateName
    Set-Itemproperty -path HKLM:\SOFTWARE\CEB\TalentCentral\Integration\ -Name 'JWTSigningCertificateName' -value $JWTSigningCertificateName

    #HKEY_LOCAL_MACHINE\SOFTWARE\CEB\TalentCentral\Integration\IntegrationToolsDomain
    Set-Itemproperty -path HKLM:\SOFTWARE\CEB\TalentCentral\Integration\ -Name 'IntegrationToolsDomain' -value $IntegrationToolsDomain
	
	#HKEY_LOCAL_MACHINE\SOFTWARE\CEB\TalentCentral\Integration\Adapters\Snaphire\ApiKey
	Set-Itemproperty -path HKLM:\SOFTWARE\CEB\TalentCentral\Integration\Adapters\Snaphire\ -Name 'ApiKey' -value $SnaphireApiKey

	#HKEY_LOCAL_MACHINE\SOFTWARE\CEB\TalentCentral\Integration\Adapters\Snaphire\AppName
	Set-Itemproperty -path HKLM:\SOFTWARE\CEB\TalentCentral\Integration\Adapters\Snaphire\ -Name 'AppName' -value $SnaphireAppName

	#HKEY_LOCAL_MACHINE\SOFTWARE\CEB\TalentCentral\Integration\Adapters\Snaphire\AppShortCode
	Set-Itemproperty -path HKLM:\SOFTWARE\CEB\TalentCentral\Integration\Adapters\Snaphire\ -Name 'AppShortCode' -value $SnaphireAppShortCode

	#HKEY_LOCAL_MACHINE\SOFTWARE\CEB\TalentCentral\Integration\Adapters\Snaphire\SnaphireUrl
	Set-Itemproperty -path HKLM:\SOFTWARE\CEB\TalentCentral\Integration\Adapters\Snaphire\ -Name 'SnaphireUrl' -value $SnaphireSnaphireUrl

	#HKEY_LOCAL_MACHINE\SOFTWARE\CEB\TalentCentral\Integration\RegressionToolService\RegressionToolServiceUrl
	Set-Itemproperty -path HKLM:\SOFTWARE\CEB\TalentCentral\Integration\RegressionToolService\ -Name 'RegressionToolServiceUrl' -value $RegressionToolServiceUrl

	#HKEY_LOCAL_MACHINE\SOFTWARE\CEB\TalentCentral\Integration\SendMail\SmtpServer
	#Set-Itemproperty -path HKLM:\SOFTWARE\CEB\TalentCentral\Integration\SendMail -Name 'SmtpServer' -value $smtpserver

	#HKEY_LOCAL_MACHINE\SOFTWARE\CEB\TalentCentral\Integration\RegressionToolService\RegressionToolServiceUrl
	Set-Itemproperty -path HKLM:\SOFTWARE\CEB\TalentCentral\Integration\RegressionToolService\ -Name 'RegressionToolServiceUrl' -value $RegressionToolServiceUrl

	#HKEY_LOCAL_MACHINE\SOFTWARE\CEB\TalentCentral\Integration\Adapters\SmartRecruiters\SmartRecruitersBaseUrl
	Set-Itemproperty -path HKLM:\SOFTWARE\CEB\TalentCentral\Integration\Adapters\SmartRecruiters\ -Name 'SmartRecruitersBaseUrl' -value $smartrecruitersbaseurl

	#HKEY_LOCAL_MACHINE\SOFTWARE\CEB\\TalentCentral\Integration\Adapters\SmartRecruiters\SmartRecruitersAccessToken
	Set-Itemproperty -path HKLM:\SOFTWARE\CEB\TalentCentral\Integration\Adapters\SmartRecruiters\ -Name 'SmartRecruitersAccessToken' -value $smartrecruitersaccesstoken

	#HKEY_LOCAL_MACHINE\SOFTWARE\CEB\\TalentCentral\Integration\Adapters\IcimsPrime\IcimsPrimeUrl
	Set-Itemproperty -path HKLM:\SOFTWARE\CEB\TalentCentral\Integration\Adapters\IcimsPrime\ -Name 'IcimsPrimeUrl' -value $icimsprimeurlkey

	#HKEY_LOCAL_MACHINE\SOFTWARE\CEB\\TalentCentral\Integration\Adapters\IcimsPrime\IcimsPrimeUsername
	Set-Itemproperty -path HKLM:\SOFTWARE\CEB\TalentCentral\Integration\Adapters\IcimsPrime\ -Name 'IcimsPrimeUsername' -value $icimsprimeusername

	#HKEY_LOCAL_MACHINE\SOFTWARE\CEB\\TalentCentral\Integration\Adapters\IcimsPrime\IcimsPrimePassword
	Set-Itemproperty -path HKLM:\SOFTWARE\CEB\TalentCentral\Integration\Adapters\IcimsPrime\ -Name 'IcimsPrimePassword' -value $icimsprimepassword

	#HKEY_LOCAL_MACHINE\SOFTWARE\CEB\TalentCentral\Integration\AspiringMindsBaseUrl
	Set-Itemproperty -path HKLM:\SOFTWARE\CEB\TalentCentral\Integration\ -Name 'AspiringMindsBaseUrl' -value $aspiringmindsbaseurl

	#HKEY_LOCAL_MACHINE\SOFTWARE\CEB\TalentCentral\Integration\Moka\MokaBaseUrl
	New-Item -path HKLM:\SOFTWARE\CEB\TalentCentral\Integration\Adapters\ -name Moka
	Set-Itemproperty -path HKLM:\SOFTWARE\CEB\TalentCentral\Integration\Adapters\Moka\ -Name 'MokaBaseUrl' -value $mokabaseurl
}
#--- End TCIW Registry Changes -----#

Set-Location d:\

#Configure permissions for TCI web service accounts to access IIS configs
$path = "C:\Windows\System32\inetsrv\config" #Replace with whatever file you want to do this to.
$user = "SVC-TCI-OUTGOING-WEB" #User account to grant permisions too.
$Rights = "Read, ReadAndExecute, ListDirectory" #Comma seperated list.
$InheritSettings = "Containerinherit, ObjectInherit" #Controls how permissions are inherited by children
$PropogationSettings = "None" #Usually set to none but can setup rules that only apply to children.
$RuleType = "Allow" #Allow or Deny.

$acl = Get-Acl $path
$perm = $user, $Rights, $InheritSettings, $PropogationSettings, $RuleType
$rule = New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule -ArgumentList $perm
$acl.SetAccessRule($rule)
$acl | Set-Acl -Path $path

$path = "C:\Windows\System32\inetsrv\config" #Replace with whatever file you want to do this to.
$user = "SVC-TCI-INCOMING-WEB" #User account to grant permisions too.
$Rights = "Read, ReadAndExecute, ListDirectory" #Comma seperated list.
$InheritSettings = "Containerinherit, ObjectInherit" #Controls how permissions are inherited by children
$PropogationSettings = "None" #Usually set to none but can setup rules that only apply to children.
$RuleType = "Allow" #Allow or Deny.

$acl = Get-Acl $path
$perm = $user, $Rights, $InheritSettings, $PropogationSettings, $RuleType
$rule = New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule -ArgumentList $perm
$acl.SetAccessRule($rule)
$acl | Set-Acl -Path $path

#Configure permissions for TCI service accounts to access D:\SHL log location
$path = "D:\SHL" #Replace with whatever file you want to do this to.
$user = "SVC-TCI-OUTGOING-WEB" #User account to grant permisions too.
$Rights = "Modify" #Comma seperated list.
$InheritSettings = "Containerinherit, ObjectInherit" #Controls how permissions are inherited by children
$PropogationSettings = "None" #Usually set to none but can setup rules that only apply to children.
$RuleType = "Allow" #Allow or Deny.

$acl = Get-Acl $path
$perm = $user, $Rights, $InheritSettings, $PropogationSettings, $RuleType
$rule = New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule -ArgumentList $perm
$acl.SetAccessRule($rule)
$acl | Set-Acl -Path $path

$path = "D:\SHL" #Replace with whatever file you want to do this to.
$user = "SVC-TCI-INCOMING-WEB" #User account to grant permisions too.
$Rights = "Modify" #Comma seperated list.
$InheritSettings = "Containerinherit, ObjectInherit" #Controls how permissions are inherited by children
$PropogationSettings = "None" #Usually set to none but can setup rules that only apply to children.
$RuleType = "Allow" #Allow or Deny.

$acl = Get-Acl $path
$perm = $user, $Rights, $InheritSettings, $PropogationSettings, $RuleType
$rule = New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule -ArgumentList $perm
$acl.SetAccessRule($rule)
$acl | Set-Acl -Path $path

$path = "D:\SHL" #Replace with whatever file you want to do this to.
$user = "SVC-TCI-OUTGOING-APP" #User account to grant permisions too.
$Rights = "Modify" #Comma seperated list.
$InheritSettings = "Containerinherit, ObjectInherit" #Controls how permissions are inherited by children
$PropogationSettings = "None" #Usually set to none but can setup rules that only apply to children.
$RuleType = "Allow" #Allow or Deny.

$acl = Get-Acl $path
$perm = $user, $Rights, $InheritSettings, $PropogationSettings, $RuleType
$rule = New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule -ArgumentList $perm
$acl.SetAccessRule($rule)
$acl | Set-Acl -Path $path

$path = "D:\SHL" #Replace with whatever file you want to do this to.
$user = "SVC-TCI-INCOMING-APP" #User account to grant permisions too.
$Rights = "Modify" #Comma seperated list.
$InheritSettings = "Containerinherit, ObjectInherit" #Controls how permissions are inherited by children
$PropogationSettings = "None" #Usually set to none but can setup rules that only apply to children.
$RuleType = "Allow" #Allow or Deny.

$acl = Get-Acl $path
$perm = $user, $Rights, $InheritSettings, $PropogationSettings, $RuleType
$rule = New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule -ArgumentList $perm
$acl.SetAccessRule($rule)
$acl | Set-Acl -Path $path

#--- DataDog Config -----#
$envString1 = $(((curl.exe -H "X-Vault-Token: ${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/windows-tcia/STACKPROFILE | ConvertFrom-Json ).data).STACKPROFILE)
$envString = "tc_" + $envString1
$hostnamedefault = "hostname: NOT-SET"
$Ipaddress = (Get-NetIPAddress -PrefixOrigin Dhcp).IPAddress
$hostnamedd= "hostname: $Ipaddress"
$tagdefault = "- system:NOT-SET"
$tags = @"
- system:talentcentral
- application:talentcentral
- env:$envString
- tcappcode:iw
- tcappname:integrationweb
- platform:bluvalt
"@
$ddconf = Get-Content "C:\programdata\datadog\datadog.yaml"
$ddconf = $ddconf -Replace ($tagdefault,$tags) 
$ddconf = $ddconf -Replace ($hostnamedefault,$hostnamedd)
$ddconf | Set-Content -Path "C:\programdata\datadog\datadog.yaml"


aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket riyadh2-prd-win-deployment --key tciw.d_conf.txt C:\bootstrap\tciw.d_conf.txt
aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket riyadh2-prd-win-deployment --key tciw.win32_event_log.d_conf.txt C:\bootstrap\win32_event_log.d_conf.txt
aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket riyadh2-prd-win-deployment --key tciw.disk.d_conf.txt C:\bootstrap\disk.d_conf.txt
aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket riyadh2-prd-win-deployment --key tciw.dd_app.config.txt C:\bootstrap\dd_app.config.txt

aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket riyadh2-prd-win-deployment --key tciw_http_check.d.txt C:\bootstrap\tciw_http_check.d.txt

Copy-Item "C:\bootstrap\tciw_http_check.d.txt" -Destination "C:\ProgramData\Datadog\conf.d\http_check.d\conf.yaml" -force;

Copy-Item "C:\bootstrap\tciw.d_conf.txt" -Destination "c:\ProgramData\Datadog\conf.d\iis.d\conf.yaml" -force;
Copy-Item "C:\bootstrap\win32_event_log.d_conf.txt" -Destination "C:\ProgramData\Datadog\conf.d\win32_event_log.d\conf.yaml" -force;
Copy-Item "C:\bootstrap\disk.d_conf.txt" -Destination "c:\ProgramData\Datadog\conf.d\disk.d\conf.yaml" -force;

## DD .NET APM Set-up
# Install DD dotnet-tracer only if it's not already installed on the AMI
 if ( -Not (((gp HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*).DisplayName -Match "Datadog .NET Tracer").Length -gt 0))
 {
      #Download latest dotnet-tracer
      $repo = "DataDog/dd-trace-dotnet"
      $releases = "https://api.github.com/repos/$repo/releases"
      Write-Host Determining latest release
      $tag = (Invoke-WebRequest $releases | ConvertFrom-Json)[0].tag_name
      $dlver = $tag.replace("v","")
      $file = "datadog-dotnet-apm-$dlver-x64.msi"
      $download = "https://github.com/$repo/releases/download/$tag/$file"
      Invoke-Webrequest -Uri $download -OutFile c:\bootstrap\datadog-dotnet-apm.msi
      Start-Process msiexec.exe -Wait -ArgumentList '/qn /i c:\bootstrap\datadog-dotnet-apm.msi /norestart'
 }

# TCIW services to monitor
[String[]] $v = @("COR_ENABLE_PROFILING=1", "COR_PROFILER={846F5F1C-F9AE-4B07-969E-05C26BC060D8}")
Set-ItemProperty HKLM:SYSTEM\CurrentControlSet\Services\CEB.TalentCentral.Integration.RegressionTool.Db.Service -Name Environment -Value $v

# Replace env string in app.config
$ddconf = Get-Content "C:\bootstrap\dd_app.config.txt"
$ddconf = $ddconf -Replace ("#ENVSTRING#",$envString) 
$ddconf | Set-Content -Path "C:\bootstrap\dd_app.config.txt"

# TCIW web-sites to monitor
Copy-Item "C:\bootstrap\dd_app.config.txt" -Destination "C:\Program Files\CEB\Talent Central\Integration\Incoming\Web\TCDomain\app.config" -force;

## End DD APM

Set-Service -Name DatadogAgent -StartupType "Automatic"
#--- End DataDog Config -----#


& c:\installs\test_dns.ps1 $hashi_vault_root_token $hashi_vault_server_ip

