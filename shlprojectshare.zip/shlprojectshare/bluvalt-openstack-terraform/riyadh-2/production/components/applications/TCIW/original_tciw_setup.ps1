# Copy Install files to c:\installs #
Write-Host "Copying Install Zips.."
aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket win-dependencies --key tciw.zip  C:\installs\tciw.zip
aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket win-dependencies --key tciw.csv  C:\installs\tciw.csv
# Copy-S3Object -BucketName artifacts-shl-commonservices-1 -KeyPrefix TC\tciw\  -LocalFolder c:\installs -force
Expand-Archive -LiteralPath c:\installs\tciw.zip -DestinationPath c:\installs\ -force
Move-Item -Path C:\installs\tciw\tciw\* -Destination C:\installs\tciw\
copy-item -path "c:\installs\tciw\*" -destination "C:\installs" -recurse
Remove-Item -Path C:\installs\tciw\tciw
mkdir c:\users\public\desktop

copy-item -path "c:\installs\tciw\*" -destination "c:\users\public\desktop\" -recurse
Write-Host "Finished Copying Install Zips.."

# Install Roles for TCNet #
Write-Host "Installing roles and features"
Import-Module servermanager
Import-Csv C:\installs\tciw.csv | ForEach-Object{Add-WindowsFeature $_.name  }
Write-Host "Finished Installing roles and features"

# Install MS Stuff #
Write-Host "Installing MS Build Packages"
Start-Process "c:\installs\msbuild.msi" /qn -Wait
#cmd /c c:\installs\ndp.exe /q /norestart 
start-sleep 100
Write-Host "Finished Installing MS Build Packages"
# End Install MS Stuff #

# Install Certs #
Write-Host "Installing Certs"
Import-Certificate -FilePath "c:\installs\DCHA.cer" -CertStoreLocation Cert:\LocalMachine\My 
Import-Certificate -FilePath "c:\installs\DCSHA2HA.cer" -CertStoreLocation Cert:\LocalMachine\My 
Import-Certificate -FilePath "c:\installs\lloyds.cer" -CertStoreLocation Cert:\LocalMachine\My 
$certpass = ConvertTo-SecureString "test" -AsPlainText -Force
Import-PfxCertificate -FilePath c:\installs\jwttest.pfx -CertStoreLocation Cert:\LocalMachine\My -Password $certpass
Import-PfxCertificate -FilePath c:\installs\star-eu.pfx -CertStoreLocation Cert:\LocalMachine\My -Password $certpass
Import-PfxCertificate -FilePath c:\installs\star-us.pfx -CertStoreLocation Cert:\LocalMachine\My -Password $certpass
Write-Host "Finished Installing Certs"
# End Install Certs #

