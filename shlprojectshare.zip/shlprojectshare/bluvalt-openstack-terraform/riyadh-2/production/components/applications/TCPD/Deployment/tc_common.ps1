# Set-Location c:\bootstrap
# $json = Get-Content -Raw -Path c:\cfn\param.json | ConvertFrom-Json
# $EnvName = $json.identifier
# $environment = $json.environment
# $EnvType = $json.identifier
# $Senv = $json.senv
# $Sreg = $json.sreg
# $S3FilesBucket = $json.s3
# $Module = $json.module
# $LowModule = $Module.ToLower()
# $App = $json.service
# $Os = $json.os
# $Ad = $json.ad
# $Domain = $json.domain
# $DirectoryID = $json.directoryId
# $Directory = Get-DSDirectory -DirectoryId $DirectoryID
# $DnsIpAddresses = $Directory.DnsIpAddrs
# $DomainName = $Directory.Name
# $Region = $json.region
# $ShlRegion = $json.shlregion
# $instanceId=(Invoke-WebRequest -UseBasicParsing -Uri http://169.254.169.254/latest/meta-data/instance-id).Content
# $fs = "talentcentral-" + $EnvType.ToLower() + "-fs." + $ShlRegion.ToLower() + "." + $Domain.ToLower()
# $UUDI=("get-wmiobject Win32_ComputerSystemProduct | Select-Object -ExpandProperty UUID | out-string"); $hash = $UUDI.Substring(9, 2); 

# if ($Module -notlike 'TCI*'){
# Rename-Computer -NewName $Sreg-$Senv-$LowModule-$Os-$hash -force
# }
# if ($Region -eq "cn-northwest-1")
# {
# 	Copy-S3Object -BucketName ${S3FilesBucket} -KeyPrefix common -LocalFolder C:\bootstrap -force -Region $Region
# }else{
# 	Copy-S3Object -BucketName ${S3FilesBucket} -KeyPrefix common -LocalFolder C:\bootstrap -force -UseAccelerateEndpoint
# };

# # Disable Firewall
Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled False

# # Install Cloudwatch Agent #
# net stop AmazonCloudWatchAgent
# net stop AmazonSSMAgent
# set-location c:\bootstrap\Agent
# ./install.ps1
# ./amazon-cloudwatch-agent-ctl.ps1 -a fetch-config -m ec2 -c ssm:AmazonCloudWatch-SHL-Windows -s

#Enable WinRM
Enable-PSRemoting -force
Set-Service WinRM -StartMode Automatic
Set-Item WSMan:localhost\client\trustedhosts -value * -force

c:\bootstrap\module.ps1
