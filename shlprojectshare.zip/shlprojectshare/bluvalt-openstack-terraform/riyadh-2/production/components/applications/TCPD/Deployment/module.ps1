# Setup Service #
mkdir d:\logs

Expand-Archive -LiteralPath c:\installs\tcpd.zip -DestinationPath d:\ -force

copy-item -path "d:\desktop\*" -destination "C:\Users\Administrator\desktop\" -recurse

copy-item -path d:\tcpd -recurse -destination c:\windows\system32\inetsrv\backup\tcpd -container -force

restore-webconfiguration tcpd

# End Setup Service #

# Copy scripts and Desktop Icons #

copy-item -path "d:\desktop\*" -destination "C:\Users\Administrator\desktop\" -recurse

# End Copy scripts and Desktop Icons #

# Setup Local User #

Remove-Item alias:curl

$TCPassword = $(((curl -H "X-Vault-Token: s.EbXCZqjl7i4fD9O3y9eEXtEX" -X GET http://10.210.16.28:8200/v1/kv/tc-windows/TCPASSWORD | ConvertFrom-Json ).data).TCPASSWORD)


$DOPassword = $(((curl -H "X-Vault-Token: s.EbXCZqjl7i4fD9O3y9eEXtEX" -X GET http://10.210.16.28:8200/v1/kv/tc-windows/TCPASSWORD | ConvertFrom-Json ).data).TCPASSWORD)


$UserAccount = Get-LocalUser -Name "devops-s"

$SecurePassword=ConvertTo-SecureString $DOPassword -asplaintext -force 

$UserAccount | Set-LocalUser -Password $SecurePassword -PasswordNeverExpires 1

$UserAccount = Get-LocalUser -Name "tomcat-s"

$SecurePassword=ConvertTo-SecureString $TCPassword -asplaintext -force 

$UserAccount | Set-LocalUser -Password $SecurePassword -PasswordNeverExpires 1

$UserAccount = Get-LocalUser -Name "Administrator"

$UserAccount | Set-LocalUser -PasswordNeverExpires 1

# End Setup Local User #

# Datadog config #

$envString = "tc_" + $(((curl -H "X-Vault-Token: s.EbXCZqjl7i4fD9O3y9eEXtEX" -X GET http://10.210.16.28:8200/v1/kv/windows-tcpd/STACKPROFILE | ConvertFrom-Json ).data).STACKPROFILE)


$hostnamedd = hostname

$tagdefault = "- system:NOT-SET"

$tags = @"
- system:talentcentral
- application:talentcentral
- env:$envString
- tcappcode:pd
- tcappname:pdfgenerator
- platform:aws
"@

$ddconf = Get-Content "C:\programdata\datadog\datadog.yaml"

$ddconf = $ddconf -Replace ($tagdefault,$tags) 

$ddconf = $ddconf -Replace ($hostnamedefault,$hostnamedd)

$ddconf | Set-Content -Path "C:\programdata\datadog\datadog.yaml"

aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket win-dependencies --key tcpd/iis.d_conf.txt C:\bootstrap\iis.d_conf.txt

aws s3api --endpoint-url https://api-object.bluvalt.com:8082 --profile default get-object --bucket win-dependencies --key tcpd/iis.d_conf.yaml C:\bootstrap\iis.d_conf.yaml


Copy-Item "C:\bootstrap\iis.d_conf.txt" -Destination "c:\ProgramData\Datadog\conf.d\iis.d\conf.yaml" -force;


Set-Service -Name DatadogAgent -StartupType "Automatic"

# End DataDog Config #

# CleanUp Installs #
Remove-item 'c:\installs' -Recurse
Remove-item 'd:\desktop' -Recurse
Remove-item 'd:\tcpd' -Recurse
# End CleanUp Installs #

#Restart-Computer -force
