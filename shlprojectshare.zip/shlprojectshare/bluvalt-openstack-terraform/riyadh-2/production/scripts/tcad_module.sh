#!/bin/bash

PROFILE=""
hashi_vault_root_token=""
hashi_vault_server_ip=""

# Initialize parameters specified from command line
while getopts ":p:t:i:n:d:s:" arg; do
  case "${arg}" in
    p)
      PROFILE=${OPTARG}
      ;; 
    t)
      hashi_vault_root_token=${OPTARG}
      ;;
    i)
      hashi_vault_server_ip=${OPTARG}
      ;;
    n)
      dns_srv_ip=${OPTARG}
      ;;
    s)
      dns_srv_ip2=${OPTARG}
      ;; 
    d)
      dns_domain=${OPTARG}
      ;;
  esac
done

apt update -y

#Install and enable resolveconf
apt install resolvconf 
sudo systemctl enable --now resolvconf.service
tee /etc/resolvconf/resolv.conf.d/head <<EOF
nameserver $dns_srv_ip
nameserver $dns_srv_ip2
search $dns_domain
EOF
sudo resolvconf -u

HOSTNAME=`hostname`
echo "127.0.0.1   $HOSTNAME" >> /etc/hosts


# Prevent datadog being updated by apt
apt-mark hold datadog-agent

#Stop tomcat if enabled
systemctl stop tomcat

# Install latest updates and required packages.
apt update -y

# Update TCAD Configs
TCURL=`curl -H "X-Vault-Token: $hashi_vault_root_token " -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/TCURL | jq '.data.TCURL' | sed 's/"//g'`
TCCDNURL=`curl -H "X-Vault-Token: $hashi_vault_root_token " -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/TCURL| jq '.data.TCURL' | sed 's/"//g'`"\/cdn"
TCDBSERVER=`curl -H "X-Vault-Token: $hashi_vault_root_token " -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/TCDBSERVER | jq '.data.TCDBSERVER' | sed 's/"//g'`
TCReadDBServer=`curl -H "X-Vault-Token: $hashi_vault_root_token " -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/TCREADDBSERVER | jq '.data.TCREADDBSERVER' | sed 's/"//g'`
APPVERSION=`curl -H "X-Vault-Token: $hashi_vault_root_token " -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/APPVERSION | jq '.data.APPVERSION' | sed 's/"//g'`
TCPASSWORD=`curl -H "X-Vault-Token: $hashi_vault_root_token " -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/TCPASSWORD | jq '.data.TCPASSWORD' | sed 's/"//g'`
READTCPASS=`curl -H "X-Vault-Token: $hashi_vault_root_token " -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/READTCPASS | jq '.data.READTCPASS' | sed 's/"//g'`

AWS_ACCESS_KEY_ID=`curl -H "X-Vault-Token:$hashi_vault_root_token" -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-s3/AWS_ACCESS_KEY_ID | jq '.data.AWS_ACCESS_KEY_ID' | sed 's/"//g'`
AWS_SECRET_ACCESS_KEY=`curl -H "X-Vault-Token:$hashi_vault_root_token" -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-s3/AWS_SECRET_ACCESS_KEY | jq '.data.AWS_SECRET_ACCESS_KEY' | sed 's/"//g'`

sed -i "s/#TCURL#/${TCURL}/g" /opt/shl/apache-tomcat/conf/web.xml
sed -i "s/#TCCDNURL#/${TCCDNURL}/g" /opt/shl/apache-tomcat/conf/web.xml
sed -i "s/#TCDBServer#/${TCDBSERVER}/g" /opt/shl/apache-tomcat/conf/database.properties
sed -i "s/#TCPassword#/${TCPASSWORD}/g" /opt/shl/apache-tomcat/conf/database.properties
sed -i "s/#TCReadDBServer#/${TCReadDBServer}/g" /opt/shl/apache-tomcat/conf/database.properties
sed -i "s/#readtcpass#/${READTCPASS}/g" /opt/shl/apache-tomcat/conf/database.properties
sed -i "s/#TCProfile#/${PROFILE}/g" /opt/shl/apache-tomcat/bin/setenv.sh
sed -i "s|#LOGFILEFULLPATH#|/opt/shl/apache-tomcat/logs/shlonline.log|g" /opt/shl/apache-tomcat/conf/log4j.properties

sed -i "s/#APPNAME#/admin/g" /opt/shl/jmx/jmxremote.access
sed -i "s/#APPNAME#/admin/g" /opt/shl/jmx/jmxremote.password
chmod 0600 /opt/shl/jmx/jmxremote.*

# Doing this here as we may find it difficult to live without port 80
# Ideally this should be configured in the Tomcat archive used by packer
sed -i 's|Connector port="80"|Connector port="8080"|g' /opt/shl/apache-tomcat/conf/server.xml

# Copy WAR files
aws s3api --endpoint-url https://api-object.bluvalt.com:8082 get-object --bucket riyadh2-prd-tc-application-artifacts --key tcad/${APPVERSION}/admin.war /opt/shl/apache-tomcat/webapps/admin.war

# Fix permissions
chown -R tomcat-s:tomcat-s /opt/shl

# for admin we need to create credentials.properties
tee /opt/shl/apache-tomcat/conf/credentials.properties <<EOF
 
aws_access_key_id : $AWS_ACCESS_KEY_ID
aws_secret_access_key : $AWS_SECRET_ACCESS_KEY
EOF

# Configure Datadog Agent
systemctl stop datadog-agent
rm -rf /var/log/datadog-agent/*
DDAPIKEY=`curl -H "X-Vault-Token: $hashi_vault_root_token " -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/DATADOG_APIKEY | jq '.data.DATADOG_APIKEY' | sed 's/"//g'`
tee /etc/datadog-agent/datadog.yaml <<EOF
dd_url: https://app.datadoghq.com
api_key: $DDAPIKEY
logs_enabled: true
log_format_json: false
log_level: DEBUG
log_file: /var/log/datadog/agent.log
log_payloads: false
log_to_console: true
log_to_syslog: false
logging_frequency: 20
apm_config:
  enabled: true
logs_config:
  container_collect_all: false
  dd_port: 10516
  dd_url: agent-intake.logs.datadoghq.com
  dev_mode_use_proto: true
  frame_size: 9000
  open_files_limit: 100
  run_path: ""
  tcp_forward_port: -1
tags:
- system:talentcentral
- application:talentcentral
- env:tc_$PROFILE
- tcappcode:adl
- tcappname:admin
EOF
mkdir /etc/datadog-agent/conf.d/tomcat.d

sudo touch /etc/datadog-agent/conf.d/http_check.d/conf.yaml

aws s3api --endpoint-url https://api-object.bluvalt.com:8082 get-object --bucket riyadh2-prd-tc-application-artifacts --key tcad/tomcat.d_conf.txt /etc/datadog-agent/conf.d/tomcat.d/conf.yaml 
aws s3api --endpoint-url https://api-object.bluvalt.com:8082 get-object --bucket riyadh2-prd-tc-application-artifacts --key tcad/tcad_http_check.txt /etc/datadog-agent/conf.d/http_check.d/conf.yaml
# Fix permissions for datadog-agent
chown -R dd-agent:dd-agent /etc/datadog-agent/

#Adding Cron Jobs
(crontab -l ; echo "0 * * * * find /var/log/ -type f  -name messages -size +1G -exec > /var/log/messages {} \;")| crontab -

# Enable and restart services
systemctl enable datadog-agent
systemctl enable tomcat
systemctl restart datadog-agent
systemctl restart tomcat
