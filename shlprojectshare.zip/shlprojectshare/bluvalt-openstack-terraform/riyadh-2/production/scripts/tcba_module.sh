#!/bin/bash

PROFILE=""
hashi_vault_root_token=""
hashi_vault_server_ip=""
env_type=""

# Initialize parameters specified from command line
while getopts ":p:t:i:e:n:s:d:" arg; do
	case "${arg}" in
		p) 
			PROFILE=${OPTARG}
			;;
    t)
      hashi_vault_root_token=${OPTARG}
      ;;
    i)
      hashi_vault_server_ip=${OPTARG}
      ;;
    e)
      env_type=${OPTARG}
      ;;
    n)
      dns_srv_ip=${OPTARG}
      ;; 
    s)
      dns_srv_ip2=${OPTARG}
      ;;
    d)
      dns_domain=${OPTARG}
      ;;
	esac
done

apt update -y

#Install and enable resolveconf
apt install resolvconf 
sudo systemctl enable --now resolvconf.service
tee /etc/resolvconf/resolv.conf.d/head <<EOF
nameserver $dns_srv_ip
nameserver $dns_srv_ip2
search $dns_domain
EOF
sudo resolvconf -u


# Prevent datadog being updated by apt
apt-mark hold datadog-agent
 
#Stop tomcat if enabled
systemctl stop tomcat
 
# Install latest updates and required packages.
apt update -y

# Update TCAD Configs
TCURL=`curl -H "X-Vault-Token: $hashi_vault_root_token " -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/TCURL | jq '.data.TCURL' | sed 's/"//g'`
TCCDNURL=`curl -H "X-Vault-Token: $hashi_vault_root_token " -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/TCURL| jq '.data.TCURL' | sed 's/"//g'`"\/cdn"
TCDBSERVER=`curl -H "X-Vault-Token: $hashi_vault_root_token " -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/TCDBSERVER | jq '.data.TCDBSERVER' | sed 's/"//g'`
TCReadDBServer=`curl -H "X-Vault-Token: $hashi_vault_root_token " -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/TCREADDBSERVER | jq '.data.TCREADDBSERVER' | sed 's/"//g'`
APPVERSION=`curl -H "X-Vault-Token: $hashi_vault_root_token " -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/APPVERSION | jq '.data.APPVERSION' | sed 's/"//g'`
TCPASSWORD=`curl -H "X-Vault-Token: $hashi_vault_root_token " -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/TCPASSWORD | jq '.data.TCPASSWORD' | sed 's/"//g'`
READTCPASS=`curl -H "X-Vault-Token: $hashi_vault_root_token " -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/READTCPASS | jq '.data.READTCPASS' | sed 's/"//g'`

sed -i "s/#TCURL#/${TCURL}/g" /opt/shl/apache-tomcat/conf/web.xml
sed -i "s/#TCCDNURL#/${TCCDNURL}/g" /opt/shl/apache-tomcat/conf/web.xml
sed -i "s/#TCDBServer#/${TCDBSERVER}/g" /opt/shl/apache-tomcat/conf/database.properties
sed -i "s/#TCPassword#/${TCPASSWORD}/g" /opt/shl/apache-tomcat/conf/database.properties
sed -i "s/#TCReadDBServer#/${TCReadDBServer}/g" /opt/shl/apache-tomcat/conf/database.properties
sed -i "s/#readtcpass#/${READTCPASS}/g" /opt/shl/apache-tomcat/conf/database.properties
sed -i "s/ApplicationName=ADMIN/ApplicationName=Backend Driver/g" /opt/shl/apache-tomcat/conf/database.properties
sed -i "s/#TCProfile#/${PROFILE}/g" /opt/shl/apache-tomcat/bin/setenv.sh
sed -i "s|#LOGFILEFULLPATH#|/opt/shl/apache-tomcat/logs/DriverApplication.log|g" /opt/shl/apache-tomcat/conf/log4j.properties

sed -i "s/#APPNAME#/backenddriver/g" /opt/shl/jmx/jmxremote.access
sed -i "s/#APPNAME#/backenddriver/g" /opt/shl/jmx/jmxremote.password
chmod 0600 /opt/shl/jmx/jmxremote.*

# Doing this here as we may find it difficult to live without port 80
# Ideally this should be configured in the Tomcat archive used by packer
sed -i 's|Connector port="80"|Connector port="8080"|g' /opt/shl/apache-tomcat/conf/server.xml

# Copy WAR files
aws s3api --endpoint-url https://api-object.bluvalt.com:8082  get-object --bucket riyadh2-prd-tc-application-artifacts  --key tcba/${APPVERSION}/backenddriver.war /opt/shl/apache-tomcat/webapps/backenddriver.war

# Fix permissions
chown -R tomcat-s:tomcat-s /opt/shl

# for backend we need to create credentials.properties
tee /opt/shl/apache-tomcat/conf/credentials.properties <<EOF
 
aws_access_key_id : $AWS_ACCESS_KEY_ID
aws_secret_access_key : $AWS_SECRET_ACCESS_KEY
EOF

# Install postfix relay on BA
# The .local version of the name should be resolvable locally.
HOSTNAME=`hostname`
echo "127.0.0.1   $HOSTNAME" >> /etc/hosts

# Fail-safe for smart host param
SMARTHOST=`curl -H "X-Vault-Token: $hashi_vault_root_token " -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/TC_SMTPRELAY | jq '.data.TC_SMTPRELAY' | sed 's/"//g'`

DEBIAN_FRONTEND=noninteractive apt install postfix -y
apt install mailutils -y

tee /etc/postfix/main.cf <<EOF
# See /usr/share/postfix/main.cf.dist for a commented, more complete version
# Debian specific:  Specifying a file name will cause the first
# line of that file to be used as the name.  The Debian default
# is /etc/mailname.
#myorigin = /etc/mailname
smtpd_banner = $myhostname ESMTP shl.com (Ubuntu)
biff = no
# appending .domain is the MUA's job.
append_dot_mydomain = no
# Uncomment the next line to generate "delayed mail" warnings
#delay_warning_time = 4h
readme_directory = no
# See http://www.postfix.org/COMPATIBILITY_README.html -- default to 2 on
# fresh installs.
compatibility_level = 2
# TLS parameters
smtpd_tls_cert_file=/etc/ssl/certs/ssl-cert-snakeoil.pem
smtpd_tls_key_file=/etc/ssl/private/ssl-cert-snakeoil.key
smtpd_tls_security_level=may
smtp_tls_CApath=/etc/ssl/certs
smtp_tls_security_level=may
smtp_tls_session_cache_database = btree:${data_directory}/smtp_scache
smtpd_relay_restrictions = permit_mynetworks permit_sasl_authenticated defer_unauth_destination
myhostname = $HOSTNAME
alias_maps = hash:/etc/aliases
alias_database = hash:/etc/aliases
mydestination = $myhostname, localhost.localdomain, , localhost
relayhost = $SMARTHOST:25
mynetworks = 127.0.0.0/8 [::ffff:127.0.0.0]/104 [::1]/128 10.0.0.0/8
mailbox_size_limit = 0
recipient_delimiter = +
inet_interfaces = all
inet_protocols = all
EOF

if [ $env_type == "prd" ]
then
  echo '# This is a lower env.  Restrict outbound relay domains' >> /etc/postfix/main.cf
  echo 'smtpd_recipient_restrictions = check_recipient_access hash:/etc/postfix/recipient_domains, reject' >> /etc/postfix/main.cf
  echo 'shl.com OK' > /etc/postfix/recipient_domains
  echo 'mailinator.com OK' >> /etc/postfix/recipient_domains
  postmap /etc/postfix/recipient_domains
fi

chmod -R 0644 /etc/postfix

# Configure Datadog Agent
systemctl stop datadog-agent
rm -rf /var/log/datadog-agent/*
DDAPIKEY=`curl -H "X-Vault-Token: $hashi_vault_root_token " -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/DATADOG_APIKEY | jq '.data.DATADOG_APIKEY' | sed 's/"//g'`
tee /etc/datadog-agent/datadog.yaml <<EOF
dd_url: https://app.datadoghq.com
api_key: $DDAPIKEY
logs_enabled: true
log_format_json: false
log_level: DEBUG
log_file: /var/log/datadog/agent.log
log_payloads: false
log_to_console: true
log_to_syslog: false
logging_frequency: 20
apm_config:
  enabled: true
logs_config:
  container_collect_all: false
  dd_port: 10516
  dd_url: agent-intake.logs.datadoghq.com
  dev_mode_use_proto: true
  frame_size: 9000
  open_files_limit: 100
  run_path: ""
  tcp_forward_port: -1
tags:
- system:talentcentral
- application:talentcentral
- env:tc_$PROFILE
- tcappcode:bal
- tcappname:backenddriver
EOF
mkdir /etc/datadog-agent/conf.d/tomcat.d

sudo touch /etc/datadog-agent/conf.d/http_check.d/conf.yaml

aws s3api --endpoint-url https://api-object.bluvalt.com:8082  get-object --bucket riyadh2-prd-tc-application-artifacts --key tcba/tomcat.d_conf.txt /etc/datadog-agent/conf.d/tomcat.d/conf.yaml
aws s3api --endpoint-url https://api-object.bluvalt.com:8082  get-object --bucket riyadh2-prd-tc-application-artifacts --key tcba/postfix_conf.txt /etc/datadog-agent/conf.d/postfix.d/conf.yaml
aws s3api --endpoint-url https://api-object.bluvalt.com:8082  get-object --bucket riyadh2-prd-tc-application-artifacts --key tcba/tcba_http_check.txt /etc/datadog-agent/conf.d/http_check.d/conf.yaml
# Fix permissions for datadog-agent
chown -R dd-agent:dd-agent /etc/datadog-agent/
tee /etc/sudoers.d/dd-agent <<EOF
dd-agent ALL=(postfix) NOPASSWD:/usr/bin/find /var/spool/postfix/incoming -type f
dd-agent ALL=(postfix) NOPASSWD:/usr/bin/find /var/spool/postfix/active -type f
dd-agent ALL=(postfix) NOPASSWD:/usr/bin/find /var/spool/postfix/deferred -type f
EOF

#Give dd-agent read access to postfix logs
apt-get install acl -y
/usr/bin/setfacl -m g:dd-agent:rx /var/log/mail.log
tee /etc/logrotate.d/postfixlog_acls << EOF
/var/log/maillog_rotate
{
    postrotate
         su root syslog
        /usr/bin/setfacl -m g:dd-agent:rx /var/log/mail.log
        touch /var/log/maillog_rotate
    endscript
}
EOF
touch /var/log/maillog_rotate
chmod 0644 /etc/logrotate.d/postfixlog_acls
chmod 0644 /var/log/maillog_rotate
logrotate -vf /etc/logrotate.d/postfixlog_acls


mkdir /tmp/BulkReports/
chown tomcat-s:tomcat-s /tmp/BulkReports

#Adding Cron Jobs
(crontab -l ; echo "0 * * * * find /var/log/ -type f  -name messages -size +1G -exec > /var/log/messages {} \;")| crontab -

# Enable and restart services
systemctl enable datadog-agent
systemctl enable tomcat
systemctl enable postfix
systemctl restart datadog-agent
systemctl restart tomcat
systemctl restart postfix
