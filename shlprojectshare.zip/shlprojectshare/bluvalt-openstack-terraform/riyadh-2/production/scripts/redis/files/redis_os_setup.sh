#!/bin/bash
echo "vm.overcommit_memory = 1" >> /etc/sysctl.conf
echo "vm.swappiness = 0" >> /etc/sysctl.conf
echo "never" > /sys/kernel/mm/transparent_hugepage/enabled
sed -i "s/#DefaultLimitNOFILE=/DefaultLimitNOFILE=65536/g" /etc/systemd/system.conf

