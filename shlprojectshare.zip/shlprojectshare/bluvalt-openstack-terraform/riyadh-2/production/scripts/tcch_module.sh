#!/bin/bash -v

PROFILE=""
hashi_vault_root_token=""
hashi_vault_server_ip=""
 
# Initialize parameters specified from command line
while getopts ":p:t:i:n:s:d:" arg; do
  case "${arg}" in
    p)
      PROFILE=${OPTARG} 
      ;;
    t)
      hashi_vault_root_token=${OPTARG}
      ;;
    i)
      hashi_vault_server_ip=${OPTARG}
      ;;
    n)
      dns_srv_ip=${OPTARG}
      ;;
    s)
      dns_srv_ip2=${OPTARG}
      ;;
    d)
      dns_domain=${OPTARG}
      ;; 
  esac
done

apt update -y

#Install and enable resolveconf
apt install resolvconf 
sudo systemctl enable --now resolvconf.service
tee /etc/resolvconf/resolv.conf.d/head <<EOF
nameserver $dns_srv_ip
nameserver $dns_srv_ip2
search $dns_domain
EOF
sudo resolvconf -u

HOSTNAME=`hostname`
echo "127.0.0.1   $HOSTNAME" >> /etc/hosts

apt install ruby -y
DEBIAN_FRONTEND=noninteractive apt install jq mailutils -y
# Add mssql-tools repo
wget -qO- https://packages.microsoft.com/keys/microsoft.asc | sudo apt-key add -
curl https://packages.microsoft.com/config/ubuntu/20.04/prod.list | sudo tee /etc/apt/sources.list.d/msprod.list
# Install mssql-tools
apt update -y
export ACCEPT_EULA=y
apt install mssql-tools unixodbc-dev -y
echo "PATH=\"$PATH:/opt/mssql-tools/bin\"" >> /etc/environment
source /etc/environment

# Prevent datadog being updated by apt
apt-mark hold datadog-agent

# Install latest updates and required packages.
apt update -y

echo "$PROFILE" > /opt/shl/tc-cache/profile.txt

InstanceID=`hostname`_`hostname -I`

APPVERSION=`curl -H "X-Vault-Token: $hashi_vault_root_token " -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/APPVERSION | jq '.data.APPVERSION' | sed 's/"//g'`

# Copy tc-cache.jar from versioned location
aws s3api --endpoint-url https://api-object.bluvalt.com:8082  get-object --bucket tc-application-artifacts --key  tcch/${APPVERSION}/tc-cache.jar /opt/shl/tc-cache/tc-cache.jar
chown root:root /opt/shl/tc-cache/tc-cache.jar
aws s3api --endpoint-url https://api-object.bluvalt.com:8082 get-object --bucket riyadh2-prd-tc-application-artifacts --key tcch/tcch_http_check.txt /etc/datadog-agent/conf.d/http_check.d/conf.yaml

mkdir /opt/shl/tc-cache/scripts
echo "curl http://localhost:2080/content/load/all" > /opt/shl/tc-cache/scripts/loadall.sh
echo "curl http://localhost:2080/content/cacheStatus" > /opt/shl/tc-cache/scripts/cachestatus.sh
echo "curl http://localhost:2080/content/load/cp" > /opt/shl/tc-cache/scripts/loadcp.sh
echo "curl http://localhost:2080/content/load/localizedcontentsdisplayname" > /opt/shl/tc-cache/scripts/loadlocalizedcontentsdisplayname.sh
echo "curl http://localhost:2080/content/load/scalenorms" > /opt/shl/tc-cache/scripts/loadscalenorms.sh
echo "curl http://localhost:2080/content/load/normcategories" > /opt/shl/tc-cache/scripts/loadnormcategories.sh
echo "curl http://localhost:2080/content/load/scalenorms" > /opt/shl/tc-cache/scripts/loadscalenorms.sh
echo "curl http://localhost:2080/content/load/questions" > /opt/shl/tc-cache/scripts/loadquestions.sh
echo "curl http://localhost:2080/content/load/assessments" > /opt/shl/tc-cache/scripts/loadassessments.sh
echo "curl http://localhost:2080/content/load/media" > /opt/shl/tc-cache/scripts/loadmedia.sh
echo "curl http://localhost:2080/content/assessment/\$1" > /opt/shl/tc-cache/scripts/contentassessment.sh
echo "curl http://localhost:2080/content/assessment/\$1/questions" > /opt/shl/tc-cache/scripts/contentassessmentquestions.sh
echo "curl http://localhost:2080/content/assessment/\$1/sections" > /opt/shl/tc-cache/scripts/contentassessmentsections.sh
echo "curl http://localhost:2080/content/question/\$1" > /opt/shl/tc-cache/scripts/contentquestion.sh
echo "curl http://localhost:2080/content/package/\$1" > /opt/shl/tc-cache/scripts/contentpackage.sh
chmod +x /opt/shl/tc-cache/scripts/*.sh

# Create application.properties for TCCH
TCURL=`curl -H "X-Vault-Token: $hashi_vault_root_token " -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/TCURL | jq '.data.TCURL' | sed 's/"//g'`
TCCDNURL=`curl -H "X-Vault-Token: $hashi_vault_root_token " -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/TCURL| jq '.data.TCURL' | sed 's/"//g'`"\/cdn"
TCDBSERVER=`curl -H "X-Vault-Token: $hashi_vault_root_token " -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/TCDBSERVER | jq '.data.TCDBSERVER' | sed 's/"//g'`
TCReadDBServer=`curl -H "X-Vault-Token: $hashi_vault_root_token " -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/TCREADDBSERVER | jq '.data.TCREADDBSERVER' | sed 's/"//g'`
# use secrets manager
TCPASSWORD=`curl -H "X-Vault-Token: $hashi_vault_root_token " -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/TCPASSWORD | jq '.data.TCPASSWORD' | sed 's/"//g'`
READTCPASS=`curl -H "X-Vault-Token: $hashi_vault_root_token " -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/READTCPASS | jq '.data.READTCPASS' | sed 's/"//g'`

# Write out main TCCH config file
tee /opt/shl/tc-cache/application.properties <<EOF
#new application.properties template
spring.datasource.url=jdbc:jtds:sqlserver://$TCDBSERVER:1605/TalentCentral
spring.datasource.username=tomcat-s
spring.datasource.password=$TCPASSWORD
spring.datasource.driver-class-name=net.sourceforge.jtds.jdbc.Driver
spring.jpa.hibernate.dialect=org.hibernate.dialect.SQLServer2012Dialect
spring.hibernate.hbm2ddl.auto=none
spring.datasource.tomcat.validationQuery=SELECT 1
spring.datasource.tomcat.testOnBorrow=true

#read-only DB properties
spring.replica.datasource.url=jdbc:jtds:sqlserver://$TCReadDBServer:1605/TalentCentral
spring.replica.datasource.username=tomcatread-s
spring.replica.datasource.password=$READTCPASS

#server.port=

#spring.redis.host=
#spring.redis.password=
#spring.redis.port=6379

log4j.rootLogger=INFO, R, stdout
log4j.appender.stdout=org.apache.log4j.ConsoleAppender
log4j.appender.stdout.layout=org.apache.log4j.PatternLayout
log4j.appender.stdout.layout.ConversionPattern=%d [%t] %-5p %c - %m%n
log4j.appender.R=org.apache.log4j.RollingFileAppender
log4j.appender.R.MaxFileSize=20000KB
log4j.appender.R.MaxBackupIndex=10
log4j.appender.R.layout=org.apache.log4j.PatternLayout
log4j.appender.R.layout.ConversionPattern=%d [%t] %-5p %c - %m%n
log4j.logger.org.hibernate.type=ERROR

log4j.appender.R.File=/opt/shl/logs/tc-cache.log

cache.scheduled.task.enabled=true
cache.update.delay.seconds=300

#solr.serverUrl=
ehcache.url=http://$TCURL/admin/tcehcache/evictehcache
package.evict.url=http://$TCURL/admin/tcehcache/evictcontentpackagesettings
#prop.jms.brokerURL=!!not defined in this file!!
EOF
chmod 755 /opt/shl/tc-cache/application.properties

# Update TCCH start-up script
rm -rf /opt/shl/tc-cache/startup.sh
tee /opt/shl/tc-cache/startup.sh <<EOF
/usr/bin/java -Xmx6144m -Xms2048m -Dspring.profiles.active=\`cat /opt/shl/tc-cache/profile.txt\` -Dspring.config.location=file:/opt/shl/tc-cache/application.properties -Dserver.port=2080 -Dlog4j.configuration=file:/opt/shl/tc-cache/config/log4j.properties -jar /opt/shl/tc-cache/tc-cache.jar 
EOF

DDAPIKEY=`curl -H "X-Vault-Token: $hashi_vault_root_token " -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/DATADOG_APIKEY | jq '.data.DATADOG_APIKEY' | sed 's/"//g'`
systemctl stop datadog-agent
tee /etc/datadog-agent/datadog.yaml <<EOF
dd_url: https://app.datadoghq.com
api_key: $DDAPIKEY
logs_enabled: true
log_format_json: false
log_level: DEBUG
log_file: /var/log/datadog/agent.log
log_payloads: false
log_to_console: true
log_to_syslog: false
logging_frequency: 20
apm_config:
  enabled: true
logs_config:
  container_collect_all: false
  dd_port: 10516
  dd_url: agent-intake.logs.datadoghq.com
  dev_mode_use_proto: true
  frame_size: 9000
  open_files_limit: 100
  run_path: ""
  tcp_forward_port: -1
tags:
- system:talentcentral
- application:talentcentral
- env:tc_$PROFILE
- tcappcode:tcch
- tcappname:tc-cache
EOF
mkdir /etc/datadog-agent/conf.d/tc_cache.d

sudo touch /etc/datadog-agent/conf.d/http_check.d/conf.yaml

tee /etc/datadog-agent/conf.d/tc_cache.d/conf.yaml <<EOF
logs:
    - type: file
      path: /opt/shl/logs/tc-cache.log
      service: tc-cache
      source: java
      log_processing_rules:
      - type: multi_line
        name: new_log_start_with_date
        pattern: \d{4}\-(0?[1-9]|1[012])\-(0?[1-9]|[12][0-9]|3[01])
EOF

TCNXURL=`curl -H "X-Vault-Token: $hashi_vault_root_token " -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/TCILB | jq '.data.TCILB' | sed 's/"//g'`

systemctl start datadog-agent
systemctl start tc-cache

#sleep for 60sec to tc-cache available
sleep 60
curl http://localhost:2080/content/load/all --max-time 3600
FINISHED=$(grep -c "done loading all cache objects..." /opt/shl/logs/tc-cache.log)

if [[ $FINISHED != "0" ]]; then
  # Everything went fine, email the team
  echo "SUCCESS running cache load in $TCURL $TCDBSERVER $InstanceID" | mailx -s "TCCH Success: $InstanceID" -r devops@shl.com devops@shl.com
else
  # Something went wrong, email the team
  echo "Failure running cache load in $TCURL $TCDBSERVER $InstanceID" | mailx -s "TCCH Failure: $InstanceID" -r devops@shl.com devops@shl.com
fi

# Create tc-redis-cli wrapper script
REDISURL=`curl -H "X-Vault-Token: $hashi_vault_root_token " -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-services/TC_REDIS_URL | jq '.data.TC_REDIS_URL' | sed 's/"//g'`

cat <<EOF >> /usr/bin/tc-redis-cli
#!/bin/sh
exec redis-cli -h $REDISURL -p 6379 "\$@"
EOF
chmod +x /usr/bin/tc-redis-cli

#Create the Script to Load SOLR Master
SMTPRELAY=`curl -H "X-Vault-Token: $hashi_vault_root_token " -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/TC_SMTPRELAY | jq '.data.TC_SMTPRELAY' | sed 's/"//g'`
cat <<EOF >> /opt/shl/load-solr.sh 
#!/bin/bash

#Get the number of documents in the master solr node collection
COLLECTIONCOUNT=\$(curl http://$TCNXURL:8984/solr/collection1/query?q=*:* | jq -r '.response.numFound')
if [[ "\$COLLECTIONCOUNT" -lt 1000 ]]; then
    echo "the collection contains less than 1000 documents"
    #if the collection has less than 1000 documents, we should run load cp but need to check a few things first
    #check to see if this is a new environment (could already be waiting to run intial load all)--ignore that as we can create the job after the script runs initial load all for an environment
    #check to see if load/cp is running already; if so, stop
    LINESTART=\$(tac /opt/shl/logs/tc-cache.log | grep -n -m1 "deleting all content packages from cache..." | cut -d : -f 1 )
    LINEEND=\$(tac /opt/shl/logs/tc-cache.log | grep -n -m1 "loading content package complete" | cut -d : -f 1 )
    STARTEDLOADALL=$(grep -c "done loading all cache objects..." /opt/shl/logs/tc-cache.log)
    if [[ \$LINEEND == "" ]] && [[ \$LINESTART == "" ]]; then
        echo "starting load/cp as it has never been run on this instance"
        #echo "Running load/cp for the VERY FIRST time for SOLR in $TCNXURL on TCCH instance: $InstanceID" | mailx -s "Load/cp Running: $TCNXURL on TCCH instance: $InstanceID" -S smtp="$SMTPRELAY" -r devops@shl.com devops@shl.com
        echo "Running load/cp for the VERY FIRST time for SOLR in $TCNXURL on TCCH instance: $InstanceID" | mailx -s "Load/cp Running: $TCNXURL on TCCH instance: $InstanceID" -r devops@shl.com devops@shl.com
        curl -X POST -H 'Content-type: application/json' --data '{"text":"Running load/cp for the VERY FIRST time for SOLR in $TCNXURL on TCCH instance: $InstanceID"}' https://hooks.slack.com/services/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
        curl http://localhost:2080/content/load/cp --max-time 1200
    elif [[ "\$LINEEND" = "" ]] && [[ \$LINESTART != "" ]]; then
        echo "loading content package has not completed"
        #echo "Running load/cp has not completed for SOLR in $TCNXURL on TCCH instance: $InstanceID" | mailx -s "Load/cp has not completed: $TCNXURL on TCCH instance: $InstanceID" -S smtp="$SMTPRELAY" -r devops@shl.com devops@shl.com
        echo "Running load/cp has not completed for SOLR in $TCNXURL on TCCH instance: $InstanceID" | mailx -s "Load/cp has not completed: $TCNXURL on TCCH instance: $InstanceID" -r devops@shl.com devops@shl.com
        curl -X POST -H 'Content-type: application/json' --data '{"text":"Running load/cp has not completed for SOLR in $TCNXURL on TCCH instance: $InstanceID"}' https://hooks.slack.com/services/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
        break
    #compare the line numbers to make sure the loading completes is after the deleting all content packages line number (numbers will be reversed order, so lower is after the higher)
    elif [[ \$LINEEND -lt \$LINESTART ]]; then
        echo "load/cp is not currently running"
        echo "starting load/cp"
        curl http://localhost:2080/content/load/cp --max-time 1200
    fi
    NEWLINESTART=\$(tac /opt/shl/logs/tc-cache.log | grep -n -m1 "deleting all content packages from cache..." | cut -d : -f 1 )
    echo "NEWLINESTART is:  \$NEWLINESTART"
    NEWLINEEND=\$(tac /opt/shl/logs/tc-cache.log | grep -n -m1 "loading content package complete" | cut -d : -f 1 )
    echo "NEWLINEEND is:  \$NEWLINEEND"
    while [[ \$NEWLINEEND -gt \$NEWLINESTART ]]
    do
        echo "waiting for solr load/cp to complete"
        sleep 1
        NEWLINESTART=\$(tac /opt/shl/logs/tc-cache.log | grep -n -m1 "deleting all content packages from cache..." | cut -d : -f 1 )
        NEWLINEEND=\$(tac /opt/shl/logs/tc-cache.log | grep -n -m1 "loading content package complete" | cut -d : -f 1 )
    done
    echo "load/cp completed"
    #check collection count now to ensure it is over 1000
    COLLECTIONCOUNTNEW=\$(curl http://$TCNXURL:8984/solr/collection1/query?q=*:* | jq -r '.response.numFound')
    if [[ "\$COLLECTIONCOUNTNEW" != "" ]]; then
        if [[ "\$COLLECTIONCOUNTNEW" -lt 1000 ]]; then
            echo "SOLR Master Collection count is still below 1000"
            #email the team
            #echo "Possible Failure running load/cp for SOLR in $TCNXURL on TCCH instance: $InstanceID" | mailx -s "Load/cp Possible Failure: $TCNXURL on TCCH instance: $InstanceID" -S smtp="$SMTPRELAY" -r devops@shl.com devops@shl.com
            echo "Possible Failure running load/cp for SOLR in $TCNXURL on TCCH instance: $InstanceID" | mailx -s "Load/cp Possible Failure: $TCNXURL on TCCH instance: $InstanceID" -r devops@shl.com devops@shl.com
            #also send to slack channel
            curl -X POST -H 'Content-type: application/json' --data '{"text":"Possible Failure running load/cp for SOLR in $TCNXURL on TCCH instance: $InstanceID"}' https://hooks.slack.com/services/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
            curl -X POST -H 'Content-type: application/json' --data '{"text":"Possible Failure running load/cp for SOLR in $TCNXURL on TCCH instance: $InstanceID"}' https://hooks.slack.com/services/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
        else
            echo "SOLR Master Collection is above 1000, enabling replication from master"
            curl http://$TCNXURL:8984/solr/collection1/replication?command=enablereplication
            #email the team
            #echo "SUCCESS running load/cp for SOLR in $TCNXURL on TCCH instance: $InstanceID" | mailx -s "Load/cp Success: $TCNXURL on TCCH instance: $InstanceID" -S smtp="$SMTPRELAY" -r devops@shl.com devops@shl.com
            echo "SUCCESS running load/cp for SOLR in $TCNXURL on TCCH instance: $InstanceID" | mailx -s "Load/cp Success: $TCNXURL on TCCH instance: $InstanceID" -r devops@shl.com devops@shl.com
            #also send to slack channel
            curl -X POST -H 'Content-type: application/json' --data '{"text":"SUCCESS running load/cp for SOLR in $TCNXURL on TCCH instance: $InstanceID"}' https://hooks.slack.com/services/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
        fi
    fi
fi
EOF
chmod 755 /opt/shl/load-solr.sh

#Add Cron job
cat > /etc/cron.d/solrload << EOF
*/5 * * * * root /bin/bash /opt/shl/load-solr.sh
EOF

systemctl start cron
systemctl enable cron