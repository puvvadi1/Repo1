#!/bin/bash
echo 'Installing Rapid7 on Ubuntu-20.04 .. '

RAPID7_CUSTOMTOKEN=""

# Initialize parameters specified from command line
while getopts ":t:" arg; do
  case "${arg}" in
    t)
      RAPID7_CUSTOMTOKEN=${OPTARG}
      ;;
  esac
done

TOKEN=$RAPID7_CUSTOMTOKEN
SEDISABLED=$(sestatus | grep disabled | wc -l)

if [[ $SEDISABLED == 1 ]]; then
  echo "SELinux is disabled, continuing .. "

  echo "Disabling auditd .. "
  service auditd stop
  systemctl disable auditd

  echo "Install Rapid7 agent .. "
  chmod u+x /tmp/rapid7/agent_installer.sh
  sudo /bin/bash /tmp/rapid7/agent_installer.sh install_start --token $TOKEN

else
  echo "SELinux is enabled.  Stopping without installing the agent."
fi