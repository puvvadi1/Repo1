#!/bin/bash

echo "Uninstalling Rapid7 on Ubuntu .. "

/tmp/rapid7/agent_installer.sh uninstall

echo "Uninstalling auditd .. "
# Re-enable auditd
service auditd start
systemctl enable auditd