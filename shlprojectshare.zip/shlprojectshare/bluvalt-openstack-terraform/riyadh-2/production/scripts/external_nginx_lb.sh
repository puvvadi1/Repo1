#!/bin/bash
################### THE below code block is to install the datadog from the vault itself ######################

hashi_vault_root_token=""
hashi_vault_server_ip=""
PROFILE = ""
 
# Initialize parameters specified from command line
while getopts ":t:i:p:" arg; do
  case "${arg}" in
    t)
      hashi_vault_root_token=${OPTARG}
      ;;
    i)
      hashi_vault_server_ip=${OPTARG}
      ;;
     p)
      PROFILE=${OPTARG}
      ;; 
   
  esac
done

#!/bin/bash
################### THE below script is to install the nginx and configure upstream servers ########################
sudo apt-get update -y
#sudo apt-get install openjdk-8-jdk -y
######## Installing latest/default nginx ############

sudo apt install net-tools -y


sudo apt install nginx -y
sudo apt-get install nginx-extras -y 
sudo apt-get install nginx-plus-module-perl -y 
sudo apt-get install perl -y 


############################## Adding the upstream server details in configuration file ###################
###########Taking the backup of existing conf file ###################
sudo chown -R ubuntu:ubuntu /etc/nginx

sudo cat <<EOF > /etc/nginx/nginx.conf
user www-data;
worker_processes auto;
pid /run/nginx.pid;
#load_module /usr/lib/nginx/modules/ngx_http_perl_module.so;
include /etc/nginx/modules-enabled/*.conf;

events {
worker_connections 768;
# multi_accept on;
}

http {
client_max_body_size 500M;

sendfile on;
tcp_nopush on;
tcp_nodelay on;
keepalive_timeout 65;
types_hash_max_size 2048;

include /etc/nginx/mime.types;
default_type application/octet-stream;

limit_req_zone \$binary_remote_addr zone=mylimit:10m rate=480r/m;

ssl_protocols TLSv1 TLSv1.1 TLSv1.2 TLSv1.3; # Dropping SSLv3, ref: POODLE
ssl_prefer_server_ciphers on;

access_log /var/log/nginx/access.log;
error_log /var/log/nginx/error.log debug;
rewrite_log on;
gzip on;

include /etc/nginx/conf.d/*.conf;
include /etc/nginx/conf.d/applications;
#include /etc/nginx/conf.d/applications_ip_772021;

upstream tcad {
server tcad1.sa.shl.com:8080 max_fails=3 fail_timeout=10s;
server tcad2.sa.shl.com:8080 max_fails=3 fail_timeout=10s;
}

upstream tcvp {
server tcvp1.sa.shl.com:8080 max_fails=3 fail_timeout=10s;
server tcvp2.sa.shl.com:8080 max_fails=3 fail_timeout=10s;
}


upstream tciw {
server tciw1.sa.shl.com:80 max_fails=3 fail_timeout=10s;
server tciw2.sa.shl.com:80 max_fails=3 fail_timeout=10s;
}

upstream cdn {
server talentcentral-cdn-zone1.sa.shl.com:80;
server talentcentral-cdn-zone2.sa.shl.com:80;
}

upstream mqr {
server talentcentral-mqr-zone1.sa.shl.com:8080;
server talentcentral-mqr-zone2.sa.shl.com:8080;
}

upstream mq-api {
server talentcentral-mq-api-zone1.sa.shl.com:8080;
server talentcentral-mq-api-zone2.sa.shl.com:8080;
}


upstream tcai {
server integration-talentcentral-ai-zone1.sa.shl.com:8080 max_fails=3 fail_timeout=10s;
server integration-talentcentral-ai-zone2.sa.shl.com:8080 max_fails=3 fail_timeout=10s;
}

}

EOF

sudo cp /etc/nginx/nginx.conf /etc/nginx/nginx.conf_bkp



###################### adding the proxy details in default file ####################################

sudo cat <<EOF > /etc/nginx/conf.d/applications
map $http_x_forwarded_for $block {
        include /etc/nginx/conf.d/regional-shl-outbound-ip-range.map;
        #default 1;
}

server {
listen 80 default_server;
#listen [::]:80 default_server;
server_name _;
return 301 https://\$host\$request_uri;

root /var/www/html;

# Add index.php to the list if you are using PHP
index index.html index.htm index.nginx-debian.html;


location /admin {
proxy_redirect off;
proxy_set_header Host talentcentral.sa.shl.com;
proxy_pass http://tcad;
}

location /admin* {
proxy_redirect off;
proxy_set_header Host talentcentral.sa.shl.com;
proxy_pass http://tcad;
}

location /player {
proxy_redirect off;
proxy_set_header Host talentcentral.sa.shl.com;
proxy_pass http://tcvp;
}

location /opq {
proxy_redirect off;
proxy_set_header Host talentcentral.sa.shl.com;
proxy_pass http://tcvp;
}

location /cdn {
#rewrite ^(.*)[A-Z]+(.*)\$ https://$host$uri_lowercase;
if (\$request_uri ~ [a-z]) {
rewrite ^(.*)[A-Z]+(.*)\$ https://$host$uri_lowercase;
}
proxy_redirect off;
#proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
proxy_set_header Host talentcentral.sa.shl.com;
proxy_pass http://cdn;
#limit_req zone=mylimit burst=5 nodelay;
#limit_req_status 403;
#break;
}


location /mq-api {
proxy_redirect off;
proxy_set_header Host talentcentral.sa.shl.com;
proxy_pass http://mq-api;
#break;
}

location /mq {
proxy_redirect off;
proxy_set_header Host talentcentral.sa.shl.com;
proxy_pass http://mqr;
#break;
}

location /integrationtools/dependencyhealthchecks/webserver {
proxy_pass http://tciw;
limit_req zone=mylimit burst=5 nodelay;
limit_req_status 403;
}

location /integration/ {
proxy_pass http://tciw;
limit_req zone=mylimit burst=5 nodelay;
limit_req_status 403;
}

location /integrationtools/ {
if ( \$http_x_forwarded_for != \$block ) { return 403; }
proxy_pass http://tciw;
limit_req zone=mylimit burst=5 nodelay;
limit_req_status 403;
}

location /Integration/ {
proxy_pass http://tciw;
limit_req zone=mylimit burst=5 nodelay;
limit_req_status 403;
}

location /IntegrationTools/ {
if ( \$http_x_forwarded_for != \$block ) { return 403; }
proxy_pass http://tciw;
limit_req zone=mylimit burst=5 nodelay;
limit_req_status 403;
}

location /cdn {
#rewrite ^(.*)[A-Z]+(.*)\$ https://\$host\$uri_lowercase;
if (\$request_uri ~ [a-z]) {
rewrite ^(.*)[A-Z]+(.*)\$ https://\$host\$uri_lowercase;
}
proxy_redirect off;
#proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
proxy_set_header Host talentcentral.sa.shl.com;
proxy_pass http://cdn;

#break;
}


location /mq-api {
proxy_redirect off;
proxy_set_header Host talentcentral.sa.shl.com;
proxy_pass http://mq-api;
#break;
}

location /mq {
proxy_redirect off;
proxy_set_header Host talentcentral.sa.shl.com;
proxy_pass http://mqr;
#break;
}

location /admin/integration {
if (\$request_uri ~ [A-Z]) {
rewrite ^(.*)\$ https://\$host\$uri_lowercase;
}
proxy_redirect off;
proxy_set_header Host talentcentral.sa.shl.com;
proxy_pass http://tcai;
}

}

server {
       listen 443 ssl;
       #ssl on;
       ssl_certificate /etc/letsencrypt/live/sa.shl.com/fullchain1.pem;
       ssl_certificate_key /etc/letsencrypt/live/sa.shl.com/privkey1.pem;
       ssl_protocols TLSv1.2 TLSv1.1 TLSv1;
       server_name _;
 #     return 301 https://\$server_name\$request_uri;
root /var/www/html;
index index.html index.htm index.nginx-debian.html;


location /admin {
proxy_redirect off;
proxy_set_header Host talentcentral.sa.shl.com;
proxy_pass http://tcad;
}

location /admin* {
proxy_redirect off;
proxy_set_header Host talentcentral.sa.shl.com;
proxy_pass http://tcad;
}

location /player {
proxy_redirect off;
proxy_set_header Host talentcentral.sa.shl.com;
proxy_pass http://tcvp;
}

location /opq {
proxy_redirect off;
proxy_set_header Host talentcentral.sa.shl.com;
proxy_pass http://tcvp;
}


location /integrationtools/dependencyhealthchecks/webserver {
proxy_pass http://tciw;
limit_req zone=mylimit burst=5 nodelay;
limit_req_status 403;
}

location /integration/ {
proxy_pass http://tciw;
limit_req zone=mylimit burst=5 nodelay;
limit_req_status 403;
}

location /integrationtools/ {
if ( \$http_x_forwarded_for != \$block ) { return 403; }
proxy_pass http://tciw;
limit_req zone=mylimit burst=5 nodelay;
limit_req_status 403;
}

location /Integration/ {
proxy_pass http://tciw;
limit_req zone=mylimit burst=5 nodelay;
limit_req_status 403;
}

location /IntegrationTools/ {
if ( \$http_x_forwarded_for != \$block ) { return 403; }
proxy_pass http://tciw;
limit_req zone=mylimit burst=5 nodelay;
limit_req_status 403;
}



location /admin/integration {
if (\$request_uri ~ [A-Z]) {
rewrite ^(.*)\$ https://\$host\$uri_lowercase;
}
proxy_redirect off;
proxy_set_header Host talentcentral.sa.shl.com;
proxy_pass http://tcai;
}

}

EOF
sudo cp /etc/nginx/conf.d/applications /etc/nginx/conf.d/applications_bkp


sudo cat <<EOF > /etc/nginx/conf.d/perl-regex.conf
perl_modules perl/lib;



perl_set \$uri_lowercase '
    sub {
            my \$r = shift;
            my \$uri =\$r->uri;
            \$uri = lc(\$uri);
            return \$uri;
   }
';
EOF

sudo cat <<EOF > /etc/nginx/conf.d/regional-shl-outbound-ip-range.map

3.122.184.113 32;
89.187.99.0 25;
35.157.229.19 32;
37.46.6.32 27;
18.216.107.94 32;
34.254.52.133 32;
192.184.115.0 24;
13.234.6.58 32;
27.111.250.128 25;
10.221.6.121 32;
10.181.1.169 32;
89.187.118.0 24;
13.233.29.123 32;
69.171.27.0 24;
103.204.73.128 27;
34.254.15.170 32;
18.184.243.194 32;
35.156.219.213 32;
13.55.234.104 32;
18.191.116.100 32;
18.184.97.40 32;
52.64.153.43 32;
101.230.200.48 28;
10.221.13.55 32;

EOF

sudo cat <<EOF > /etc/resolv.conf
# This file is managed by man:systemd-resolved(8). Do not edit.
#
# This is a dynamic resolv.conf file for connecting local clients to the
# internal DNS stub resolver of systemd-resolved. This file lists all
# configured search domains.
#
# Run "systemd-resolve --status" to see details about the uplink DNS servers
# currently in use.
#
# Third party programs must not access this file directly, but only through the
# symlink at /etc/resolv.conf. To manage man:resolv.conf(5) in a different way,
# replace this symlink by a static file or a different symlink.
#
# See man:systemd-resolved.service(8) for details about the supported modes of
# operation for /etc/resolv.conf.

search sa.shl.com
nameserver 10.211.16.27
nameserver 10.211.16.32

nameserver 127.0.0.53
options edns0

EOF


sudo cat <<EOF > /etc/nginx/conf.d/timeout.conf
proxy_connect_timeout       600;
proxy_send_timeout          600;
proxy_read_timeout          600;
send_timeout                600;
#client_max_body_size        500M;
EOF

####add sudo if required and check script and remove unwanted comments
sudo apt update -y
sudo apt install jq -y
sudo wget https://s3.amazonaws.com/dd-agent/scripts/install_script.sh
sudo cp install_script.sh /tmp/
sudo chmod +x /tmp/install_script.sh

DDAPIKEY=`curl -H "X-Vault-Token:$hashi_vault_root_token" -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/DATADOG_APIKEY | jq '.data.DATADOG_APIKEY' | sed 's/"//g'` 

echo $DDAPIKEY >> /tmp

DD_AGENT_MAJOR_VERSION=7 DD_API_KEY=$DDAPIKEY DD_SITE="datadoghq.com" bash /tmp/install_script.sh

systemctl stop datadog-agent

sudo cat <<EOF > /etc/datadog-agent/datadog.yaml
dd_url: https://app.datadoghq.com
api_key: $DDAPIKEY
logs_enabled: true
log_format_json: false
log_level: DEBUG
log_file: /var/log/datadog/agent.log
log_payloads: false
log_to_console: true
log_to_syslog: false
logging_frequency: 20
apm_config:
  enabled: true
logs_config:
  container_collect_all: false
  dd_port: 10516
  dd_url: agent-intake.logs.datadoghq.com
  dev_mode_use_proto: true
  frame_size: 9000
  open_files_limit: 100
  run_path: ""
  tcp_forward_port: -1
tags:
- system:talentcentral
- application:talentcentral
- env:tc_$PROFILE
- tcappcode:tccnnginx
- tcappname:tccnnginx

EOF

sudo chmod 644 /var/log/nginx/access.log
sudo chmod 644 /var/log/nginx/error.log

sudo cat <<EOF > /etc/datadog-agent/conf.d/nginx.d/conf.yaml
init_config:

instances:
  - nginx_status_url: http://localhost:81/nginx_status/

logs:
    - type: file
      path: /var/log/nginx/access.log
      service: nginx
      source: nginx
      sourcecategory: http_web_access

    - type: file
      path: /var/log/nginx/error.log
      service: nginx
      source: nginx
      sourcecategory: http_web_access

EOF

chown dd-agent:dd-agent /etc/datadog-agent/datadog.yaml
chown dd-agent:dd-agent /etc/datadog-agent/conf.d/nginx.d/conf.yaml

# sudo mv /etc/nginx/sites-available/applicatiions /etc/nginx/conf.d/ 
################# Post configuration changes , doing the restart of nginx servie #####################
sudo chown -R root:root /etc/nginx
sudo systemctl stop nginx
sudo systemctl start nginx
echo "Line number 548"

sudo cat <<EOF > /etc/nginx/conf.d/timeout.conf
proxy_connect_timeout       600;
proxy_send_timeout          600;
proxy_read_timeout          600;
send_timeout                600;
#client_max_body_size        500M;
EOF

sudo cat <<EOF > /etc/nginx/conf.d/status.conf
server {
  listen 81;
  server_name localhost;
  access_log off;
  allow 127.0.0.1;
  deny all;
location /nginx_status {
    # Choose your status module
    # freely available with open source NGINX
    stub_status;
    # for open source NGINX < version 1.7.5
    # stub_status on;
    # available only with NGINX Plus
    # status;
    # ensures the version information can be retrieved
    server_tokens on;
  }
}

EOF

chown dd-agent:dd-agent /etc/nginx/conf.d/status.conf

sudo systemctl enable datadog-agent
sudo systemctl restart datadog-agent