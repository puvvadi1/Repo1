#!/bin/bash
sudo apt-get purge falcon-sensor
