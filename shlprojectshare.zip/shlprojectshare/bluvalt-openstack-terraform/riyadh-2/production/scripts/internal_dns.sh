#!/bin/bash
sudo apt-get update -y
sudo apt-get install bind9 bind9utils bind9-doc -y
serverip=`hostname -I`

sudo apt install jq -y

sudo cat <<EOF > /etc/default/bind9
#
# run resolvconf?
RESOLVCONF=no

# startup options for the server
OPTIONS="-u bind -4"
EOF

echo ${hashi_vault_root_token} >> /tmp/dnsnames;
echo ${hashi_vault_server_ip}>> /tmp/dnsnames;
 
#DNS names from vault
DOMAIN=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/DOMAIN | jq '.data.DOMAIN' | sed 's/"//g'`
INTERNALDOMAIN=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/INTERNALDOMAIN | jq '.data.INTERNALDOMAIN' | sed 's/"//g'`
EXTERNALDOMAIN=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/EXTERNALDOMAIN | jq '.data.EXTERNALDOMAIN' | sed 's/"//g'`

TCADDOMAIN1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCADDOMAIN1 | jq '.data.TCADDOMAIN1' | sed 's/"//g'`
TCADDOMAIN2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCADDOMAIN2 | jq '.data.TCADDOMAIN2' | sed 's/"//g'`

TCBADOMAIN1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCBADOMAIN1 | jq '.data.TCBADOMAIN1' | sed 's/"//g'`
TCBADOMAIN2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCBADOMAIN2 | jq '.data.TCBADOMAIN2' | sed 's/"//g'`

TCVPDOMAIN1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCVPDOMAIN1 | jq '.data.TCVPDOMAIN1' | sed 's/"//g'`
TCVPDOMAIN2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCVPDOMAIN2 | jq '.data.TCVPDOMAIN2' | sed 's/"//g'`

TCCHDOMAIN1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCCHDOMAIN1 | jq '.data.TCCHDOMAIN1' | sed 's/"//g'`
TCCHDOMAIN2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCCHDOMAIN2 | jq '.data.TCCHDOMAIN2' | sed 's/"//g'`

TCAILDOMAIN1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCAILDOMAIN1 | jq '.data.TCAILDOMAIN1' | sed 's/"//g'`
TCAILDOMAIN2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCAILDOMAIN2 | jq '.data.TCAILDOMAIN2' | sed 's/"//g'`

ACTIVEMQDOMAIN1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/ACTIVEMQDOMAIN1 | jq '.data.ACTIVEMQDOMAIN1' | sed 's/"//g'`
ACTIVEMQDOMAIN2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/ACTIVEMQDOMAIN2 | jq '.data.ACTIVEMQDOMAIN2' | sed 's/"//g'`

REDISDOMAIN1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/REDISDOMAIN1 | jq '.data.REDISDOMAIN1' | sed 's/"//g'`
REDISDOMAIN2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/REDISDOMAIN2 | jq '.data.REDISDOMAIN2' | sed 's/"//g'`
REDISDOMAIN3=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/REDISDOMAIN3 | jq '.data.REDISDOMAIN3' | sed 's/"//g'`

CDNDOMAIN1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/CDNDOMAIN1 | jq '.data.CDNDOMAIN1' | sed 's/"//g'`
CDNDOMAIN2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/CDNDOMAIN2 | jq '.data.CDNDOMAIN2' | sed 's/"//g'`

SOLRDOMAIN1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/SOLRDOMAIN1 | jq '.data.SOLRDOMAIN1' | sed 's/"//g'`
SOLRDOMAIN2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/SOLRDOMAIN2 | jq '.data.SOLRDOMAIN2' | sed 's/"//g'`
SOLRDOMAIN3=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/SOLRDOMAIN3 | jq '.data.SOLRDOMAIN3' | sed 's/"//g'`

MQRDOMAIN1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/MQRDOMAIN1 | jq '.data.MQRDOMAIN1' | sed 's/"//g'`
MQRDOMAIN2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/MQRDOMAIN2 | jq '.data.MQRDOMAIN2' | sed 's/"//g'`

SQLSERVERDOMAIN1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/SQLSERVERDOMAIN1 | jq '.data.SQLSERVERDOMAIN1' | sed 's/"//g'`
SQLSERVERDOMAIN2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/SQLSERVERDOMAIN2 | jq '.data.SQLSERVERDOMAIN2' | sed 's/"//g'`
SQLSERVERDOMAIN3=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/SQLSERVERDOMAIN3 | jq '.data.SQLSERVERDOMAIN3' | sed 's/"//g'`

IDERAMONITORDOMAIN1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/IDERAMONITORDOMAIN1 | jq '.data.IDERAMONITORDOMAIN1' | sed 's/"//g'`
IDERAMONITORDOMAIN2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/IDERAMONITORDOMAIN2 | jq '.data.IDERAMONITORDOMAIN2' | sed 's/"//g'`

TCBRDOMAIN1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCBRDOMAIN1 | jq '.data.TCBRDOMAIN1' | sed 's/"//g'`
TCBRDOMAIN2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCBRDOMAIN2 | jq '.data.TCBRDOMAIN2' | sed 's/"//g'`

TCREDOMAIN1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCREDOMAIN1 | jq '.data.TCREDOMAIN1' | sed 's/"//g'`
TCREDOMAIN2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCREDOMAIN2 | jq '.data.TCREDOMAIN2' | sed 's/"//g'`

TCSCDOMAIN1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCSCDOMAIN1 | jq '.data.TCSCDOMAIN1' | sed 's/"//g'`
TCSCDOMAIN2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCSCDOMAIN2 | jq '.data.TCSCDOMAIN2' | sed 's/"//g'`

TCIADOMAIN1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCIADOMAIN1 | jq '.data.TCIADOMAIN1' | sed 's/"//g'`
TCIADOMAIN2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCIADOMAIN2 | jq '.data.TCIADOMAIN2' | sed 's/"//g'`

TCIWDOMAIN1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCIWDOMAIN1 | jq '.data.TCIWDOMAIN1' | sed 's/"//g'`
TCIWDOMAIN2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCIWDOMAIN2 | jq '.data.TCIWDOMAIN2' | sed 's/"//g'`

#IPs from vault
INTERNALIP1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/INTERNALIP1 | jq '.data.INTERNALIP1' | sed 's/"//g'`
INTERNALIP2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/INTERNALIP2 | jq '.data.INTERNALIP2' | sed 's/"//g'`

EXTERNALIP1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/EXTERNALIP1 | jq '.data.EXTERNALIP1' | sed 's/"//g'`
EXTERNALIP2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/EXTERNALIP2 | jq '.data.EXTERNALIP2' | sed 's/"//g'`

TCADIP1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCADIP1 | jq '.data.TCADIP1' | sed 's/"//g'`
TCADIP2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCADIP2 | jq '.data.TCADIP2' | sed 's/"//g'`

TCBAIP1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCBAIP1 | jq '.data.TCBAIP1' | sed 's/"//g'`
TCBAIP2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCBAIP2 | jq '.data.TCBAIP2' | sed 's/"//g'`

TCVPIP1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCVPIP1 | jq '.data.TCVPIP1' | sed 's/"//g'`
TCVPIP2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCVPIP2 | jq '.data.TCVPIP2' | sed 's/"//g'`

TCCHIP1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCCHIP1 | jq '.data.TCCHIP1' | sed 's/"//g'`
TCCHIP2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCCHIP2 | jq '.data.TCCHIP2' | sed 's/"//g'`

TCAILIP1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCAILIP1 | jq '.data.TCAILIP1' | sed 's/"//g'`
TCAILIP2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCAILIP2 | jq '.data.TCAILIP2' | sed 's/"//g'`

ACTIVEMQIP1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/ACTIVEMQIP1 | jq '.data.ACTIVEMQIP1' | sed 's/"//g'`
ACTIVEMQIP2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/ACTIVEMQIP2 | jq '.data.ACTIVEMQIP2' | sed 's/"//g'`

REDISIP1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/REDISIP1 | jq '.data.REDISIP1' | sed 's/"//g'`
REDISIP2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/REDISIP2 | jq '.data.REDISIP2' | sed 's/"//g'`
REDISIP3=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/REDISIP3 | jq '.data.REDISIP3' | sed 's/"//g'`

CDNIP1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/CDNIP1 | jq '.data.CDNIP1' | sed 's/"//g'`
CDNIP2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/CDNIP2 | jq '.data.CDNIP2' | sed 's/"//g'`

SOLRIP1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/SOLRIP1 | jq '.data.SOLRIP1' | sed 's/"//g'`
SOLRIP2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/SOLRIP2 | jq '.data.SOLRIP2' | sed 's/"//g'`
SOLRIP3=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/SOLRIP3 | jq '.data.SOLRIP3' | sed 's/"//g'`

MQRIP1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/MQRIP1 | jq '.data.MQRIP1' | sed 's/"//g'`
MQRIP2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/MQRIP2 | jq '.data.MQRIP2' | sed 's/"//g'`

SQLSERVERIP1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/SQLSERVERIP1 | jq '.data.SQLSERVERIP1' | sed 's/"//g'`
SQLSERVERIP2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/SQLSERVERIP2 | jq '.data.SQLSERVERIP2' | sed 's/"//g'`
#SQLSERVERDOMAIN3=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/SQLSERVERDOMAIN3 | jq '.data.SQLSERVERDOMAIN3' | sed 's/"//g'`

IDERAIP1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/IDERAIP1 | jq '.data.IDERAIP1' | sed 's/"//g'`
IDERAIP2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/IDERAIP2 | jq '.data.IDERAIP2' | sed 's/"//g'`

TCBRIP1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCBRIP1 | jq '.data.TCBRIP1' | sed 's/"//g'`
TCBRIP2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCBRIP2 | jq '.data.TCBRIP2' | sed 's/"//g'`

TCREIP1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCREIP1 | jq '.data.TCREIP1' | sed 's/"//g'`
TCREIP2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCREIP2 | jq '.data.TCREIP2' | sed 's/"//g'`

TCSCIP1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCSCIP1 | jq '.data.TCSCIP1' | sed 's/"//g'`
TCSCIP2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCSCIP2 | jq '.data.TCSCIP2' | sed 's/"//g'`

TCIAIP1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCIAIP1 | jq '.data.TCIAIP1' | sed 's/"//g'`
TCIAIP2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCIAIP2 | jq '.data.TCIAIP2' | sed 's/"//g'`

TCIWIP1=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCIWIP1 | jq '.data.TCIWIP1' | sed 's/"//g'`
TCIWIP2=`curl -H "X-Vault-Token:${hashi_vault_root_token}" -X GET http://${hashi_vault_server_ip}:8200/v1/kv/dns_names/TCIWIP2 | jq '.data.TCIWIP2' | sed 's/"//g'`

echo "domain=$DOMAIN" >> /tmp/dnsnames;

sudo systemctl restart bind9


sudo cat <<EOF > /etc/bind/named.conf.options
acl "trusted" {
        $serverip;    # ns1 - can be set to localhost
        $EXTERNALIP1;
        $EXTERNALIP2;
        $INTERNALIP1;
        $INTERNALIP2;
        $TCADIP1;
        $TCADIP2;
        $TCBAIP1;
        $TCBAIP2;
        $TCVPIP1;
        $TCVPIP2;
        $TCCHIP1;
        $TCCHIP2;
        $TCAILIP1;
        $TCAILIP2;
        $ACTIVEMQIP1;
        $ACTIVEMQIP2;
        $REDISIP1;
        $REDISIP2;
        $REDISIP3;
        $SOLRIP1;
        $SOLRIP2;
        $SOLRIP3;
        $MQRIP1;
        $MQRIP2;
        $CDNIP1;
        $CDNIP2;
        $SQLSERVERIP1;
        $SQLSERVERIP2;
        $IDERAIP1;
        $IDERAIP2;
        $TCBRIP1;
        $TCBRIP2;
        $TCREIP1;
        $TCREIP2;
        $TCSCIP1;
        $TCSCIP2;
        $TCIWIP1;
        $TCIWIP2;
        $TCIAIP1;
        $TCIAIP2;
};


options {
        directory "/var/cache/bind";

        recursion yes;                 # enables resursive queries
        allow-recursion { trusted; };  # allows recursive queries from "trusted" clients
        listen-on { $serverip; };   # ns1 private IP address - listen on private network only
        allow-transfer { none; };      # disable zone transfers by default

        forwarders {
                8.8.8.8;
                8.8.4.4;
        };

        // If there is a firewall between you and nameservers you want
        // to talk to, you may need to fix the firewall to allow multiple
        // ports to talk.  See http://www.kb.cert.org/vuls/id/800113

        // If your ISP provided one or more IP addresses for stable
        // nameservers, you probably want to use them as forwarders.
        // Uncomment the following block, and insert the addresses replacing
        // the all-0's placeholder.

        // forwarders {
        //       0.0.0.0;
        // };

        //========================================================================
        // If BIND logs error messages about the root key being expired,
        // you will need to update your keys.  See https://www.isc.org/bind-keys
        //========================================================================
        dnssec-validation auto;

        auth-nxdomain no;    # conform to RFC1035
        listen-on-v6 { any; };
};
EOF

sudo cat <<EOF > /etc/bind/named.conf.local
zone "$DOMAIN" {
    type master;
    file "/etc/bind/zones/forward.$DOMAIN"; 
    allow-transfer { none; };
};

zone "211.10.in-addr.arpa" {
    type master;
    file "/etc/bind/zones/reverse.$DOMAIN"; 
    allow-transfer { none; };
};
//
// Do any local configuration here
//

// Consider adding the 1918 zones here, if they are not used in your
// organization
//include "/etc/bind/zones.rfc1918";
EOF

sudo mkdir /etc/bind/zones
sudo cp /etc/bind/db.local /etc/bind/zones/forward.$DOMAIN

sudo chmod 777 /etc/bind/zones/forward.$DOMAIN
sudo cat <<EOF > /etc/bind/zones/forward.$DOMAIN
;
; BIND data file for local loopback interface
;

\$TTL    604800
@       IN      SOA     ns1.$DOMAIN. admin.$DOMAIN. (
                 30     ; Serial
             604800     ; Refresh
              86400     ; Retry
            2419200     ; Expire
             604800 )   ; Negative Cache TTL
;
; name servers - NS records
@     IN      NS      ns1.$DOMAIN.

; name servers - A records
ns1.$DOMAIN.          IN      A       $serverip

; 10.128.0.0/16 - A records
$EXTERNALDOMAIN.          IN      A      $INTERNALIP1
$EXTERNALDOMAIN.          IN      A      $INTERNALIP2

$INTERNALDOMAIN.          IN      A      $INTERNALIP1
$INTERNALDOMAIN.          IN      A      $INTERNALIP2

$TCADDOMAIN1.             IN      A      $TCADIP1
$TCADDOMAIN2.             IN      A      $TCADIP2

$TCBADOMAIN1.             IN      A      $TCBAIP1
$TCBADOMAIN2.             IN      A      $TCBAIP2

$TCVPDOMAIN1.             IN      A      $TCVPIP1
$TCVPDOMAIN2.             IN      A      $TCVPIP2

$TCCHDOMAIN1.             IN      A      $TCCHIP1
$TCCHDOMAIN2.             IN      A      $TCCHIP2

$TCAILDOMAIN1.            IN      A      $TCAILIP1
$TCAILDOMAIN2.            IN      A      $TCAILIP2

$ACTIVEMQDOMAIN1.         IN      A      $ACTIVEMQIP1
$ACTIVEMQDOMAIN2.         IN      A      $ACTIVEMQIP2

$REDISDOMAIN1.            IN      A      $REDISIP1
$REDISDOMAIN2.            IN      A      $REDISIP2
$REDISDOMAIN3.            IN      A      $REDISIP3

$CDNDOMAIN1.              IN      A      $CDNIP1
$CDNDOMAIN2.              IN      A      $CDNIP2

$SOLRDOMAIN1.             IN      A      $SOLRIP1
$SOLRDOMAIN2.             IN      A      $SOLRIP2
$SOLRDOMAIN3.             IN      A      $SOLRIP3

$MQRDOMAIN1.              IN      A      $MQRIP1
$MQRDOMAIN2.              IN      A      $MQRIP2

$SQLSERVERDOMAIN1.        IN      A      $SQLSERVERIP1
$SQLSERVERDOMAIN2.        IN      A      $SQLSERVERIP2

$IDERAMONITORDOMAIN1.     IN      A      $IDERAIP1
$IDERAMONITORDOMAIN2.     IN      A      $IDERAIP2

$TCBRDOMAIN1.             IN      A      $TCBRIP1
$TCBRDOMAIN2.             IN      A      $TCBRIP2

$TCREDOMAIN1.             IN      A      $TCREIP1
$TCREDOMAIN2.             IN      A      $TCREIP2

$TCSCDOMAIN1.             IN      A      $TCSCIP1
$TCSCDOMAIN2.             IN      A      $TCSCIP2

$TCIWDOMAIN1.             IN      A      $TCIWIP1
$TCIWDOMAIN2.             IN      A      $TCIWIP2

$TCIADOMAIN1.             IN      A      $TCIAIP1
$TCIADOMAIN2.             IN      A      $TCIAIP2
EOF

sudo cp /etc/bind/db.127 /etc/bind/zones/reverse.$DOMAIN

a=`echo $serverip | awk -F . '{print $4"."$3}'`
b=`echo $EXTERNALIP1 | awk -F . '{print $4"."$3}'`
c=`echo $EXTERNALIP2 | awk -F . '{print $4"."$3}'`
d=`echo $INTERNALIP1 | awk -F . '{print $4"."$3}'`
e=`echo $INTERNALIP2 | awk -F . '{print $4"."$3}'`

f=`echo $TCADIP1 | awk -F . '{print $4"."$3}'`
g=`echo $TCADIP2 | awk -F . '{print $4"."$3}'`

h=`echo $TCBAIP1 | awk -F . '{print $4"."$3}'`
i=`echo $TCBAIP2 | awk -F . '{print $4"."$3}'`

j=`echo $TCVPIP1 | awk -F . '{print $4"."$3}'`
k=`echo $TCVPIP2 | awk -F . '{print $4"."$3}'`

l=`echo $TCCHIP1 | awk -F . '{print $4"."$3}'`
m=`echo $TCCHIP2 | awk -F . '{print $4"."$3}'`

n=`echo $TCAILIP1 | awk -F . '{print $4"."$3}'`
o=`echo $TCAILIP2 | awk -F . '{print $4"."$3}'`

p=`echo $ACTIVEMQIP1 | awk -F . '{print $4"."$3}'`
q=`echo $ACTIVEMQIP2 | awk -F . '{print $4"."$3}'`

r=`echo $REDISIP1 | awk -F . '{print $4"."$3}'`
s=`echo $REDISIP2 | awk -F . '{print $4"."$3}'`
t=`echo $REDISIP3 | awk -F . '{print $4"."$3}'`

u=`echo $CDNIP1 | awk -F . '{print $4"."$3}'`
v=`echo $CDNIP2 | awk -F . '{print $4"."$3}'`

w=`echo $SOLRIP1 | awk -F . '{print $4"."$3}'`
x=`echo $SOLRIP2 | awk -F . '{print $4"."$3}'`
y=`echo $SOLRIP3 | awk -F . '{print $4"."$3}'`

aa=`echo $MQRIP1 | awk -F . '{print $4"."$3}'`
bb=`echo $MQRIP2 | awk -F . '{print $4"."$3}'`

cc=`echo $SQLSERVERIP1 | awk -F . '{print $4"."$3}'`
dd=`echo $SQLSERVERIP2 | awk -F . '{print $4"."$3}'`

ee=`echo $IDERAIP1 | awk -F . '{print $4"."$3}'`
ff=`echo $IDERAIP2 | awk -F . '{print $4"."$3}'`

gg=`echo $TCBRIP1 | awk -F . '{print $4"."$3}'`
hh=`echo $TCBRIP2 | awk -F . '{print $4"."$3}'`

ii=`echo $TCREIP1 | awk -F . '{print $4"."$3}'`
jj=`echo $TCREIP2 | awk -F . '{print $4"."$3}'`

kk=`echo $TCSCIP1 | awk -F . '{print $4"."$3}'`
ll=`echo $TCSCIP2 | awk -F . '{print $4"."$3}'`

mm=`echo $TCIWIP1 | awk -F . '{print $4"."$3}'`
nn=`echo $TCIWIP2 | awk -F . '{print $4"."$3}'`

oo=`echo $TCIAIP1 | awk -F . '{print $4"."$3}'`
pp=`echo $TCIAIP2 | awk -F . '{print $4"."$3}'`

sudo cat <<EOF > /etc/bind/zones/reverse.$DOMAIN
;
; BIND reverse data file for local loopback interface
;

\$TTL    604800
@       IN      SOA     $DOMAIN. admin.$DOMAIN. (
                            10         ; Serial
                         604800         ; Refresh
                          86400         ; Retry
                        2419200         ; Expire
                         604800 )       ; Negative Cache TTL
; name servers
@      IN      NS      ns1.$DOMAIN.

; PTR Records
$a IN      PTR     ns1.$DOMAIN.    ;          $serverip
$d IN      PTR      $EXTERNALDOMAIN.  ;           $INTERNALIP1
$e IN      PTR      $EXTERNALDOMAIN.  ;           $INTERNALIP2
$d IN      PTR     $INTERNALDOMAIN.  ;     $INTERNALIP1
$e IN      PTR      $INTERNALDOMAIN.  ;       $INTERNALIP2

$f IN      PTR      $TCADDOMAIN1.  ;           $TCADIP1
$g IN      PTR      $TCADDOMAIN2.  ;           $TCADIP2

$h IN      PTR      $TCBADOMAIN1.  ;           $TCBAIP1
$i IN      PTR      $TCBADOMAIN2.  ;             $TCBAIP2

$j IN      PTR      $TCVPDOMAIN1.  ;              $TCVPIP1
$k IN      PTR      $TCVPDOMAIN2.  ;            $TCVPIP2

$l IN      PTR      $TCCHDOMAIN1. ;           $TCCHIP1
$m IN      PTR      $TCCHDOMAIN2.  ;            $TCCHIP2

$n IN      PTR      $TCAILDOMAIN1.  ;              $TCAILIP1
$o IN      PTR      $TCAILDOMAIN2.  ;             $TCAILIP2

$p IN      PTR      $ACTIVEMQDOMAIN1.  ;             $ACTIVEMQIP1
$q IN      PTR      $ACTIVEMQDOMAIN2.  ;        $ACTIVEMQIP2

$r IN      PTR      $REDISDOMAIN1.  ;     $REDISIP1
$s IN      PTR      $REDISDOMAIN2.  ;               $REDISIP2 
$t IN      PTR      $REDISDOMAIN3. ;                $REDISIP3

$u IN      PTR      $CDNDOMAIN1. ;                $CDNIP1
$v IN      PTR      $CDNDOMAIN2. ;                $CDNIP2

$w IN      PTR      $SOLRDOMAIN1. ;                $SOLRIP1
$x IN      PTR      $SOLRDOMAIN2. ;                $SOLRIP2
$y IN      PTR      $SOLRDOMAIN3. ;                $SOLRIP3

$aa IN      PTR     $MQRDOMAIN1.    ;          $MQRIP1
$bb IN      PTR      $MQRDOMAIN2.  ;           $MQRIP2

$cc IN      PTR      $SQLSERVERDOMAIN1.  ;           $SQLSERVERIP1
$dd IN      PTR     $SQLSERVERDOMAIN2.  ;     $SQLSERVERIP2

$ee IN      PTR      $IDERAMONITORDOMAIN1.  ;       $IDERAIP1
$ff IN      PTR      $IDERAMONITORDOMAIN2.  ;           $IDERAIP2

$gg IN      PTR      $TCBRDOMAIN1.  ;           $TCBRIP1
$hh IN      PTR      $TCBRDOMAIN2.  ;           $TCBRIP2

$ii IN      PTR      $TCREDOMAIN1.  ;             $TCREIP1
$jj IN      PTR      $TCREDOMAIN2.  ;              $TCREIP2

$kk IN      PTR      $TCSCDOMAIN1.  ;            $TCSCIP1
$ll IN      PTR      $TCSCDOMAIN2. ;           $TCSCIP2

$mm IN      PTR      $TCIWDOMAIN1.  ;            $TCIWIP1
$nn IN      PTR      $TCIWDOMAIN2.  ;              $TCIWIP2

$oo IN      PTR      $TCIADOMAIN1.  ;             $TCIAIP1
$pp IN      PTR      $TCIADOMAIN2.  ;             $TCIAIP2
EOF

sudo named-checkconf
cd /etc/bind/zones
sudo named-checkzone $DOMAIN forward.$DOMAIN
cd /etc/bind/zones
sudo named-checkzone 211.10.in-addr.arpa /etc/bind/zones/reverse.$DOMAIN

sudo cat <<EOF > /etc/resolv.conf
# This file is managed by man:systemd-resolved(8). Do not edit.
#
# This is a dynamic resolv.conf file for connecting local clients to the
# internal DNS stub resolver of systemd-resolved. This file lists all
# configured search domains.
#
# Run "systemd-resolve --status" to see details about the uplink DNS servers
# currently in use.
#
# Third party programs must not access this file directly, but only through the
# symlink at /etc/resolv.conf. To manage man:resolv.conf(5) in a different way,
# replace this symlink by a static file or a different symlink.
#
# See man:systemd-resolved.service(8) for details about the supported modes of
# operation for /etc/resolv.conf.

search $DOMAIN
nameserver $serverip

nameserver 127.0.0.53
options edns0
EOF

sudo systemctl restart bind9