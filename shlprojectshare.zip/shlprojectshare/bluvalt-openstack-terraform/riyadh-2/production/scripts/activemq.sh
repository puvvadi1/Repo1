#!/bin/bash
cd ~

sudo apt -y update

sudo apt install -y openjdk-8-jdk vim wget curl

export JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64

export PATH=$PATH:$JAVA_HOME/bin

sudo apt install awscli -y

sudo apt install jq -y

hashi_vault_root_token=""
hashi_vault_server_ip=""
PROFILE=""
 
# Initialize parameters specified from command line
while getopts ":p:t:i:" arg; do
    case "$arg" in
        p)
            PROFILE=$OPTARG
            ;;
        t)
            hashi_vault_root_token=$OPTARG
            ;;
        i)
            hashi_vault_server_ip=$OPTARG
            ;;
    esac
done

AWS_ACCESS_KEY_ID=`curl -H "X-Vault-Token:$hashi_vault_root_token" -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-s3/AWS_ACCESS_KEY_ID | jq '.data.AWS_ACCESS_KEY_ID' | sed 's/"//g'`
AWS_SECRET_ACCESS_KEY=`curl -H "X-Vault-Token:$hashi_vault_root_token" -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-s3/AWS_SECRET_ACCESS_KEY | jq '.data.AWS_SECRET_ACCESS_KEY' | sed 's/"//g'`
AWS_DEFAULT_REGION=`curl -H "X-Vault-Token:$hashi_vault_root_token" -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-s3/AWS_DEFAULT_REGION | jq '.data.AWS_DEFAULT_REGION' | sed 's/"//g'`

echo "AWS_ACCESS_KEY_ID=$AWS_ACCESS_KEY_ID" >> /etc/environment;
echo "AWS_SECRET_ACCESS_KEY=$AWS_SECRET_ACCESS_KEY" >> /etc/environment;
echo "AWS_DEFAULT_REGION=$AWS_DEFAULT_REGION" >> /etc/environment;

source /etc/environment

sudo apt update -y
aws configure set region $AWS_DEFAULT_REGION --profile default
 
aws configure set aws_access_key_id $AWS_ACCESS_KEY_ID --profile default
 
aws configure set aws_secret_access_key $AWS_SECRET_ACCESS_KEY --profile default

#Datadog Installation
 
sudo wget https://s3.amazonaws.com/dd-agent/scripts/install_script.sh
sudo cp install_script.sh /tmp/
sudo chmod +x /tmp/install_script.sh
 
DDAPIKEY=`curl -H "X-Vault-Token: $hashi_vault_root_token " -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-common/DATADOG_APIKEY | jq '.data.DATADOG_APIKEY' | sed 's/"//g'`
 
echo "DD_API_KEY=$DDAPIKEY" >> /etc/environment;
 
DD_AGENT_MAJOR_VERSION=7 DD_API_KEY=$DDAPIKEY DD_SITE="datadoghq.com" bash /tmp/install_script.sh

aws s3api --endpoint-url https://api-object.bluvalt.com:8082 get-object --bucket riyadh2-prd-tc-dependency-artifacts --key apache-activemq-5.15.8-bin.tar.gz ./apache-activemq-5.15.8-bin.tar.gz

sudo touch /etc/datadog-agent/conf.d/http_check.d/conf.yaml
 
aws s3api --endpoint-url https://api-object.bluvalt.com:8082  get-object --bucket riyadh2-prd-tc-application-artifacts --key activemq/activemq_http_check.txt /etc/datadog-agent/conf.d/http_check.d/conf.yaml

tar -xvf apache-activemq-5.15.8-bin.tar.gz
sudo mv apache-activemq-5.15.8 /opt/activemq
rm -rf apache-activemq-5.15.8-bin.tar.gz

sudo addgroup --quiet --system activemq
sudo adduser --quiet --system --ingroup activemq --no-create-home --disabled-password activemq
sudo chown -R activemq:activemq /opt/activemq

tee /etc/systemd/system/activemq.service <<EOF
[Unit]
Description=Apache ActiveMQ
After=network.target
[Service]
Type=forking
User=activemq
Group=activemq

ExecStart=/opt/activemq/bin/activemq start
ExecStop=/opt/activemq/bin/activemq stop

[Install]
WantedBy=multi-user.target
EOF

systemctl stop datadog-agent
echo $DDAPIKEY >> /etc/datadog-agent/temp
 
echo $DDAPIKEY >> /etc/datadog-agent/datadog.yaml
 
tee /etc/datadog-agent/datadog.yaml <<EOF
dd_url: https://app.datadoghq.com
api_key: $DDAPIKEY
logs_enabled: true
log_format_json: false
log_level: DEBUG
log_file: /var/log/datadog/agent.log
log_payloads: false
log_to_console: true
log_to_syslog: false
logging_frequency: 20
apm_config:
  enabled: true
logs_config:
  container_collect_all: false
  dd_port: 10516
  dd_url: agent-intake.logs.datadoghq.com
  dev_mode_use_proto: true
  frame_size: 9000
  open_files_limit: 100
  run_path: ""
  tcp_forward_port: -1
tags:
- system:talentcentral
- application:talentcentral
- env:tc_$PROFILE
- tcappcode:tcactivemq
- tcappname:tcactivemq
EOF
 
mkdir /etc/datadog-agent/conf.d/activemq.d
 
tee /etc/datadog-agent/conf.d/activemq.d/conf.yaml <<EOF
 
init_config:
  is_jmx: true
  collect_default_metrics: true
instances:
  - host: localhost
    port: 8161
    user: admin
    password: admin
    name: activemq_instance
 
logs:
  - type: file
    path: "/opt/activemq/data/activemq.log"
    source: activemq
    service: "tc-activemq"
  - type: file
    path: "/opt/activemq/data/audit.log"
    source: activemq
    service: "tc-activemq"
EOF
 
tee /etc/datadog-agent/conf.d/activemq.d/broker_metrics.yaml <<EOF
 
init_config:
  is_jmx: true
 
  conf:
    - include:
        destinationType: Broker
        attribute:
          TotalDequeueCount:
            alias: activemq.broker.dequeue_count
            metric_type: gauge
          TotalEnqueueCount:
            alias: activemq.broker.enqueue_count
            metric_type: gauge
 
EOF
 
sudo systemctl daemon-reload
sudo systemctl start activemq
sudo systemctl enable activemq
sudo systemctl restart datadog-agent
/opt/activemq/bin/activemq status

sed -i 's|61616|61617|g' /opt/activemq/conf/activemq.xml
sudo systemctl restart activemq
