#!/bin/bash

cd /tmp/redis/redis-3.2.6
#make
mv src/redis-cli /usr/bin
chmod +x /usr/bin/redis-cli
