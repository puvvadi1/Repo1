#!/bin/bash

hashi_vault_root_token=""
hashi_vault_server_ip=""
 
# Initialize parameters specified from command line
while getopts ":t:i:" arg; do
    case "$arg" in
        t)
            hashi_vault_root_token=$OPTARG
            ;;
        i)
            hashi_vault_server_ip=$OPTARG
            ;;
    esac
done
 
sudo apt install awscli -y
sudo apt install jq -y
sudo apt-get install zip unzip -y

AWS_ACCESS_KEY_ID=`curl -H "X-Vault-Token:$hashi_vault_root_token" -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-s3/AWS_ACCESS_KEY_ID | jq '.data.AWS_ACCESS_KEY_ID' | sed 's/"//g'`
AWS_SECRET_ACCESS_KEY=`curl -H "X-Vault-Token:$hashi_vault_root_token" -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-s3/AWS_SECRET_ACCESS_KEY | jq '.data.AWS_SECRET_ACCESS_KEY' | sed 's/"//g'`
AWS_DEFAULT_REGION=`curl -H "X-Vault-Token:$hashi_vault_root_token" -X GET http://$hashi_vault_server_ip:8200/v1/kv/tc-s3/AWS_DEFAULT_REGION | jq '.data.AWS_DEFAULT_REGION' | sed 's/"//g'`
 
echo "AWS_ACCESS_KEY_ID=$AWS_ACCESS_KEY_ID" >> /etc/environment;
echo "AWS_SECRET_ACCESS_KEY=$AWS_SECRET_ACCESS_KEY" >> /etc/environment;
echo "AWS_DEFAULT_REGION=$AWS_DEFAULT_REGION" >> /etc/environment;
 
sudo bash /etc/environment


sudo apt update -y

sudo apt install apache2 -y

sudo systemctl enable apache2

sudo ufw allow 'Apache'

sudo systemctl stop apache2
 
sudo rm /var/www/html/index.html

# To Mount S3 bucket with CDN server

sudo apt install s3fs

sudo touch /etc/passwd-s3fs

echo "$AWS_ACCESS_KEY_ID:$AWS_SECRET_ACCESS_KEY" >> /etc/passwd-s3fs;

sudo chmod 600 /etc/passwd-s3fs

sudo s3fs riyadh2-prd-cdn-resources /var/www/html -o passwd_file=/etc/passwd-s3fs -o allow_other -o url=https://api-object.bluvalt.com:8082 -o umask=0022,uid=1000,gid=1000

sudo systemctl restart apache2

sudo mkdir /opt/shl/
 
sudo touch /opt/shl/monitor-s3-mountpoint.sh
 
# Create s3 mount-point monitoring script and cron-job
cat > /opt/shl/monitor-s3-mountpoint.sh  <<- "EOF"
#!/bin/bash
MountFailed=$(/bin/ls -l /var/www/html 2>&1 | grep -i "healthcheck.html" | wc -l)
 
if [[ $MountFailed == "0" ]]; then
  echo $(date) ": Remounting /var/www/hmtl on TCCD  .."
  umount -l /var/www/html
  sudo s3fs riyadh2-prd-cdn-resources /var/www/html -o passwd_file=/etc/passwd-s3fs -o allow_other -o url=https://api-object.bluvalt.com:8082 -o umask=0022,uid=1000,gid=1000
  sleep 15
 
fi
EOF
 
sudo chmod 755 /opt/shl/monitor-s3-mountpoint.sh
 
cat > /etc/cron.d/cdnload << EOF
*/1 * * * * root /bin/bash /opt/shl/monitor-s3-mountpoint.sh
EOF
 
sudo systemctl start cron
sudo systemctl enable cron