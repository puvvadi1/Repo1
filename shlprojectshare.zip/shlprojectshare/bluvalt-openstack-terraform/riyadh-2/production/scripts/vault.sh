#!/bin/bash

access_key = ""
secret_key = ""
bucket_name = ""
 
# Initialize parameters specified from command line
while getopts ":t:i:p:" arg; do
    case "$arg" in
        t)
            access_key=$OPTARG
            ;;
        i)
            secret_key=$OPTARG
            ;;
        p)
            bucket_name=${OPTARG}
            ;;
    esac
done

sudo apt-get update -y
sudo apt-get install zip unzip -y

wget https://releases.hashicorp.com/vault/1.7.1/vault_1.7.1_linux_amd64.zip
sudo unzip vault_1.7.1_linux_amd64.zip
mv vault /usr/bin
sudo mkdir /etc/vault
sudo mkdir -p /var/lib/vault/data

cat > /etc/vault/config.hcl <<-EOF
disable_cache = true
disable_mlock = true
ui = true
listener "tcp" {
   address          = "0.0.0.0:8200"
   tls_disable      = 1
}
storage "s3" {
  access_key = "$access_key"
  secret_key = "$secret_key"
  region     = "us-east-1"
  endpoint   = "https://api-object.bluvalt.com:8082"
  bucket     = "$bucket_name"
}
api_addr         = "http://0.0.0.0:8200"
max_lease_ttl         = "10h"
default_lease_ttl    = "10h"
cluster_name         = "vault"
raw_storage_endpoint     = true
disable_sealwrap     = true
disable_printable_check = true
EOF

cat > /etc/systemd/system/vault.service <<-EOF
[Unit]
Description="HashiCorp Vault - A tool for managing secrets"
Documentation=https://www.vaultproject.io/docs/
Requires=network-online.target
After=network-online.target
ConditionFileNotEmpty=/etc/vault/config.hcl

[Service]
ProtectSystem=full
ProtectHome=read-only
PrivateTmp=yes
PrivateDevices=yes
SecureBits=keep-caps
AmbientCapabilities=CAP_IPC_LOCK
NoNewPrivileges=yes
ExecStart=/usr/bin/vault server -config=/etc/vault/config.hcl
ExecReload=/bin/kill --signal HUP 
KillMode=process
KillSignal=SIGINT
Restart=on-failure
RestartSec=5
TimeoutStopSec=30
StartLimitBurst=3
LimitNOFILE=6553

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl start vault
systemctl enable vault
